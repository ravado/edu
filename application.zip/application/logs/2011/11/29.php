<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-11-29 00:04:21 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:04:21 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:04:57 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:04:57 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:05:24 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:05:24 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:05:36 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:05:36 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:06:45 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:06:45 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:06:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:06:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:06:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:06:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:08:22 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:08:22 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:09:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:09:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:10:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:10:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:10:11 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:10:11 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:10:21 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:10:21 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:10:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:10:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:11:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:11:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:11:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:11:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:13:04 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:13:04 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:13:23 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:13:23 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:13:36 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:13:36 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:13:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:13:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:15:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:15:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:15:47 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:15:47 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:16:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:16:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:16:03 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:16:03 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 00:16:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 00:16:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:08:22 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:08:22 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:08:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL й was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:08:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL й was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:08:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:08:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:08:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:08:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:11:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:11:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:12:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:12:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:12:15 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:12:15 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:12:22 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:12:22 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:12:27 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:12:27 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:12:48 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:12:48 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:13:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:13:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:13:56 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:13:56 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:14:06 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:14:06 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:17:23 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:17:23 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:17:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:17:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:17:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:17:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:18:11 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:18:11 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:18:15 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:18:15 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:18:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:18:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:18:59 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:18:59 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:19:07 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:19:07 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:19:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:19:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:19:36 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:19:36 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:19:40 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:19:40 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:19:56 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:19:56 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:20:12 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:20:12 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:20:23 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:20:23 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:20:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:20:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:20:37 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:20:37 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:23:36 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:23:36 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:23:43 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:23:43 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:24:08 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:24:08 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:24:19 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:24:19 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:26:01 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:26:01 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:26:21 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:26:21 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:26:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:26:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:27:38 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:27:38 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:29:27 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:29:27 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:29:36 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:29:36 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:29:41 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:29:41 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:30:12 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:30:12 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:30:38 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:30:38 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:31:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:31:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:31:43 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:31:43 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:31:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:31:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:32:09 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:32:09 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:32:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:32:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:34:17 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:34:17 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:34:47 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:34:47 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:34:58 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:34:58 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:38:07 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:38:07 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:38:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:38:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:38:42 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:38:42 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:38:56 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:38:56 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:39:04 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:39:04 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:39:20 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:39:20 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:40:15 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:40:15 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:40:23 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:40:23 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:40:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:40:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:40:58 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:40:58 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:41:10 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:41:10 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:41:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:41:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:41:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:41:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:41:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:41:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:41:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:41:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:41:57 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:41:57 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-29 21:41:58 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-29 21:41:58 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}