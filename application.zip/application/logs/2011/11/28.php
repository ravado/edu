<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-11-28 18:03:14 --- ERROR: Database_Exception [ 2 ]: mysql_connect() [function.mysql-connect]: Access denied for user 'root'@'localhost' (using password: NO) ~ MODPATH/database/classes/kohana/database/mysql.php [ 67 ]
2011-11-28 18:03:14 --- STRACE: Database_Exception [ 2 ]: mysql_connect() [function.mysql-connect]: Access denied for user 'root'@'localhost' (using password: NO) ~ MODPATH/database/classes/kohana/database/mysql.php [ 67 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/mysql.php(171): Kohana_Database_MySQL->connect()
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT * FROM `...', false, Array)
#2 /Users/ravado/Sites/edu/application/classes/model/mnews.php(11): Kohana_Database_Query->execute()
#3 /Users/ravado/Sites/edu/application/classes/controller/news/news.php(20): Model_Mnews->getCountNews()
#4 [internal function]: Controller_News_News->action_index()
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_News_News))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#9 {main}
2011-11-28 18:06:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:06:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:06:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:06:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:09:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/question.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:09:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/question.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:09:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:09:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:09:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:09:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:09:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:09:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:11:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:11:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:11:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:11:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:11:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:11:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:49:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:49:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:49:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:49:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:49:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:49:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:50:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:50:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:50:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:50:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:50:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:50:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:51:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:51:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:52:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:52:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:52:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:52:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:52:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:52:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:52:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:52:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:52:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:52:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:52:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:52:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:53:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:53:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:53:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:53:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:53:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:53:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:53:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:53:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:53:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:53:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:53:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:53:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:54:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:54:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:54:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:54:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:54:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:54:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:54:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:54:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:54:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:54:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:54:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:54:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:55:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:55:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:55:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:55:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:55:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:55:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:56:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:56:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:56:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:56:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:56:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:56:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:56:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:56:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:56:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:56:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:56:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:56:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:56:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:56:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:56:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:56:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:56:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:56:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:57:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:57:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:57:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:57:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:57:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:57:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:57:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:57:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:57:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:57:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:57:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:57:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:59:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:59:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:59:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:59:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 18:59:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 18:59:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:03:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:03:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:03:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:03:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:03:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:03:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:05:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:05:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:05:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:05:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:05:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:05:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:05:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:05:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:05:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:05:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:05:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:05:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:06:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:06:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:06:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:06:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:06:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:06:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:07:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:07:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:07:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:07:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:07:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:07:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:08:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:08:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:08:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:08:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:08:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:08:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:08:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:08:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:08:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:08:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:08:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:08:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:08:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:08:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:08:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:08:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:08:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:08:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:08:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:08:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:08:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:08:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:08:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:08:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:09:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:09:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:09:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:09:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:09:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:09:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:13:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:13:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:13:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:13:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:13:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:13:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:13:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:13:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:13:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:13:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:13:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:13:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:13:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:13:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:13:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:13:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:13:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:13:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:15:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:15:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:16:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:16:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:16:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:16:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:16:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:16:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:17:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:17:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:17:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:17:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:17:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:17:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:17:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:17:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:17:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:17:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:17:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:17:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:17:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:17:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:17:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:17:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:17:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:17:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:18:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:18:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:18:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:18:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:18:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:18:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:18:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:18:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:18:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:18:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:18:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:18:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:18:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:18:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:18:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:18:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:18:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:18:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:19:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:19:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:19:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:19:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:19:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:19:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:19:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:19:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:19:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:19:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:19:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:19:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:20:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:20:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:21:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:21:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:21:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:21:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:21:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:21:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:21:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:21:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:21:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:21:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:21:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:21:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:21:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:21:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:21:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:21:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:21:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:21:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:22:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:22:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:22:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:22:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:22:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:22:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:22:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:22:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:22:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:22:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:22:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:22:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:22:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:22:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:22:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:22:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:22:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:22:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:23:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:23:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:23:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:23:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:23:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:23:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:24:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:24:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:24:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:24:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:24:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:24:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:28:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:28:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:28:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:28:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:28:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:28:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:29:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:29:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:29:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:29:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:29:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:29:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:29:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:29:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:29:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:29:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:29:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:29:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:30:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:30:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:30:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:30:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:30:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:30:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:30:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:30:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:30:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:30:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:30:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:30:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:30:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:30:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:30:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:30:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:30:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:30:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:31:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:31:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:31:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:31:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:31:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:31:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:31:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:31:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:31:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:31:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:31:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:31:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:31:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:31:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:31:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:31:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:31:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:31:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:33:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:33:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:33:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:33:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:33:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:33:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:33:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:33:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:33:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:33:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:33:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:33:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:33:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:33:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:33:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:33:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:33:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:33:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:33:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:33:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:33:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:33:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:33:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:33:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:34:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:34:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:34:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:34:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:34:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:34:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:35:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:35:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:35:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:35:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:35:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:35:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:35:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:35:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:35:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:35:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:35:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:35:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:35:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:35:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:35:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:35:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:35:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:35:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:36:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:36:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:36:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:36:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:36:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:36:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:37:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:37:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:37:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:37:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:37:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:37:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:38:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:38:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:38:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:38:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:38:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:38:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:38:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:38:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:38:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:38:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:38:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:38:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:39:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:39:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:39:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:39:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:39:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:39:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:39:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:39:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:39:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:39:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:39:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:39:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:39:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:39:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:39:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:39:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:39:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:39:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:39:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:39:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:39:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:39:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:39:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:39:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:40:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:40:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:40:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:40:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:40:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:40:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:40:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:40:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:40:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:40:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:40:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:40:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:41:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:41:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:41:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:41:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:41:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:41:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:41:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:41:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:41:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:41:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:41:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:41:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:41:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:41:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:41:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:41:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:41:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:41:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:43:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:43:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:43:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:43:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:43:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:43:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:45:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:45:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:45:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:45:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:45:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:45:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:45:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:45:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:45:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:45:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:45:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:45:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:46:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:46:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:46:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:46:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:46:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:46:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:46:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:46:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:46:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:46:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:46:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:46:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:46:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:46:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:46:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:46:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:46:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:46:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:47:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:47:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:47:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:47:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:47:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:47:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:48:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:48:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:48:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:48:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:48:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:48:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:48:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:48:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:48:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:48:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:48:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:48:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:48:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:48:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:48:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:48:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:48:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:48:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:53:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:53:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:53:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:53:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:53:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:53:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:53:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:53:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:53:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:53:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:53:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:53:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:53:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:53:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:53:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:53:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:53:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:53:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:54:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:54:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:54:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:54:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:54:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:54:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:54:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:54:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:54:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:54:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:54:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:54:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:54:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:54:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:54:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:54:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:54:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:54:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:54:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:54:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:54:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:54:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:54:23 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:54:23 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:54:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:54:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:54:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:54:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:54:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:54:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:55:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:55:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:55:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:55:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:55:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:55:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:55:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:55:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:55:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:55:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:55:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:55:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:58:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:58:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:58:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:58:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:58:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:58:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:58:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:58:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:58:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:58:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:58:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:58:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:59:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:59:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:59:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:59:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:59:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:59:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:59:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:59:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:59:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:59:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:59:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:59:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:59:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:59:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:59:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:59:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:59:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:59:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:59:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:59:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:59:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:59:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 19:59:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 19:59:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:00:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:00:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:00:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:00:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:00:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:00:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:00:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:00:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:00:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:00:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:02:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:02:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:02:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:02:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:02:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:02:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:03:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:03:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:03:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:03:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:03:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:03:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:03:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:03:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:03:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:03:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:03:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:03:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:03:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:03:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:03:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:03:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:03:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:03:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:03:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:03:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:03:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:03:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:03:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:03:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:07:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:07:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:07:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:07:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:07:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:07:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:08:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:08:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:08:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:08:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:08:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:08:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:09:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:09:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:09:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:09:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:09:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:09:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:10:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:10:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:10:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:10:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:10:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:10:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:12:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:12:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:12:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:12:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:12:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:12:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:15:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:15:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:15:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:15:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:15:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:15:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:16:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:16:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:16:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:16:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:16:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:16:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:18:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:18:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:18:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:18:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:18:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:18:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:20:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:20:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:20:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:20:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:20:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:20:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:21:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:21:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:21:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:21:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:21:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:21:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:21:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:21:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:21:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:21:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:21:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:21:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:22:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:22:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:22:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:22:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:22:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:22:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:22:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:22:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:22:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:22:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:22:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:22:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:22:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:22:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:22:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:22:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:22:45 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:22:45 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:23:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:23:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:24:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:24:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:24:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:24:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:24:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:24:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:24:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:24:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:24:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:24:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:24:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:24:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:24:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:24:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:24:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:24:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:24:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:24:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:24:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:24:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:24:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:24:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:24:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:24:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:25:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:25:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:25:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:25:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:25:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:25:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:25:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:25:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:25:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:25:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:25:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:25:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:25:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:25:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:25:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:25:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:25:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:25:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:26:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:26:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/user1.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:26:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:26:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/answer.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:26:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-11-28 20:26:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/q&a/time.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-11-28 20:51:17 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:51:17 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 20:51:45 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:51:45 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 20:51:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:51:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 20:51:57 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:51:57 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 20:52:01 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:52:01 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 20:52:31 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:52:31 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 20:52:38 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:52:38 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 20:52:45 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:52:45 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 20:52:55 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:52:55 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 20:53:11 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:53:11 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 20:57:44 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:57:44 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 20:58:22 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:58:22 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 20:59:08 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:59:08 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 20:59:19 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:59:19 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 20:59:27 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:59:27 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 20:59:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 20:59:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:00:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:00:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:00:56 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:00:56 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:03:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:03:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:04:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:04:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:06:03 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:06:03 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:06:10 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:06:10 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:06:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:06:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:06:39 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:06:39 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:06:50 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:06:50 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:07:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:07:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:08:09 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:08:09 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:08:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:08:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:08:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:08:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:08:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:08:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:08:41 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:08:41 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:08:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:08:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:08:56 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:08:56 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:09:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:09:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:09:09 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:09:09 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:09:58 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:09:58 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:10:44 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:10:44 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:10:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:10:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:11:04 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:11:04 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:11:13 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:11:13 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:11:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:11:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:11:32 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:11:32 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:11:37 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:11:37 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:11:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:11:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:12:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:12:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:12:22 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:12:22 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:13:19 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:13:19 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:13:37 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:13:37 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:14:25 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:14:25 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:14:37 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:14:37 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:14:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:14:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:15:39 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:15:39 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:16:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:16:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:16:38 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:16:38 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:16:44 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:16:44 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:16:48 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:16:48 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:17:03 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:17:03 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:17:07 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:17:07 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:17:44 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:17:44 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:17:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:17:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:17:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:17:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:18:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:18:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:18:20 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:18:20 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:20:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:20:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:20:43 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:20:43 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:22:42 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:22:42 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:22:48 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:22:48 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:23:55 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:23:55 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:23:57 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:23:57 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:24:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:24:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:25:06 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:25:06 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:25:39 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:25:39 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:26:10 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:26:10 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:27:06 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:27:06 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:27:22 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:27:22 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:27:41 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:27:41 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:29:19 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:29:19 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:32:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:32:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:33:19 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:33:19 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:33:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:33:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:34:18 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:34:18 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:34:45 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:34:45 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:44:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:44:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 21:48:42 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 21:48:42 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:10:42 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:10:42 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:13:41 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:13:41 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:15:00 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:15:00 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:16:18 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:16:18 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:27:06 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:27:06 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:27:13 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:27:13 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:29:16 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:29:16 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:29:51 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:29:51 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:30:22 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:30:22 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:32:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:32:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:32:35 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:32:35 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:32:44 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:32:44 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:32:55 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:32:55 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:33:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:33:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:33:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:33:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:33:32 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:33:32 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:33:59 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:33:59 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:34:10 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:34:10 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:34:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:34:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:35:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:35:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:35:21 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:35:21 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:35:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:35:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:36:23 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:36:23 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:37:15 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:37:15 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:37:22 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:37:22 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:37:38 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:37:38 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:37:58 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:37:58 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:38:09 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:38:09 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:38:16 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:38:16 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:39:42 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:39:42 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:41:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:41:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:41:27 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:41:27 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:41:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:41:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:41:48 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:41:48 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:41:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:41:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:42:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:42:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:42:16 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:42:16 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:42:41 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:42:41 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:42:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:42:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:43:00 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:43:00 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 22:43:22 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 22:43:22 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:10:09 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:10:09 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:21:38 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:21:38 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:23:32 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:23:32 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:23:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:23:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:24:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:24:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:24:21 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:24:21 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:24:38 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:24:38 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:24:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:24:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:25:09 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:25:09 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:25:56 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:25:56 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:26:47 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:26:47 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:27:00 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:27:00 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:27:18 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:27:18 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:27:33 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:27:33 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:27:44 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:27:44 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:27:58 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:27:58 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:28:22 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:28:22 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:28:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:28:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:28:38 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:28:38 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:29:21 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:29:21 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:29:43 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:29:43 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:30:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:30:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:30:22 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:30:22 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:33:40 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:33:40 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:33:42 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:33:42 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:33:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:33:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:33:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:33:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:33:58 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:33:58 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:34:11 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:34:11 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:34:41 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:34:41 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:34:44 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:34:44 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:34:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:34:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:35:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:35:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:35:10 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:35:10 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:39:11 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:39:11 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:43:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:43:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:45:12 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:45:12 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:47:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:47:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:47:36 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:47:36 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:49:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:49:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-11-28 23:51:03 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-11-28 23:51:03 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL stfile/js/jquery was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}