<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-12-13 23:10:43 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id' in 'where clause' [ SELECT * FROM `subcategory` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2011-12-13 23:10:43 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id' in 'where clause' [ SELECT * FROM `subcategory` WHERE `id` = '1' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT * FROM `...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(13): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(48): Model_Mquestions->askQuestion(true)
#3 [internal function]: Controller_Questions_Questions->action_ask()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2011-12-13 23:12:44 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestionsAsk.php [ 20 ]
2011-12-13 23:12:44 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestionsAsk.php [ 20 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(20): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-13 23:12:58 --- ERROR: ErrorException [ 8 ]: Undefined offset:  1 ~ APPPATH/views/questions/vQuestionsAsk.php [ 20 ]
2011-12-13 23:12:58 --- STRACE: ErrorException [ 8 ]: Undefined offset:  1 ~ APPPATH/views/questions/vQuestionsAsk.php [ 20 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(20): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-13 23:13:04 --- ERROR: ErrorException [ 8 ]: Undefined offset:  1 ~ APPPATH/views/questions/vQuestionsAsk.php [ 20 ]
2011-12-13 23:13:04 --- STRACE: ErrorException [ 8 ]: Undefined offset:  1 ~ APPPATH/views/questions/vQuestionsAsk.php [ 20 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(20): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-13 23:13:34 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestionsAsk.php [ 20 ]
2011-12-13 23:13:34 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestionsAsk.php [ 20 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(20): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-13 23:13:45 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestionsAsk.php [ 20 ]
2011-12-13 23:13:45 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestionsAsk.php [ 20 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(20): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}