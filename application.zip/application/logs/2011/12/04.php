<?php defined('SYSPATH') or die('No direct script access.'); ?>

2011-12-04 18:07:57 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/a was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-12-04 18:07:57 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/a was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-12-04 18:07:57 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/as was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-12-04 18:07:57 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/as was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-12-04 18:07:58 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/ask was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-12-04 18:07:58 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/ask was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-12-04 18:08:32 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/ask was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-12-04 18:08:32 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/ask was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-12-04 18:08:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 18:08:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 18:08:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 18:08:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 18:10:12 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/a was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-12-04 18:10:12 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/a was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-12-04 18:10:12 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/as was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-12-04 18:10:12 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/as was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-12-04 18:10:12 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/ask was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-12-04 18:10:12 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/ask was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-12-04 18:10:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/ask. ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 18:10:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/ask. ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 18:10:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/ask.p ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 18:10:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/ask.p ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 18:10:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/ask.php ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 18:10:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/ask.php ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 18:12:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL a was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-12-04 18:12:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL a was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-12-04 18:12:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL adm/pa was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-12-04 18:12:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL adm/pa was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-12-04 18:12:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL adm/pane was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-12-04 18:12:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL adm/pane was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-12-04 18:14:59 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2011-12-04 18:14:59 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^questions(?:/...', 'questions', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('questions')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('questions', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/questions', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2011-12-04 18:15:02 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2011-12-04 18:15:02 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^questions(?:/...', 'questions.', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('questions.')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('questions.', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/questions.', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2011-12-04 18:15:03 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2011-12-04 18:15:03 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^questions(?:/...', 'questions.a', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('questions.a')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('questions.a', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/questions.a', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2011-12-04 18:15:03 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2011-12-04 18:15:03 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^questions(?:/...', 'questions.aa', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('questions.aa')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('questions.aa', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/questions.aa', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2011-12-04 18:15:04 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2011-12-04 18:15:04 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^questions(?:/...', 'questions.', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('questions.')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('questions.', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/questions.', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2011-12-04 18:15:05 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2011-12-04 18:15:05 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^questions(?:/...', 'questions', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('questions')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('questions', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/questions/', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2011-12-04 18:15:05 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2011-12-04 18:15:05 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^questions(?:/...', 'questions/as', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('questions/as')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('questions/as', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/questions/as', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2011-12-04 18:15:05 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2011-12-04 18:15:05 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: unmatched parentheses at offset 66 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^questions(?:/...', 'questions/ask', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('questions/ask')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('questions/ask', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/questions/ask', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2011-12-04 18:15:16 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: two named subpatterns have the same name at offset 52 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2011-12-04 18:15:16 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: two named subpatterns have the same name at offset 52 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^questions(?:/...', 'questions/ask', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('questions/ask')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('questions/ask', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/questions/ask', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2011-12-04 18:15:20 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: two named subpatterns have the same name at offset 52 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2011-12-04 18:15:20 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: two named subpatterns have the same name at offset 52 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^questions(?:/...', 'questions', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('questions')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('questions', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/questions', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2011-12-04 18:15:22 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: two named subpatterns have the same name at offset 52 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2011-12-04 18:15:22 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: two named subpatterns have the same name at offset 52 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^questions(?:/...', 'questions', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('questions')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('questions', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/questions/', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2011-12-04 18:15:23 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: two named subpatterns have the same name at offset 52 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2011-12-04 18:15:23 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: two named subpatterns have the same name at offset 52 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^questions(?:/...', 'questions/in', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('questions/in')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('questions/in', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/questions/in', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2011-12-04 18:15:24 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: two named subpatterns have the same name at offset 52 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2011-12-04 18:15:24 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: two named subpatterns have the same name at offset 52 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^questions(?:/...', 'questions/inde', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('questions/inde')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('questions/inde', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/questions/inde', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2011-12-04 18:15:24 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: two named subpatterns have the same name at offset 52 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2011-12-04 18:15:24 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: two named subpatterns have the same name at offset 52 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2011-12-04 18:15:24 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: two named subpatterns have the same name at offset 52 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^questions(?:/...', 'questions/index', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('questions/index')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('questions/index', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/questions/inde...', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2011-12-04 18:15:24 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: two named subpatterns have the same name at offset 52 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^questions(?:/...', 'questions/index', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('questions/index')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('questions/index', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/questions/inde...', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2011-12-04 18:16:57 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/a was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2011-12-04 18:16:57 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/a was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-12-04 18:16:57 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/as was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2011-12-04 18:16:57 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/as was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-12-04 18:17:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 18:17:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 18:17:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 18:17:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 18:18:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions. ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 18:18:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions. ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 18:18:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions.ф ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 18:18:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions.ф ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 18:18:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions.фыл ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 18:18:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions.фыл ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 18:18:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions. ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 18:18:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions. ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 18:27:06 --- ERROR: ErrorException [ 8 ]: Undefined index:  some ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 18:27:06 --- STRACE: ErrorException [ 8 ]: Undefined index:  some ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 18:27:19 --- ERROR: ErrorException [ 8 ]: Undefined index:  question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 18:27:19 --- STRACE: ErrorException [ 8 ]: Undefined index:  question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 18:27:20 --- ERROR: ErrorException [ 8 ]: Undefined index:  question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 18:27:20 --- STRACE: ErrorException [ 8 ]: Undefined index:  question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 18:27:22 --- ERROR: ErrorException [ 8 ]: Undefined index:  question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 18:27:22 --- STRACE: ErrorException [ 8 ]: Undefined index:  question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 18:27:36 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 18:27:36 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 18:48:43 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL s was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-12-04 18:48:43 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL s was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-12-04 18:52:32 --- ERROR: ErrorException [ 8 ]: Undefined index:  btnAsk ~ APPPATH/classes/controller/questions/questions.php [ 42 ]
2011-12-04 18:52:32 --- STRACE: ErrorException [ 8 ]: Undefined index:  btnAsk ~ APPPATH/classes/controller/questions/questions.php [ 42 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(42): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2011-12-04 18:52:48 --- ERROR: ErrorException [ 8 ]: Undefined index:  btnAsk ~ APPPATH/classes/controller/questions/questions.php [ 42 ]
2011-12-04 18:52:48 --- STRACE: ErrorException [ 8 ]: Undefined index:  btnAsk ~ APPPATH/classes/controller/questions/questions.php [ 42 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(42): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2011-12-04 18:53:49 --- ERROR: ErrorException [ 8 ]: Undefined index:  sss ~ APPPATH/classes/controller/questions/questions.php [ 42 ]
2011-12-04 18:53:49 --- STRACE: ErrorException [ 8 ]: Undefined index:  sss ~ APPPATH/classes/controller/questions/questions.php [ 42 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(42): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2011-12-04 18:55:03 --- ERROR: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 18:55:03 --- STRACE: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 18:55:13 --- ERROR: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 18:55:13 --- STRACE: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 18:56:08 --- ERROR: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 18:56:08 --- STRACE: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 18:56:48 --- ERROR: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 18:56:48 --- STRACE: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 18:58:12 --- ERROR: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 18:58:12 --- STRACE: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 18:58:34 --- ERROR: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 18:58:34 --- STRACE: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 18:58:39 --- ERROR: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 18:58:39 --- STRACE: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 19:05:08 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL sadas was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2011-12-04 19:05:08 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL sadas was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-12-04 19:09:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2011-12-04 19:09:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2011-12-04 19:09:21 --- ERROR: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 19:09:21 --- STRACE: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 19:12:51 --- ERROR: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 19:12:51 --- STRACE: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 19:12:56 --- ERROR: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 19:12:56 --- STRACE: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 19:13:12 --- ERROR: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 19:13:12 --- STRACE: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 19:13:40 --- ERROR: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 19:13:40 --- STRACE: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 19:13:43 --- ERROR: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 19:13:43 --- STRACE: ErrorException [ 8 ]: Undefined variable: question ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 20:15:22 --- ERROR: ErrorException [ 8 ]: Undefined variable: result ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 20:15:22 --- STRACE: ErrorException [ 8 ]: Undefined variable: result ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 20:17:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 20:17:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 20:17:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 20:17:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 20:26:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 20:26:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 20:26:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 20:26:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 20:28:43 --- ERROR: ErrorException [ 8 ]: Undefined variable: result ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 20:28:43 --- STRACE: ErrorException [ 8 ]: Undefined variable: result ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 20:29:03 --- ERROR: ErrorException [ 8 ]: Undefined index:  frmQuestion ~ APPPATH/classes/controller/questions/questions.php [ 44 ]
2011-12-04 20:29:03 --- STRACE: ErrorException [ 8 ]: Undefined index:  frmQuestion ~ APPPATH/classes/controller/questions/questions.php [ 44 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(44): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2011-12-04 20:29:42 --- ERROR: ErrorException [ 1 ]: Class 'Model_Mquestion' not found ~ SYSPATH/classes/kohana/model.php [ 26 ]
2011-12-04 20:29:42 --- STRACE: ErrorException [ 1 ]: Class 'Model_Mquestion' not found ~ SYSPATH/classes/kohana/model.php [ 26 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler('Mquestion')
#1 {main}
2011-12-04 20:30:06 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Mquestions::askQuestion() ~ APPPATH/classes/controller/questions/questions.php [ 45 ]
2011-12-04 20:30:06 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Mquestions::askQuestion() ~ APPPATH/classes/controller/questions/questions.php [ 45 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2011-12-04 20:31:37 --- ERROR: ErrorException [ 8 ]: Undefined index:  frmQuestion ~ APPPATH/classes/controller/questions/questions.php [ 44 ]
2011-12-04 20:31:37 --- STRACE: ErrorException [ 8 ]: Undefined index:  frmQuestion ~ APPPATH/classes/controller/questions/questions.php [ 44 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(44): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2011-12-04 20:32:23 --- ERROR: ErrorException [ 8 ]: Undefined variable: result ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 20:32:23 --- STRACE: ErrorException [ 8 ]: Undefined variable: result ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 20:32:23 --- ERROR: ErrorException [ 8 ]: Undefined variable: result ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
2011-12-04 20:32:23 --- STRACE: ErrorException [ 8 ]: Undefined variable: result ~ APPPATH/views/questions/vQuestionsAsk.php [ 3 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(3): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(37): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2011-12-04 21:02:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 21:02:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 21:02:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 21:02:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 21:02:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 21:02:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2011-12-04 21:02:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2011-12-04 21:02:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}