<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-02-17 00:14:15 --- ERROR: ErrorException [ 8 ]: Undefined index: cat_id ~ APPPATH/classes/model/mquestions.php [ 549 ]
2012-02-17 00:14:15 --- STRACE: ErrorException [ 8 ]: Undefined index: cat_id ~ APPPATH/classes/model/mquestions.php [ 549 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(549): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 549, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(190): Model_Mquestions->getAllQuestions(Array)
#2 [internal function]: Controller_Questions_Questions->action_all()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-02-17 00:48:57 --- ERROR: ErrorException [ 1 ]: Call to undefined function as_array() ~ APPPATH/classes/model/mquestions.php [ 457 ]
2012-02-17 00:48:57 --- STRACE: ErrorException [ 1 ]: Call to undefined function as_array() ~ APPPATH/classes/model/mquestions.php [ 457 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-02-17 21:59:42 --- ERROR: ErrorException [ 8 ]: Undefined variable: category ~ APPPATH/views/questions/vQuestionsAsk.php [ 19 ]
2012-02-17 21:59:42 --- STRACE: ErrorException [ 8 ]: Undefined variable: category ~ APPPATH/views/questions/vQuestionsAsk.php [ 19 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionsAsk.php(19): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 19, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(52): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-02-17 22:18:42 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '.' ~ APPPATH/views/questions/vQuestionsAsk.php [ 124 ]
2012-02-17 22:18:42 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '.' ~ APPPATH/views/questions/vQuestionsAsk.php [ 124 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-02-17 23:13:52 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '>' ~ APPPATH/views/questions/vQuestionsAsk.php [ 86 ]
2012-02-17 23:13:52 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '>' ~ APPPATH/views/questions/vQuestionsAsk.php [ 86 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-02-17 23:30:15 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '/' ~ APPPATH/views/questions/vQuestionAll.php [ 135 ]
2012-02-17 23:30:15 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '/' ~ APPPATH/views/questions/vQuestionAll.php [ 135 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-02-17 23:30:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-17 23:30:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-17 23:30:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-17 23:30:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-17 23:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-17 23:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-17 23:30:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-17 23:30:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-17 23:30:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-17 23:30:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-17 23:31:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-17 23:31:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-17 23:31:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-17 23:31:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-17 23:31:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-17 23:31:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-17 23:31:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-17 23:31:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-17 23:31:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-17 23:31:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-17 23:31:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-17 23:31:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-17 23:35:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-17 23:35:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-17 23:35:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-17 23:35:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-17 23:35:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-17 23:35:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-17 23:35:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-17 23:35:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}