<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-02-16 11:18:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 11:18:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 11:20:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 11:20:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 11:20:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 11:20:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 11:20:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 11:20:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 11:21:26 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 11:21:26 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 11:21:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 11:21:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 11:21:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 11:21:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 11:22:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 11:22:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 11:22:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 11:22:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 11:23:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 11:23:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 11:28:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/category/all/category/3 ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 11:28:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/category/all/category/3 ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 11:28:25 --- ERROR: ErrorException [ 8 ]: Undefined index: qtype ~ APPPATH/classes/model/mquestions.php [ 469 ]
2012-02-16 11:28:25 --- STRACE: ErrorException [ 8 ]: Undefined index: qtype ~ APPPATH/classes/model/mquestions.php [ 469 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(469): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 469, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(153): Model_Mquestions->getAllQuestions(Array)
#2 [internal function]: Controller_Questions_Questions->action_category()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-02-16 11:28:32 --- ERROR: ErrorException [ 8 ]: Undefined index: qtype ~ APPPATH/classes/model/mquestions.php [ 469 ]
2012-02-16 11:28:32 --- STRACE: ErrorException [ 8 ]: Undefined index: qtype ~ APPPATH/classes/model/mquestions.php [ 469 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(469): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 469, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(153): Model_Mquestions->getAllQuestions(Array)
#2 [internal function]: Controller_Questions_Questions->action_category()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-02-16 11:29:52 --- ERROR: ErrorException [ 8 ]: Undefined index: user_id ~ APPPATH/classes/model/mquestions.php [ 543 ]
2012-02-16 11:29:52 --- STRACE: ErrorException [ 8 ]: Undefined index: user_id ~ APPPATH/classes/model/mquestions.php [ 543 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(543): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 543, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(154): Model_Mquestions->getAllQuestions(Array)
#2 [internal function]: Controller_Questions_Questions->action_category()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-02-16 11:30:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/category/all/category/3 ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 11:30:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/category/all/category/3 ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 11:32:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 11:32:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 11:35:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 11:35:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 11:35:23 --- ERROR: ErrorException [ 8 ]: Undefined index: cat_id ~ APPPATH/classes/model/mquestions.php [ 535 ]
2012-02-16 11:35:23 --- STRACE: ErrorException [ 8 ]: Undefined index: cat_id ~ APPPATH/classes/model/mquestions.php [ 535 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(535): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 535, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(192): Model_Mquestions->getAllQuestions(Array)
#2 [internal function]: Controller_Questions_Questions->action_all()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-02-16 11:43:48 --- ERROR: ErrorException [ 8 ]: Undefined index: cat_id ~ APPPATH/classes/model/mquestions.php [ 535 ]
2012-02-16 11:43:48 --- STRACE: ErrorException [ 8 ]: Undefined index: cat_id ~ APPPATH/classes/model/mquestions.php [ 535 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(535): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 535, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(192): Model_Mquestions->getAllQuestions(Array)
#2 [internal function]: Controller_Questions_Questions->action_all()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-02-16 12:03:29 --- ERROR: ErrorException [ 8 ]: Undefined index: cat_id ~ APPPATH/classes/model/mquestions.php [ 535 ]
2012-02-16 12:03:29 --- STRACE: ErrorException [ 8 ]: Undefined index: cat_id ~ APPPATH/classes/model/mquestions.php [ 535 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(535): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 535, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(192): Model_Mquestions->getAllQuestions(Array)
#2 [internal function]: Controller_Questions_Questions->action_all()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-02-16 12:22:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:22:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:22:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:22:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:22:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:22:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:22:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:22:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:22:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:22:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:22:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:22:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:23:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:23:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:26:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:26:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:26:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:26:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:26:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:26:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:26:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:26:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:26:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:26:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:26:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:26:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:26:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:26:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:27:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:27:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:27:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:27:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:28:09 --- ERROR: ErrorException [ 8 ]: Undefined index: cat_id ~ APPPATH/classes/model/mquestions.php [ 544 ]
2012-02-16 12:28:09 --- STRACE: ErrorException [ 8 ]: Undefined index: cat_id ~ APPPATH/classes/model/mquestions.php [ 544 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(544): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 544, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(190): Model_Mquestions->getAllQuestions(Array)
#2 [internal function]: Controller_Questions_Questions->action_all()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-02-16 12:28:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:28:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:29:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:29:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:29:03 --- ERROR: ErrorException [ 8 ]: Undefined index: cat_id ~ APPPATH/classes/model/mquestions.php [ 544 ]
2012-02-16 12:29:03 --- STRACE: ErrorException [ 8 ]: Undefined index: cat_id ~ APPPATH/classes/model/mquestions.php [ 544 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(544): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 544, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(190): Model_Mquestions->getAllQuestions(Array)
#2 [internal function]: Controller_Questions_Questions->action_all()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-02-16 12:29:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:29:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:29:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:29:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:29:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:29:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:30:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:30:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:30:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:30:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:30:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:30:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:30:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:30:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:30:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:30:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:30:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:30:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:30:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:30:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:30:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:30:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:30:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:30:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:30:32 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:30:32 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:30:52 --- ERROR: ErrorException [ 8 ]: Undefined index: cat_id ~ APPPATH/classes/model/mquestions.php [ 544 ]
2012-02-16 12:30:52 --- STRACE: ErrorException [ 8 ]: Undefined index: cat_id ~ APPPATH/classes/model/mquestions.php [ 544 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(544): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 544, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(190): Model_Mquestions->getAllQuestions(Array)
#2 [internal function]: Controller_Questions_Questions->action_all()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-02-16 12:31:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:31:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:31:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:31:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:31:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:31:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:32:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:32:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:32:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:32:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:32:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:32:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:33:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:33:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:33:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:33:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:34:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:34:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:34:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:34:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:34:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:34:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:34:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:34:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:34:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:34:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:34:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:34:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:35:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:35:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:35:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:35:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:35:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:35:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:35:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:35:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:36:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:36:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:36:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:36:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:36:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:36:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:36:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:36:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:36:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:36:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:36:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:36:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:36:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:36:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:36:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:36:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:36:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:36:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:36:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:36:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:37:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:37:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:37:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:37:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:37:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:37:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:37:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:37:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:37:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:37:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:40:34 --- ERROR: ErrorException [ 8 ]: Undefined index: per_page ~ APPPATH/classes/model/mquestions.php [ 467 ]
2012-02-16 12:40:34 --- STRACE: ErrorException [ 8 ]: Undefined index: per_page ~ APPPATH/classes/model/mquestions.php [ 467 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(467): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 467, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(190): Model_Mquestions->getAllQuestions(Array)
#2 [internal function]: Controller_Questions_Questions->action_all()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-02-16 12:45:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:45:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:45:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:45:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:50:56 --- ERROR: ErrorException [ 8 ]: Undefined variable: countQuestions ~ APPPATH/classes/model/mquestions.php [ 578 ]
2012-02-16 12:50:56 --- STRACE: ErrorException [ 8 ]: Undefined variable: countQuestions ~ APPPATH/classes/model/mquestions.php [ 578 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(578): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 578, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(190): Model_Mquestions->getAllQuestions(Array)
#2 [internal function]: Controller_Questions_Questions->action_all()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-02-16 12:51:13 --- ERROR: ErrorException [ 8 ]: Undefined variable: tblTitle ~ APPPATH/views/questions/vQuestionAll.php [ 57 ]
2012-02-16 12:51:13 --- STRACE: ErrorException [ 8 ]: Undefined variable: tblTitle ~ APPPATH/views/questions/vQuestionAll.php [ 57 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionAll.php(57): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 57, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-02-16 12:52:00 --- ERROR: ErrorException [ 8 ]: Undefined variable: lnk ~ APPPATH/views/questions/vQuestionAll.php [ 117 ]
2012-02-16 12:52:00 --- STRACE: ErrorException [ 8 ]: Undefined variable: lnk ~ APPPATH/views/questions/vQuestionAll.php [ 117 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionAll.php(117): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 117, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-02-16 12:52:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:52:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:52:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:52:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:52:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:52:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:52:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:52:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:52:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:52:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:52:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:52:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:52:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:52:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:52:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:52:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:52:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:52:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:54:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:54:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:54:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:54:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:59:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:59:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:59:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:59:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 12:59:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 12:59:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 13:00:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 13:00:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 13:00:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 13:00:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 13:05:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 13:05:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 13:05:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 13:05:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 13:05:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 13:05:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 13:05:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 13:05:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 13:05:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 13:05:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 13:11:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 13:11:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 13:11:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 13:11:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 13:11:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 13:11:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 13:11:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 13:11:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 13:11:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 13:11:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 17:31:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 17:31:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 17:31:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 17:31:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 17:31:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 17:31:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 17:31:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 17:31:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 17:31:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 17:31:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 18:53:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 18:53:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 18:53:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 18:53:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 19:02:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 19:02:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 19:02:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 19:02:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 19:02:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 19:02:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 19:11:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 19:11:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 19:11:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 19:11:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 19:12:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 19:12:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 19:40:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 19:40:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 19:44:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 19:44:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 19:44:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 19:44:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 19:44:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 19:44:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 19:44:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 19:44:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 20:03:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 20:03:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 20:03:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 20:03:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 20:03:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 20:03:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 20:03:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 20:03:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 20:03:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 20:03:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 20:05:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 20:05:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 20:05:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 20:05:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 20:06:25 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 20:06:25 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/bootstrap/bootstrap.js ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 20:21:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 20:21:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 20:21:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 20:21:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 20:24:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 20:24:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-16 20:24:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-16 20:24:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}