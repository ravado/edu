<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-02-18 00:18:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-18 00:18:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-18 00:18:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-18 00:18:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-18 00:18:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-18 00:18:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-18 00:18:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-18 00:18:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-18 00:18:58 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-18 00:18:58 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-18 00:18:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-18 00:18:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-18 00:19:00 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-18 00:19:00 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-18 00:19:02 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-18 00:19:02 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-18 22:02:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-18 22:02:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-18 22:02:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-18 22:02:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-18 22:02:18 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-18 22:02:18 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-18 22:50:04 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/classes/controller/questions/questions.php [ 139 ]
2012-02-18 22:50:04 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/classes/controller/questions/questions.php [ 139 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(139): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 139, Array)
#1 [internal function]: Controller_Questions_Questions->action_question()
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-02-18 22:50:51 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/classes/controller/questions/questions.php [ 139 ]
2012-02-18 22:50:51 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/classes/controller/questions/questions.php [ 139 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(139): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 139, Array)
#1 [internal function]: Controller_Questions_Questions->action_question()
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-02-18 22:51:31 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'vote.value' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `vote`.`value` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = Array AND `questions_cat`.`id_question` != 143) LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-18 22:51:31 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'vote.value' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `vote`.`value` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = Array AND `questions_cat`.`id_question` != 143) LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(609): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(142): Model_Mquestions->getSimiliarQuestions('143', Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-18 22:52:44 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'vote.value' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `vote`.`value` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 1 AND `questions_cat`.`id_question` != 143) LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-18 22:52:44 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'vote.value' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `vote`.`value` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 1 AND `questions_cat`.`id_question` != 143) LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(609): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(142): Model_Mquestions->getSimiliarQuestions('143', '1')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-18 22:52:51 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'vote.value' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `vote`.`value` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 1 AND `questions_cat`.`id_question` != 143) LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-18 22:52:51 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'vote.value' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `vote`.`value` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 1 AND `questions_cat`.`id_question` != 143) LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(609): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(142): Model_Mquestions->getSimiliarQuestions('143', '1')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-18 22:53:11 --- ERROR: ErrorException [ 8 ]: Undefined variable: similiar ~ APPPATH/views/questions/vQuestionOne.php [ 25 ]
2012-02-18 22:53:11 --- STRACE: ErrorException [ 8 ]: Undefined variable: similiar ~ APPPATH/views/questions/vQuestionOne.php [ 25 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(25): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 25, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(52): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-02-18 23:08:06 --- ERROR: ErrorException [ 8 ]: Undefined variable: similiar ~ APPPATH/views/questions/vQuestionOne.php [ 34 ]
2012-02-18 23:08:06 --- STRACE: ErrorException [ 8 ]: Undefined variable: similiar ~ APPPATH/views/questions/vQuestionOne.php [ 34 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(34): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 34, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(52): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-02-18 23:08:20 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestionOne.php [ 34 ]
2012-02-18 23:08:20 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestionOne.php [ 34 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(34): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 34, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(52): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-02-18 23:17:06 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::orderby() ~ APPPATH/classes/model/mquestions.php [ 610 ]
2012-02-18 23:17:06 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::orderby() ~ APPPATH/classes/model/mquestions.php [ 610 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-02-18 23:17:36 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::orderby() ~ APPPATH/classes/model/mquestions.php [ 610 ]
2012-02-18 23:17:36 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::orderby() ~ APPPATH/classes/model/mquestions.php [ 610 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-02-18 23:18:13 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::orderby() ~ APPPATH/classes/model/mquestions.php [ 610 ]
2012-02-18 23:18:13 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::orderby() ~ APPPATH/classes/model/mquestions.php [ 610 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-02-18 23:18:37 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'RAND() LIMIT 5' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 9 AND `questions_cat`.`id_question` != 146) WHERE `closed` = '0' ORDER BY `` RAND() LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-18 23:18:37 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'RAND() LIMIT 5' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 9 AND `questions_cat`.`id_question` != 146) WHERE `closed` = '0' ORDER BY `` RAND() LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(610): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(140): Model_Mquestions->getSimiliarQuestions('146', '9')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-18 23:19:00 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'RAND() LIMIT 5' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 9 AND `questions_cat`.`id_question` != 146) WHERE `closed` = '0' ORDER BY `` RAND() LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-18 23:19:00 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'RAND() LIMIT 5' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 9 AND `questions_cat`.`id_question` != 146) WHERE `closed` = '0' ORDER BY `` RAND() LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(610): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(140): Model_Mquestions->getSimiliarQuestions('146', '9')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-18 23:21:07 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '57426448 LIMIT 5' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 9 AND `questions_cat`.`id_question` != 146) WHERE `closed` = '0' ORDER BY `` 57426448 LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-18 23:21:07 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '57426448 LIMIT 5' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 9 AND `questions_cat`.`id_question` != 146) WHERE `closed` = '0' ORDER BY `` 57426448 LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(610): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(140): Model_Mquestions->getSimiliarQuestions('146', '9')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-18 23:21:19 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'RAND() LIMIT 5' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 9 AND `questions_cat`.`id_question` != 146) WHERE `closed` = '0' ORDER BY `` RAND() LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-18 23:21:19 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'RAND() LIMIT 5' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 9 AND `questions_cat`.`id_question` != 146) WHERE `closed` = '0' ORDER BY `` RAND() LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(610): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(140): Model_Mquestions->getSimiliarQuestions('146', '9')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-18 23:22:08 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'RAND LIMIT 5' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 9 AND `questions_cat`.`id_question` != 146) WHERE `closed` = '0' ORDER BY `` RAND LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-18 23:22:08 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'RAND LIMIT 5' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 9 AND `questions_cat`.`id_question` != 146) WHERE `closed` = '0' ORDER BY `` RAND LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(610): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(140): Model_Mquestions->getSimiliarQuestions('146', '9')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-18 23:22:16 --- ERROR: ErrorException [ 8 ]: Use of undefined constant _ - assumed '_' ~ APPPATH/classes/model/mquestions.php [ 610 ]
2012-02-18 23:22:16 --- STRACE: ErrorException [ 8 ]: Use of undefined constant _ - assumed '_' ~ APPPATH/classes/model/mquestions.php [ 610 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(610): Kohana_Core::error_handler(8, 'Use of undefine...', '/Users/ravado/S...', 610, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(140): Model_Mquestions->getSimiliarQuestions('146', '9')
#2 [internal function]: Controller_Questions_Questions->action_question()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-02-18 23:22:27 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'RAND' in 'order clause' [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 9 AND `questions_cat`.`id_question` != 146) WHERE `closed` = '0' ORDER BY `RAND` LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-18 23:22:27 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'RAND' in 'order clause' [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 9 AND `questions_cat`.`id_question` != 146) WHERE `closed` = '0' ORDER BY `RAND` LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(610): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(140): Model_Mquestions->getSimiliarQuestions('146', '9')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-18 23:23:22 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'RAND LIMIT 5' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 9 AND `questions_cat`.`id_question` != 146) WHERE `closed` = '0' ORDER BY `questions_cat`.`id_question` RAND LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-18 23:23:22 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'RAND LIMIT 5' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 9 AND `questions_cat`.`id_question` != 146) WHERE `closed` = '0' ORDER BY `questions_cat`.`id_question` RAND LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(610): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(140): Model_Mquestions->getSimiliarQuestions('146', '9')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-18 23:26:45 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestionOne.php [ 25 ]
2012-02-18 23:26:45 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestionOne.php [ 25 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(25): Kohana_Core::error_handler(2, 'Invalid argumen...', '/Users/ravado/S...', 25, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(52): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-02-18 23:27:37 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_cat.id_question' in 'field list' [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` WHERE `closed` = '0' LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-18 23:27:37 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_cat.id_question' in 'field list' [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` WHERE `closed` = '0' LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(622): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(140): Model_Mquestions->getSimiliarQuestions('146', '9')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-18 23:27:50 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_cat.id_question' in 'field list' [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` WHERE `closed` = '0' LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-18 23:27:50 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_cat.id_question' in 'field list' [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` WHERE `closed` = '0' LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(622): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(140): Model_Mquestions->getSimiliarQuestions('146', '9')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-18 23:28:04 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_cat.id_question' in 'field list' [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question` FROM `questions` WHERE `closed` = '0' LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-18 23:28:04 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_cat.id_question' in 'field list' [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question` FROM `questions` WHERE `closed` = '0' LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(620): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(140): Model_Mquestions->getSimiliarQuestions('146', '9')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-18 23:45:23 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::orderby() ~ APPPATH/classes/model/mquestions.php [ 610 ]
2012-02-18 23:45:23 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::orderby() ~ APPPATH/classes/model/mquestions.php [ 610 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-02-18 23:45:34 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'RAND() LIMIT 5' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 101 AND `questions_cat`.`id_question` != 144) WHERE `closed` = '0' ORDER BY `` RAND() LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-18 23:45:34 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'RAND() LIMIT 5' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 101 AND `questions_cat`.`id_question` != 144) WHERE `closed` = '0' ORDER BY `` RAND() LIMIT 5 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(610): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(140): Model_Mquestions->getSimiliarQuestions('144', '101')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-18 23:46:02 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'RAND()' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 101 AND `questions_cat`.`id_question` != 144) WHERE `closed` = '0' ORDER BY `` RAND() ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-18 23:46:02 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'RAND()' at line 1 [ SELECT `questions_cat`.`id_question`, `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions_cat`.`id_subcategory` FROM `questions` JOIN `questions_cat` ON (`questions_cat`.`id_subcategory` = 101 AND `questions_cat`.`id_question` != 144) WHERE `closed` = '0' ORDER BY `` RAND() ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(609): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(140): Model_Mquestions->getSimiliarQuestions('144', '101')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}