<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-02-21 11:11:33 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 [ DELETE FROM `questions` WHERE `id_question` = ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-21 11:11:33 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 [ DELETE FROM `questions` WHERE `id_question` = ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(4, 'DELETE FROM `qu...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(642): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(60): Model_Mquestions->delQuestionById('')
#3 [internal function]: Controller_Adm_Ahid->action_delQuestionById()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-21 11:49:46 --- ERROR: Database_Exception [ 1146 ]: Table 'edu.user' doesn't exist [ SELECT `questions_and_answers`.`id_questions`, `questions_and_answers`.`id_answers`, `answers`.`id_answer`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`best`, `answers`.`public_date`, `users`.`id`, `users`.`username` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) JOIN `user` ON (`users`.`id` = `answers`.`id_user`) WHERE `questions_and_answers`.`id_questions` = 150 AND `questions_and_answers`.`id_answers` IS NOT NULL ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-21 11:49:46 --- STRACE: Database_Exception [ 1146 ]: Table 'edu.user' doesn't exist [ SELECT `questions_and_answers`.`id_questions`, `questions_and_answers`.`id_answers`, `answers`.`id_answer`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`best`, `answers`.`public_date`, `users`.`id`, `users`.`username` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) JOIN `user` ON (`users`.`id` = `answers`.`id_user`) WHERE `questions_and_answers`.`id_questions` = 150 AND `questions_and_answers`.`id_answers` IS NOT NULL ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(695): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(60): Model_Mquestions->getQuestionAllById('150')
#3 [internal function]: Controller_Adm_Ahid->action_getQuestionAllById()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-21 19:06:26 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 [ SELECT `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions`.`full` FROM `questions` WHERE `id_question` = ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-21 19:06:26 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 [ SELECT `questions`.`title`, `questions`.`closed`, `questions`.`id_question`, `questions`.`full` FROM `questions` WHERE `id_question` = ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(678): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(60): Model_Mquestions->getQuestionAllById('')
#3 [internal function]: Controller_Adm_Ahid->action_getQuestionAllById()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-21 19:21:54 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL adm/ahid/delanswersbyid was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-02-21 19:21:54 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL adm/ahid/delanswersbyid was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-02-21 19:24:28 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL adm/ahid/delanswersbyid was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-02-21 19:24:28 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL adm/ahid/delanswersbyid was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-02-21 19:25:13 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL adm/ahid/delanswersbyid was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-02-21 19:25:13 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL adm/ahid/delanswersbyid was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-02-21 19:31:56 --- ERROR: ErrorException [ 8 ]: Uninitialized string offset: 3 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
2012-02-21 19:31:56 --- STRACE: ErrorException [ 8 ]: Uninitialized string offset: 3 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(91): Kohana_Core::error_handler(8, 'Uninitialized s...', '/Users/ravado/S...', 91, Array)
#1 [internal function]: Controller_Adm_Ahid->action_delAnswersById()
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-02-21 19:35:40 --- ERROR: ErrorException [ 2 ]: json_decode() expects parameter 1 to be string, array given ~ APPPATH/classes/controller/adm/ahid.php [ 82 ]
2012-02-21 19:35:40 --- STRACE: ErrorException [ 2 ]: json_decode() expects parameter 1 to be string, array given ~ APPPATH/classes/controller/adm/ahid.php [ 82 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'json_decode() e...', '/Users/ravado/S...', 82, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(82): json_decode(Array, true)
#2 [internal function]: Controller_Adm_Ahid->action_delAnswersById()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-02-21 19:36:36 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
2012-02-21 19:36:36 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(91): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 91, Array)
#1 [internal function]: Controller_Adm_Ahid->action_delAnswersById()
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-02-21 19:51:12 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
2012-02-21 19:51:12 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(91): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 91, Array)
#1 [internal function]: Controller_Adm_Ahid->action_delAnswersById()
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-02-21 19:52:20 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
2012-02-21 19:52:20 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(91): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 91, Array)
#1 [internal function]: Controller_Adm_Ahid->action_delAnswersById()
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-02-21 19:52:23 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
2012-02-21 19:52:23 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(91): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 91, Array)
#1 [internal function]: Controller_Adm_Ahid->action_delAnswersById()
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-02-21 19:52:51 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
2012-02-21 19:52:51 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(91): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 91, Array)
#1 [internal function]: Controller_Adm_Ahid->action_delAnswersById()
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-02-21 19:53:09 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
2012-02-21 19:53:09 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(91): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 91, Array)
#1 [internal function]: Controller_Adm_Ahid->action_delAnswersById()
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-02-21 19:53:47 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
2012-02-21 19:53:47 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/adm/ahid.php [ 91 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(91): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 91, Array)
#1 [internal function]: Controller_Adm_Ahid->action_delAnswersById()
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-02-21 20:19:00 --- ERROR: ErrorException [ 8 ]: Undefined variable: answersId ~ APPPATH/classes/controller/adm/ahid.php [ 83 ]
2012-02-21 20:19:00 --- STRACE: ErrorException [ 8 ]: Undefined variable: answersId ~ APPPATH/classes/controller/adm/ahid.php [ 83 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(83): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 83, Array)
#1 [internal function]: Controller_Adm_Ahid->action_delAnswersById()
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-02-21 20:29:18 --- ERROR: Database_Exception [ 1054 ]: Unknown column '13question_id' in 'where clause' [ DELETE FROM `answers` WHERE `id_answer` = 13question_id=144 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-21 20:29:18 --- STRACE: Database_Exception [ 1054 ]: Unknown column '13question_id' in 'where clause' [ DELETE FROM `answers` WHERE `id_answer` = 13question_id=144 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(4, 'DELETE FROM `an...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(711): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(83): Model_Mquestions->delAnswersById(Array)
#3 [internal function]: Controller_Adm_Ahid->action_delAnswersById()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-21 20:30:04 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'question_id' in 'where clause' [ DELETE FROM `answers` WHERE `id_answer` = question_id=144 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-21 20:30:04 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'question_id' in 'where clause' [ DELETE FROM `answers` WHERE `id_answer` = question_id=144 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(4, 'DELETE FROM `an...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(711): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(83): Model_Mquestions->delAnswersById(Array)
#3 [internal function]: Controller_Adm_Ahid->action_delAnswersById()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-21 20:32:02 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'question_id=144' at line 1 [ DELETE FROM `answers` WHERE `id_answer` = 14; question_id=144 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-21 20:32:02 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'question_id=144' at line 1 [ DELETE FROM `answers` WHERE `id_answer` = 14; question_id=144 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(4, 'DELETE FROM `an...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(711): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(83): Model_Mquestions->delAnswersById(Array)
#3 [internal function]: Controller_Adm_Ahid->action_delAnswersById()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-21 21:25:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-21 21:25:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-21 21:25:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-21 21:25:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}