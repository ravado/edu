<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-02-20 18:37:39 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-20 18:37:39 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-20 18:37:40 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-20 18:37:40 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-20 18:37:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-20 18:37:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-20 18:37:43 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-20 18:37:43 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-20 18:37:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-20 18:37:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-20 21:00:46 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_id' in 'where clause' [ SELECT `questions`.`title`, `questions`.`closed`, `questions`.`id_question` FROM `questions` WHERE `questions_id` = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-20 21:00:46 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_id' in 'where clause' [ SELECT `questions`.`title`, `questions`.`closed`, `questions`.`id_question` FROM `questions` WHERE `questions_id` = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(630): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(49): Model_Mquestions->getQuestionById('1')
#3 [internal function]: Controller_Adm_Ahid->action_getQuestionById()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-20 21:02:43 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_id' in 'where clause' [ SELECT `questions`.`title`, `questions`.`closed`, `questions`.`id_question` FROM `questions` WHERE `questions_id` = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-20 21:02:43 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_id' in 'where clause' [ SELECT `questions`.`title`, `questions`.`closed`, `questions`.`id_question` FROM `questions` WHERE `questions_id` = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(630): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(49): Model_Mquestions->getQuestionById('1')
#3 [internal function]: Controller_Adm_Ahid->action_getQuestionById()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-20 21:03:40 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id_questions' in 'where clause' [ SELECT `questions`.`title`, `questions`.`closed`, `questions`.`id_question` FROM `questions` WHERE `id_questions` = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-20 21:03:40 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id_questions' in 'where clause' [ SELECT `questions`.`title`, `questions`.`closed`, `questions`.`id_question` FROM `questions` WHERE `id_questions` = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(630): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(49): Model_Mquestions->getQuestionById('1')
#3 [internal function]: Controller_Adm_Ahid->action_getQuestionById()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-20 23:31:55 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/questions/questions.php [ 139 ]
2012-02-20 23:31:55 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/questions/questions.php [ 139 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(139): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 139, Array)
#1 [internal function]: Controller_Questions_Questions->action_question()
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-02-20 23:33:28 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/questions/questions.php [ 139 ]
2012-02-20 23:33:28 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/questions/questions.php [ 139 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(139): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 139, Array)
#1 [internal function]: Controller_Questions_Questions->action_question()
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-02-20 23:34:46 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/questions/questions.php [ 139 ]
2012-02-20 23:34:46 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/controller/questions/questions.php [ 139 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(139): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 139, Array)
#1 [internal function]: Controller_Questions_Questions->action_question()
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-02-20 23:36:31 --- ERROR: ErrorException [ 8 ]: Undefined variable: similar ~ APPPATH/views/questions/vQuestionOne.php [ 33 ]
2012-02-20 23:36:31 --- STRACE: ErrorException [ 8 ]: Undefined variable: similar ~ APPPATH/views/questions/vQuestionOne.php [ 33 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(33): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 33, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(52): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-02-20 23:37:49 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestionOne.php [ 102 ]
2012-02-20 23:37:49 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestionOne.php [ 102 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(102): Kohana_Core::error_handler(2, 'Invalid argumen...', '/Users/ravado/S...', 102, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(52): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-02-20 23:42:28 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'Array' in 'where clause' [ DELETE FROM `answers` WHERE `id_answer` = Array ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-02-20 23:42:28 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'Array' in 'where clause' [ DELETE FROM `answers` WHERE `id_answer` = Array ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(4, 'DELETE FROM `an...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(661): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/adm/ahid.php(60): Model_Mquestions->delQuestionById('143')
#3 [internal function]: Controller_Adm_Ahid->action_delQuestionById()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Adm_Ahid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-02-20 23:58:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL adm/vio/del was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-02-20 23:58:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL adm/vio/del was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}