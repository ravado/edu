<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-02-15 19:32:36 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 19:32:36 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-15 19:32:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 19:32:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-15 19:34:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 19:34:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-15 19:34:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 19:34:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-15 19:34:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 19:34:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-15 19:38:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 19:38:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-15 19:42:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 19:42:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-15 19:42:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 19:42:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-15 19:42:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 19:42:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-15 19:42:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 19:42:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-15 19:43:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/opened was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-02-15 19:43:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/opened was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-02-15 23:10:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 23:10:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-15 23:11:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 23:11:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-15 23:12:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 23:12:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-15 23:12:14 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 23:12:14 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-15 23:14:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 23:14:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-02-15 23:15:24 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-02-15 23:15:24 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/stfile/img/favicon.ico ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}