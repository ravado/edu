<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-01-20 00:02:50 --- ERROR: ErrorException [ 1 ]: Call to undefined function select() ~ APPPATH/classes/model/mquestions.php [ 22 ]
2012-01-20 00:02:50 --- STRACE: ErrorException [ 1 ]: Call to undefined function select() ~ APPPATH/classes/model/mquestions.php [ 22 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-01-20 00:03:01 --- ERROR: Database_Exception [ 1248 ]: Every derived table must have its own alias [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN (SELECT `id_subcategory` FROM `subcategory` WHERE `id_subcategory` = '1') ON (`questions`.`id_user` = `users`.`id`) LEFT JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) LEFT JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `questions`.`public_date` DESC ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-20 00:03:01 --- STRACE: Database_Exception [ 1248 ]: Every derived table must have its own alias [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN (SELECT `id_subcategory` FROM `subcategory` WHERE `id_subcategory` = '1') ON (`questions`.`id_user` = `users`.`id`) LEFT JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) LEFT JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `questions`.`public_date` DESC ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(26): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-20 00:03:28 --- ERROR: Database_Exception [ 1248 ]: Every derived table must have its own alias [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN (SELECT `subcategory`.`id_subcategory` FROM `subcategory` WHERE `subcategory`.`id_subcategory` = '1') ON (`questions`.`id_user` = `users`.`id`) LEFT JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) LEFT JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `questions`.`public_date` DESC ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-20 00:03:28 --- STRACE: Database_Exception [ 1248 ]: Every derived table must have its own alias [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN (SELECT `subcategory`.`id_subcategory` FROM `subcategory` WHERE `subcategory`.`id_subcategory` = '1') ON (`questions`.`id_user` = `users`.`id`) LEFT JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) LEFT JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `questions`.`public_date` DESC ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(26): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-20 00:04:08 --- ERROR: Database_Exception [ 1248 ]: Every derived table must have its own alias [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN (SELECT `vote`.`id_vote` FROM `vote` WHERE `vote`.`id_vote` = '1') ON (`questions`.`id_user` = `users`.`id`) LEFT JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) LEFT JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `questions`.`public_date` DESC ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-20 00:04:08 --- STRACE: Database_Exception [ 1248 ]: Every derived table must have its own alias [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN (SELECT `vote`.`id_vote` FROM `vote` WHERE `vote`.`id_vote` = '1') ON (`questions`.`id_user` = `users`.`id`) LEFT JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) LEFT JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `questions`.`public_date` DESC ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(26): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-20 20:14:43 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:14:43 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:15:03 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:15:03 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:15:42 --- ERROR: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/classes/model/mquestions.php [ 25 ]
2012-01-20 20:15:42 --- STRACE: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/classes/model/mquestions.php [ 25 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(25): Kohana_Core::error_handler(2, 'Illegal offset ...', '/Users/ravado/S...', 25, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:15:57 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:15:57 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:19:20 --- ERROR: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 31 ]
2012-01-20 20:19:20 --- STRACE: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 31 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(31): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 31, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:20:00 --- ERROR: ErrorException [ 8 ]: Undefined offset: -1 ~ APPPATH/classes/model/mquestions.php [ 31 ]
2012-01-20 20:20:00 --- STRACE: ErrorException [ 8 ]: Undefined offset: -1 ~ APPPATH/classes/model/mquestions.php [ 31 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(31): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 31, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:20:11 --- ERROR: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 31 ]
2012-01-20 20:20:11 --- STRACE: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 31 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(31): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 31, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:20:13 --- ERROR: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 31 ]
2012-01-20 20:20:13 --- STRACE: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 31 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(31): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 31, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:21:06 --- ERROR: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/classes/model/mquestions.php [ 31 ]
2012-01-20 20:21:06 --- STRACE: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/classes/model/mquestions.php [ 31 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(31): Kohana_Core::error_handler(2, 'Illegal offset ...', '/Users/ravado/S...', 31, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:21:09 --- ERROR: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 31 ]
2012-01-20 20:21:09 --- STRACE: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 31 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(31): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 31, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:21:59 --- ERROR: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions_cat` JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) WHERE `questions_cat`.`id_question` = ('144', 'как в разных странах встречают новый год', '5', '2012-01-19 22:44:48', '0', 'ravado') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-20 20:21:59 --- STRACE: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions_cat` JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) WHERE `questions_cat`.`id_question` = ('144', 'как в разных странах встречают новый год', '5', '2012-01-19 22:44:48', '0', 'ravado') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(32): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-20 20:22:20 --- ERROR: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 31 ]
2012-01-20 20:22:20 --- STRACE: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 31 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(31): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 31, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:22:22 --- ERROR: ErrorException [ 8 ]: Undefined index: id_questions ~ APPPATH/classes/model/mquestions.php [ 31 ]
2012-01-20 20:22:22 --- STRACE: ErrorException [ 8 ]: Undefined index: id_questions ~ APPPATH/classes/model/mquestions.php [ 31 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(31): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 31, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:22:28 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:22:28 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:22:34 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:22:34 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:23:04 --- ERROR: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 32 ]
2012-01-20 20:23:04 --- STRACE: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 32 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(32): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 32, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:23:10 --- ERROR: ErrorException [ 8 ]: Undefined offset: -1 ~ APPPATH/classes/model/mquestions.php [ 32 ]
2012-01-20 20:23:10 --- STRACE: ErrorException [ 8 ]: Undefined offset: -1 ~ APPPATH/classes/model/mquestions.php [ 32 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(32): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 32, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:23:14 --- ERROR: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 32 ]
2012-01-20 20:23:14 --- STRACE: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 32 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(32): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 32, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:23:16 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:23:16 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:23:21 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:23:21 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:24:12 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:24:12 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:25:09 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:25:09 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:25:54 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:25:54 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:26:15 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:26:15 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:26:25 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:26:25 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:26:32 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:26:32 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:26:34 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:26:34 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:26:37 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:26:37 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:26:39 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:26:39 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:26:55 --- ERROR: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions_cat` JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) WHERE `questions_cat`.`id_question` = ('144', 'как в разных странах встречают новый год', '5', '2012-01-19 22:44:48', '0', 'ravado') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-20 20:26:55 --- STRACE: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions_cat` JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) WHERE `questions_cat`.`id_question` = ('144', 'как в разных странах встречают новый год', '5', '2012-01-19 22:44:48', '0', 'ravado') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(38): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-20 20:27:10 --- ERROR: ErrorException [ 8 ]: Undefined index: id_question ~ APPPATH/classes/model/mquestions.php [ 37 ]
2012-01-20 20:27:10 --- STRACE: ErrorException [ 8 ]: Undefined index: id_question ~ APPPATH/classes/model/mquestions.php [ 37 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(37): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 37, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:27:28 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:27:28 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:27:34 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:27:34 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:27:38 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:27:38 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:27:41 --- ERROR: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 37 ]
2012-01-20 20:27:41 --- STRACE: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 37 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(37): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 37, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:27:45 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:27:45 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:27:48 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:27:48 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:27:52 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:27:52 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:27:56 --- ERROR: ErrorException [ 8 ]: Undefined offset: -1 ~ APPPATH/classes/model/mquestions.php [ 37 ]
2012-01-20 20:27:56 --- STRACE: ErrorException [ 8 ]: Undefined offset: -1 ~ APPPATH/classes/model/mquestions.php [ 37 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(37): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 37, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:28:02 --- ERROR: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 37 ]
2012-01-20 20:28:02 --- STRACE: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 37 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(37): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 37, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:28:15 --- ERROR: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 37 ]
2012-01-20 20:28:15 --- STRACE: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 37 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(37): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 37, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:28:17 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
2012-01-20 20:28:17 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestions.php [ 213 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(213): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 213, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:28:20 --- ERROR: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 37 ]
2012-01-20 20:28:20 --- STRACE: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 37 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(37): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 37, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:28:59 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:28:59 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:29:40 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:29:40 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:30:13 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:30:13 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:30:27 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:30:27 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:30:55 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:30:55 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:36:43 --- ERROR: ErrorException [ 2 ]: array_push() expects at least 2 parameters, 1 given ~ APPPATH/classes/model/mquestions.php [ 40 ]
2012-01-20 20:36:43 --- STRACE: ErrorException [ 2 ]: array_push() expects at least 2 parameters, 1 given ~ APPPATH/classes/model/mquestions.php [ 40 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_push() ex...', '/Users/ravado/S...', 40, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(40): array_push(Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-20 20:37:21 --- ERROR: ErrorException [ 2 ]: array_push() expects parameter 1 to be array, null given ~ APPPATH/classes/model/mquestions.php [ 40 ]
2012-01-20 20:37:21 --- STRACE: ErrorException [ 2 ]: array_push() expects parameter 1 to be array, null given ~ APPPATH/classes/model/mquestions.php [ 40 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_push() ex...', '/Users/ravado/S...', 40, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(40): array_push(NULL, Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-20 20:38:17 --- ERROR: ErrorException [ 2 ]: array_push() expects parameter 1 to be array, string given ~ APPPATH/classes/model/mquestions.php [ 41 ]
2012-01-20 20:38:17 --- STRACE: ErrorException [ 2 ]: array_push() expects parameter 1 to be array, string given ~ APPPATH/classes/model/mquestions.php [ 41 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_push() ex...', '/Users/ravado/S...', 41, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(41): array_push('', Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-20 20:38:24 --- ERROR: ErrorException [ 2 ]: array_push() expects parameter 1 to be array, integer given ~ APPPATH/classes/model/mquestions.php [ 41 ]
2012-01-20 20:38:24 --- STRACE: ErrorException [ 2 ]: array_push() expects parameter 1 to be array, integer given ~ APPPATH/classes/model/mquestions.php [ 41 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_push() ex...', '/Users/ravado/S...', 41, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(41): array_push(0, Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-20 20:38:35 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/model/mquestions.php [ 34 ]
2012-01-20 20:38:35 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ';' ~ APPPATH/classes/model/mquestions.php [ 34 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-01-20 20:38:40 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:38:40 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:49:38 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:49:38 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:49:50 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:49:50 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:49:55 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:49:55 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:50:19 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:50:19 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:50:23 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:50:23 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:50:47 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:50:47 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:52:23 --- ERROR: ErrorException [ 8 ]: Undefined index: stitle ~ APPPATH/classes/model/mquestions.php [ 42 ]
2012-01-20 20:52:23 --- STRACE: ErrorException [ 8 ]: Undefined index: stitle ~ APPPATH/classes/model/mquestions.php [ 42 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(42): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 42, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:52:51 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:52:51 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:53:03 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:53:03 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:53:25 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:53:25 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:53:41 --- ERROR: ErrorException [ 8 ]: Undefined index: stitle ~ APPPATH/classes/model/mquestions.php [ 41 ]
2012-01-20 20:53:41 --- STRACE: ErrorException [ 8 ]: Undefined index: stitle ~ APPPATH/classes/model/mquestions.php [ 41 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(41): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 41, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:53:46 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:53:46 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:54:02 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/model/mquestions.php [ 41 ]
2012-01-20 20:54:02 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/model/mquestions.php [ 41 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(41): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 41, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:54:14 --- ERROR: ErrorException [ 2 ]: array_push() expects parameter 1 to be array, null given ~ APPPATH/classes/model/mquestions.php [ 36 ]
2012-01-20 20:54:14 --- STRACE: ErrorException [ 2 ]: array_push() expects parameter 1 to be array, null given ~ APPPATH/classes/model/mquestions.php [ 36 ]
--
#0 [internal function]: Kohana_Core::error_handler(2, 'array_push() ex...', '/Users/ravado/S...', 36, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(36): array_push(NULL, Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-20 20:54:23 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:54:23 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:55:24 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/classes/model/mquestions.php [ 43 ]
2012-01-20 20:55:24 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/classes/model/mquestions.php [ 43 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(43): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 43, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:55:32 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:55:32 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:56:01 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:56:01 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 20:56:47 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/model/mquestions.php [ 43 ]
2012-01-20 20:56:47 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/model/mquestions.php [ 43 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(43): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 43, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:56:54 --- ERROR: ErrorException [ 8 ]: Undefined index: stitle ~ APPPATH/classes/model/mquestions.php [ 43 ]
2012-01-20 20:56:54 --- STRACE: ErrorException [ 8 ]: Undefined index: stitle ~ APPPATH/classes/model/mquestions.php [ 43 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(43): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 43, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:57:01 --- ERROR: ErrorException [ 8 ]: Undefined index: stitle ~ APPPATH/classes/model/mquestions.php [ 43 ]
2012-01-20 20:57:01 --- STRACE: ErrorException [ 8 ]: Undefined index: stitle ~ APPPATH/classes/model/mquestions.php [ 43 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(43): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 43, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 20:57:05 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 20:57:05 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:01:41 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/classes/model/mquestions.php [ 43 ]
2012-01-20 21:01:41 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/classes/model/mquestions.php [ 43 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(43): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 43, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 21:01:47 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:01:47 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:01:55 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:01:55 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:02:27 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/classes/model/mquestions.php [ 43 ]
2012-01-20 21:02:27 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/classes/model/mquestions.php [ 43 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(43): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 43, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 21:02:29 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/model/mquestions.php [ 43 ]
2012-01-20 21:02:29 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/model/mquestions.php [ 43 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(43): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 43, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 21:02:47 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:02:47 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:03:06 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:03:06 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:03:26 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:03:26 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:03:33 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:03:33 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:04:37 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:04:37 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:04:55 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:04:55 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:05:19 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:05:19 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:05:26 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:05:26 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:05:30 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/model/mquestions.php [ 42 ]
2012-01-20 21:05:30 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/classes/model/mquestions.php [ 42 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(42): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 42, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 21:05:36 --- ERROR: ErrorException [ 8 ]: Undefined index: stitle ~ APPPATH/classes/model/mquestions.php [ 42 ]
2012-01-20 21:05:36 --- STRACE: ErrorException [ 8 ]: Undefined index: stitle ~ APPPATH/classes/model/mquestions.php [ 42 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(42): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 42, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 21:05:40 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:05:40 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:05:48 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:05:48 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:06:02 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:06:02 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:06:09 --- ERROR: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/model/mquestions.php [ 42 ]
2012-01-20 21:06:09 --- STRACE: ErrorException [ 8 ]: Undefined offset: 2 ~ APPPATH/classes/model/mquestions.php [ 42 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(42): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 42, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 21:06:16 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:06:16 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:06:22 --- ERROR: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 42 ]
2012-01-20 21:06:22 --- STRACE: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 42 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(42): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 42, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 21:06:29 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:06:29 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:06:42 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:06:42 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:06:47 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:06:47 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:06:52 --- ERROR: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 42 ]
2012-01-20 21:06:52 --- STRACE: ErrorException [ 8 ]: Undefined offset: 3 ~ APPPATH/classes/model/mquestions.php [ 42 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(42): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 42, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 21:06:54 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:06:54 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:06:58 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:06:58 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:07:50 --- ERROR: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/classes/model/mquestions.php [ 43 ]
2012-01-20 21:07:50 --- STRACE: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/classes/model/mquestions.php [ 43 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(43): Kohana_Core::error_handler(2, 'Illegal offset ...', '/Users/ravado/S...', 43, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 21:08:02 --- ERROR: ErrorException [ 8 ]: Undefined index: 144 ~ APPPATH/classes/model/mquestions.php [ 43 ]
2012-01-20 21:08:02 --- STRACE: ErrorException [ 8 ]: Undefined index: 144 ~ APPPATH/classes/model/mquestions.php [ 43 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(43): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 43, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 21:08:08 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:08:08 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:08:29 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:08:29 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:08:36 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:08:36 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:08:46 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:08:46 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:09:16 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:09:16 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:09:36 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:09:36 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:09:58 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:09:58 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:10:08 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:10:08 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:23:13 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:23:13 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:23:42 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:23:42 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:23:46 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:23:46 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:23:48 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:23:48 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:23:51 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:23:51 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:23:57 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:23:57 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:24:01 --- ERROR: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-20 21:24:01 --- STRACE: ErrorException [ 8 ]: Undefined index: id_subcategory ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(218): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 218, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:31:51 --- ERROR: ErrorException [ 8 ]: Undefined variable: key ~ APPPATH/views/questions/vQuestions.php [ 207 ]
2012-01-20 21:31:51 --- STRACE: ErrorException [ 8 ]: Undefined variable: key ~ APPPATH/views/questions/vQuestions.php [ 207 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(207): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 207, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:32:20 --- ERROR: ErrorException [ 8 ]: Undefined variable: key ~ APPPATH/views/questions/vQuestions.php [ 207 ]
2012-01-20 21:32:20 --- STRACE: ErrorException [ 8 ]: Undefined variable: key ~ APPPATH/views/questions/vQuestions.php [ 207 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(207): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 207, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:32:47 --- ERROR: ErrorException [ 8 ]: Undefined variable: key ~ APPPATH/views/questions/vQuestions.php [ 207 ]
2012-01-20 21:32:47 --- STRACE: ErrorException [ 8 ]: Undefined variable: key ~ APPPATH/views/questions/vQuestions.php [ 207 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(207): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 207, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 21:48:49 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers`, `vote`.`value` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = 143) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = 143 AND `questions_and_answers`.`id_answers` IS null) LEFT JOIN `vote` ON (`vote`.`id_user` = 5 AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-20 21:48:49 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers`, `vote`.`value` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = 143) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = 143 AND `questions_and_answers`.`id_answers` IS null) LEFT JOIN `vote` ON (`vote`.`id_user` = 5 AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(184): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(136): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-20 22:12:46 --- ERROR: ErrorException [ 8 ]: Undefined index: tags ~ APPPATH/views/questions/vQuestionOne.php [ 71 ]
2012-01-20 22:12:46 --- STRACE: ErrorException [ 8 ]: Undefined index: tags ~ APPPATH/views/questions/vQuestionOne.php [ 71 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(71): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 71, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:17:26 --- ERROR: ErrorException [ 1 ]: Call to a member function execute() on a non-object ~ APPPATH/classes/model/mquestions.php [ 183 ]
2012-01-20 22:17:26 --- STRACE: ErrorException [ 1 ]: Call to a member function execute() on a non-object ~ APPPATH/classes/model/mquestions.php [ 183 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-01-20 22:22:00 --- ERROR: ErrorException [ 8 ]: Undefined index: id_question ~ APPPATH/classes/model/mquestions.php [ 198 ]
2012-01-20 22:22:00 --- STRACE: ErrorException [ 8 ]: Undefined index: id_question ~ APPPATH/classes/model/mquestions.php [ 198 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(198): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 198, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(136): Model_Mquestions->getOneQuestion(Array)
#2 [internal function]: Controller_Questions_Questions->action_question()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 22:22:09 --- ERROR: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/model/mquestions.php [ 200 ]
2012-01-20 22:22:09 --- STRACE: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/model/mquestions.php [ 200 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(200): Kohana_Core::error_handler(8, 'Array to string...', '/Users/ravado/S...', 200, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(136): Model_Mquestions->getOneQuestion(Array)
#2 [internal function]: Controller_Questions_Questions->action_question()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 22:22:17 --- ERROR: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/model/mquestions.php [ 200 ]
2012-01-20 22:22:17 --- STRACE: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/model/mquestions.php [ 200 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(200): Kohana_Core::error_handler(8, 'Array to string...', '/Users/ravado/S...', 200, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(136): Model_Mquestions->getOneQuestion(Array)
#2 [internal function]: Controller_Questions_Questions->action_question()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 22:27:40 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 71 ]
2012-01-20 22:27:40 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 71 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(71): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 71, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:27:48 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 71 ]
2012-01-20 22:27:48 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 71 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(71): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 71, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:27:57 --- ERROR: ErrorException [ 8 ]: Undefined index: id_question ~ APPPATH/views/questions/vQuestionOne.php [ 71 ]
2012-01-20 22:27:57 --- STRACE: ErrorException [ 8 ]: Undefined index: id_question ~ APPPATH/views/questions/vQuestionOne.php [ 71 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(71): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 71, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:28:06 --- ERROR: ErrorException [ 8 ]: Undefined variable: popular ~ APPPATH/views/questions/vQuestionOne.php [ 72 ]
2012-01-20 22:28:06 --- STRACE: ErrorException [ 8 ]: Undefined variable: popular ~ APPPATH/views/questions/vQuestionOne.php [ 72 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 72, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:28:11 --- ERROR: ErrorException [ 8 ]: Undefined variable: popular ~ APPPATH/views/questions/vQuestionOne.php [ 72 ]
2012-01-20 22:28:11 --- STRACE: ErrorException [ 8 ]: Undefined variable: popular ~ APPPATH/views/questions/vQuestionOne.php [ 72 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(72): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 72, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:28:33 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestionOne.php [ 72 ]
2012-01-20 22:28:33 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/views/questions/vQuestionOne.php [ 72 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(72): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 72, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:29:18 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 72 ]
2012-01-20 22:29:18 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 72 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(72): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 72, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:29:26 --- ERROR: ErrorException [ 8 ]: Undefined index: stitle ~ APPPATH/views/questions/vQuestionOne.php [ 72 ]
2012-01-20 22:29:26 --- STRACE: ErrorException [ 8 ]: Undefined index: stitle ~ APPPATH/views/questions/vQuestionOne.php [ 72 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(72): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 72, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:29:33 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 72 ]
2012-01-20 22:29:33 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 72 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(72): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 72, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:33:03 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 74 ]
2012-01-20 22:33:03 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 74 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(74): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 74, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:33:40 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 74 ]
2012-01-20 22:33:40 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 74 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(74): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 74, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:34:03 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 75 ]
2012-01-20 22:34:03 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 75 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(75): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 75, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:35:44 --- ERROR: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 74 ]
2012-01-20 22:35:44 --- STRACE: ErrorException [ 8 ]: Undefined offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 74 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(74): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 74, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:35:51 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/views/questions/vQuestionOne.php [ 74 ]
2012-01-20 22:35:51 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/views/questions/vQuestionOne.php [ 74 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(74): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 74, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:35:55 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/views/questions/vQuestionOne.php [ 75 ]
2012-01-20 22:35:55 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/views/questions/vQuestionOne.php [ 75 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(75): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 75, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:38:05 --- ERROR: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/classes/controller/questions/questions.php [ 137 ]
2012-01-20 22:38:05 --- STRACE: ErrorException [ 8 ]: Undefined index: title ~ APPPATH/classes/controller/questions/questions.php [ 137 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(137): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 137, Array)
#1 [internal function]: Controller_Questions_Questions->action_question()
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-20 22:38:37 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/views/questions/vQuestionOne.php [ 74 ]
2012-01-20 22:38:37 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/views/questions/vQuestionOne.php [ 74 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(74): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 74, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:39:17 --- ERROR: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/views/questions/vQuestionOne.php [ 74 ]
2012-01-20 22:39:17 --- STRACE: ErrorException [ 8 ]: Undefined offset: 1 ~ APPPATH/views/questions/vQuestionOne.php [ 74 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(74): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 74, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:40:29 --- ERROR: ErrorException [ 8 ]: Undefined offset: 4 ~ APPPATH/classes/model/mquestions.php [ 202 ]
2012-01-20 22:40:29 --- STRACE: ErrorException [ 8 ]: Undefined offset: 4 ~ APPPATH/classes/model/mquestions.php [ 202 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(202): Kohana_Core::error_handler(8, 'Undefined offse...', '/Users/ravado/S...', 202, Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(136): Model_Mquestions->getOneQuestion(Array)
#2 [internal function]: Controller_Questions_Questions->action_question()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-20 22:40:49 --- ERROR: ErrorException [ 8 ]: Undefined index: id_question ~ APPPATH/views/questions/vQuestionOne.php [ 75 ]
2012-01-20 22:40:49 --- STRACE: ErrorException [ 8 ]: Undefined index: id_question ~ APPPATH/views/questions/vQuestionOne.php [ 75 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(75): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 75, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-20 22:42:21 --- ERROR: ErrorException [ 8 ]: Undefined variable: countTags ~ APPPATH/views/questions/vQuestionOne.php [ 82 ]
2012-01-20 22:42:21 --- STRACE: ErrorException [ 8 ]: Undefined variable: countTags ~ APPPATH/views/questions/vQuestionOne.php [ 82 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(82): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 82, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}