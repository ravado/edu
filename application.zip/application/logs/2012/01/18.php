<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-01-18 13:55:06 --- ERROR: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ APPPATH/views/questions/vQuestionCategory.php [ 8 ]
2012-01-18 13:55:06 --- STRACE: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ APPPATH/views/questions/vQuestionCategory.php [ 8 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler('/Users/ravado/S...', Array)
#1 {main}
2012-01-18 14:31:25 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_cat.id_questions_cat' in 'field list' [ SELECT `questions_cat`.`id_questions_cat`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`title`, `category`.`id_category`, `category`.`title` FROM `category` LEFT JOIN `subcategory` ON (`subcategory`.`id_category` = `category`.`id_category`) WHERE `category`.`title` != 'usercategory' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 14:31:25 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_cat.id_questions_cat' in 'field list' [ SELECT `questions_cat`.`id_questions_cat`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`title`, `category`.`id_category`, `category`.`title` FROM `category` LEFT JOIN `subcategory` ON (`subcategory`.`id_category` = `category`.`id_category`) WHERE `category`.`title` != 'usercategory' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(366): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(149): Model_Mquestions->getAllCategories(Array)
#3 [internal function]: Controller_Questions_Questions->action_category()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 14:31:52 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_cat.id_questions_cat' in 'field list' [ SELECT `questions_cat`.`id_questions_cat`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`title`, `category`.`id_category`, `category`.`title` FROM `category` LEFT JOIN `subcategory` ON (`subcategory`.`id_category` = `category`.`id_category`) WHERE `category`.`title` != 'usercategory' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 14:31:52 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_cat.id_questions_cat' in 'field list' [ SELECT `questions_cat`.`id_questions_cat`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`title`, `category`.`id_category`, `category`.`title` FROM `category` LEFT JOIN `subcategory` ON (`subcategory`.`id_category` = `category`.`id_category`) WHERE `category`.`title` != 'usercategory' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(366): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(149): Model_Mquestions->getAllCategories(Array)
#3 [internal function]: Controller_Questions_Questions->action_category()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 14:32:06 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_cat.id_question_cat' in 'field list' [ SELECT `questions_cat`.`id_question_cat`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`title`, `category`.`id_category`, `category`.`title` FROM `category` LEFT JOIN `subcategory` ON (`subcategory`.`id_category` = `category`.`id_category`) WHERE `category`.`title` != 'usercategory' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 14:32:06 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_cat.id_question_cat' in 'field list' [ SELECT `questions_cat`.`id_question_cat`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`title`, `category`.`id_category`, `category`.`title` FROM `category` LEFT JOIN `subcategory` ON (`subcategory`.`id_category` = `category`.`id_category`) WHERE `category`.`title` != 'usercategory' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(366): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(149): Model_Mquestions->getAllCategories(Array)
#3 [internal function]: Controller_Questions_Questions->action_category()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 14:32:40 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/views/questions/vQuestionCategory.php [ 8 ]
2012-01-18 14:32:40 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/views/questions/vQuestionCategory.php [ 8 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionCategory.php(8): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 14:36:33 --- ERROR: ErrorException [ 8 ]: Undefined index:  subcategory.title ~ APPPATH/views/questions/vQuestionCategory.php [ 8 ]
2012-01-18 14:36:33 --- STRACE: ErrorException [ 8 ]: Undefined index:  subcategory.title ~ APPPATH/views/questions/vQuestionCategory.php [ 8 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionCategory.php(8): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 14:38:35 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'subcategory.title' in 'field list' [ SELECT `questions`.`id_question`, `questions_cat`.`id_questions_cat`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`title` FROM `questions` LEFT JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) LEFT JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) WHERE `questions`.`id_question` > '54' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 14:38:35 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'subcategory.title' in 'field list' [ SELECT `questions`.`id_question`, `questions_cat`.`id_questions_cat`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`title` FROM `questions` LEFT JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) LEFT JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) WHERE `questions`.`id_question` > '54' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(358): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(149): Model_Mquestions->getAllCategories(Array)
#3 [internal function]: Controller_Questions_Questions->action_category()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 14:41:13 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/views/questions/vQuestionCategory.php [ 14 ]
2012-01-18 14:41:13 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/views/questions/vQuestionCategory.php [ 14 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionCategory.php(14): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 17:41:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/15 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-01-18 17:41:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/15 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-18 17:42:42 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/15 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-01-18 17:42:42 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/15 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-18 17:42:45 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/2 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-01-18 17:42:45 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/2 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-18 18:18:08 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/19 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-01-18 18:18:08 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/19 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-18 18:18:16 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/56 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-01-18 18:18:16 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/56 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-18 18:51:48 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestions.php [ 27 ]
2012-01-18 18:51:48 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestions.php [ 27 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(27): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 18:52:08 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestions.php [ 27 ]
2012-01-18 18:52:08 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestions.php [ 27 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(27): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 18:52:22 --- ERROR: ErrorException [ 8 ]: Undefined offset:  3 ~ APPPATH/views/questions/vQuestions.php [ 15 ]
2012-01-18 18:52:22 --- STRACE: ErrorException [ 8 ]: Undefined offset:  3 ~ APPPATH/views/questions/vQuestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(15): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 19:13:54 --- ERROR: ErrorException [ 8 ]: Undefined offset:  11 ~ APPPATH/views/questions/vQuestions.php [ 133 ]
2012-01-18 19:13:54 --- STRACE: ErrorException [ 8 ]: Undefined offset:  11 ~ APPPATH/views/questions/vQuestions.php [ 133 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(133): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 19:16:45 --- ERROR: ErrorException [ 2 ]: next() [function.next]: Passed variable is not an array or object ~ APPPATH/views/questions/vQuestions.php [ 133 ]
2012-01-18 19:16:45 --- STRACE: ErrorException [ 2 ]: next() [function.next]: Passed variable is not an array or object ~ APPPATH/views/questions/vQuestions.php [ 133 ]
--
#0 [internal function]: Kohana_Core::error_handler('58')
#1 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(133): next('/Users/ravado/S...', Array)
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#4 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#5 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#7 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#8 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#9 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#10 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#14 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#15 {main}
2012-01-18 19:17:23 --- ERROR: ErrorException [ 2 ]: next() [function.next]: Passed variable is not an array or object ~ APPPATH/views/questions/vQuestions.php [ 133 ]
2012-01-18 19:17:23 --- STRACE: ErrorException [ 2 ]: next() [function.next]: Passed variable is not an array or object ~ APPPATH/views/questions/vQuestions.php [ 133 ]
--
#0 [internal function]: Kohana_Core::error_handler('58')
#1 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(133): next('/Users/ravado/S...', Array)
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#4 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#5 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#7 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#8 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#9 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#10 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#14 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#15 {main}
2012-01-18 19:34:02 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/views/questions/vQuestions.php [ 130 ]
2012-01-18 19:34:02 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/views/questions/vQuestions.php [ 130 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(130): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 19:34:17 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 130 ]
2012-01-18 19:34:17 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 130 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(130): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 19:37:11 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_quetion ~ APPPATH/views/questions/vQuestions.php [ 129 ]
2012-01-18 19:37:11 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_quetion ~ APPPATH/views/questions/vQuestions.php [ 129 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(129): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 19:39:32 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 132 ]
2012-01-18 19:39:32 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 132 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(132): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 19:40:56 --- ERROR: ErrorException [ 8 ]: Undefined index:  60 ~ APPPATH/views/questions/vQuestions.php [ 133 ]
2012-01-18 19:40:56 --- STRACE: ErrorException [ 8 ]: Undefined index:  60 ~ APPPATH/views/questions/vQuestions.php [ 133 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(133): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 19:41:23 --- ERROR: ErrorException [ 8 ]: Undefined index:  60 ~ APPPATH/views/questions/vQuestions.php [ 133 ]
2012-01-18 19:41:23 --- STRACE: ErrorException [ 8 ]: Undefined index:  60 ~ APPPATH/views/questions/vQuestions.php [ 133 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(133): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 19:41:32 --- ERROR: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/views/questions/vQuestions.php [ 133 ]
2012-01-18 19:41:32 --- STRACE: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/views/questions/vQuestions.php [ 133 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(133): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 19:42:32 --- ERROR: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/views/questions/vQuestions.php [ 136 ]
2012-01-18 19:42:32 --- STRACE: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/views/questions/vQuestions.php [ 136 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(136): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 19:43:02 --- ERROR: ErrorException [ 8 ]: Undefined index:  ctitle ~ APPPATH/views/questions/vQuestions.php [ 136 ]
2012-01-18 19:43:02 --- STRACE: ErrorException [ 8 ]: Undefined index:  ctitle ~ APPPATH/views/questions/vQuestions.php [ 136 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(136): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 19:46:44 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/views/questions/vQuestions.php [ 135 ]
2012-01-18 19:46:44 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/views/questions/vQuestions.php [ 135 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(135): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 19:46:58 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 135 ]
2012-01-18 19:46:58 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 135 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(135): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 20:14:03 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected '.' ~ APPPATH/views/questions/vQuestions.php [ 135 ]
2012-01-18 20:14:03 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected '.' ~ APPPATH/views/questions/vQuestions.php [ 135 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler('/Users/ravado/S...', Array)
#1 {main}
2012-01-18 20:28:04 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_category ~ APPPATH/views/questions/vQuestions.php [ 136 ]
2012-01-18 20:28:04 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_category ~ APPPATH/views/questions/vQuestions.php [ 136 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(136): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 20:33:57 --- ERROR: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/views/questions/vQuestions.php [ 132 ]
2012-01-18 20:33:57 --- STRACE: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/views/questions/vQuestions.php [ 132 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(132): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-18 22:18:17 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` = (('общение'))' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` = (('общение')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:18:17 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` = (('общение'))' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` = (('общение')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:19:05 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` = ('физика')' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` = ('физика') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:19:05 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` = ('физика')' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` = ('физика') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:19:24 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` AS ('физика')' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` AS ('физика') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:19:24 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` AS ('физика')' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` AS ('физика') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:19:32 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` LIKE ('физика')' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` LIKE ('физика') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:19:32 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` LIKE ('физика')' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` LIKE ('физика') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:19:41 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 63 ]
2012-01-18 22:19:41 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 63 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-18 22:20:00 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 63 ]
2012-01-18 22:20:00 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 63 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-18 22:20:53 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` LIKE 'человек'' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` LIKE 'человек' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:20:53 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` LIKE 'человек'' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` LIKE 'человек' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:22:24 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` LIKE человек' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` LIKE человек ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:22:24 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` LIKE человек' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` LIKE человек ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:22:38 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` LIKE Array' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` LIKE Array ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:22:38 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` LIKE Array' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` LIKE Array ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:22:53 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` LIKE (('человек', 'закон'))' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` LIKE (('человек', 'закон')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:22:53 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` LIKE (('человек', 'закон'))' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` LIKE (('человек', 'закон')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:25:51 --- ERROR: ErrorException [ 2 ]: Missing argument 2 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 63 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
2012-01-18 22:25:51 --- STRACE: ErrorException [ 2 ]: Missing argument 2 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 63 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/where.php(30): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query_Builder_Where->where(Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#3 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:26:15 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` LIKE ('человек', 'закон')' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` LIKE ('человек', 'закон') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:26:15 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` LIKE ('человек', 'закон')' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` LIKE ('человек', 'закон') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:26:36 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` LIKE (('человек', 'закон'))' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` LIKE (('человек', 'закон')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:26:36 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `subcategory`.`stitle` LIKE (('человек', 'закон'))' at line 1 [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` WHERE `subcategory`.`stitle` LIKE (('человек', 'закон')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:33:49 --- ERROR: ErrorException [ 2 ]: Missing argument 2 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 63 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
2012-01-18 22:33:49 --- STRACE: ErrorException [ 2 ]: Missing argument 2 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 63 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/where.php(30): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query_Builder_Where->where(Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#3 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:34:53 --- ERROR: ErrorException [ 2 ]: Missing argument 2 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 63 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
2012-01-18 22:34:53 --- STRACE: ErrorException [ 2 ]: Missing argument 2 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 63 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/where.php(30): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query_Builder_Where->where(Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#3 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:38:11 --- ERROR: Database_Exception [ 1109 ]: Unknown table 'subcategory' in field list [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:38:11 --- STRACE: Database_Exception [ 1109 ]: Unknown table 'subcategory' in field list [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:39:01 --- ERROR: ErrorException [ 2 ]: Missing argument 2 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 63 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
2012-01-18 22:39:01 --- STRACE: ErrorException [ 2 ]: Missing argument 2 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 63 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/where.php(30): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query_Builder_Where->where(Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#3 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:39:31 --- ERROR: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `subcategory` WHERE `subcategory`.`stitle` = (('человек', 'закон')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:39:31 --- STRACE: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `subcategory` WHERE `subcategory`.`stitle` = (('человек', 'закон')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:40:01 --- ERROR: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `subcategory` WHERE `subcategory`.`stitle` = ('человек', 'закон') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:40:01 --- STRACE: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `subcategory` WHERE `subcategory`.`stitle` = ('человек', 'закон') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:40:24 --- ERROR: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `subcategory` WHERE `subcategory`.`stitle` LIKE ('человек', 'закон') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:40:24 --- STRACE: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `subcategory` WHERE `subcategory`.`stitle` LIKE ('человек', 'закон') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:42:52 --- ERROR: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `subcategory` WHERE `subcategory`.`stitle` LIKE ('карьера', 'человек', 'закон') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:42:52 --- STRACE: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `subcategory` WHERE `subcategory`.`stitle` LIKE ('карьера', 'человек', 'закон') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:44:34 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 63 ]
2012-01-18 22:44:34 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 63 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-18 22:44:45 --- ERROR: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `subcategory` WHERE `subcategory`.`stitle` LIKE ('музыка', 'геометрия') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 22:44:45 --- STRACE: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `subcategory` WHERE `subcategory`.`stitle` LIKE ('музыка', 'геометрия') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `subcate...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(63): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 22:53:55 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_category ~ APPPATH/classes/model/mquestions.php [ 68 ]
2012-01-18 22:53:55 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_category ~ APPPATH/classes/model/mquestions.php [ 68 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(68): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-18 22:55:18 --- ERROR: ErrorException [ 8 ]: Undefined variable: catexist ~ APPPATH/classes/model/mquestions.php [ 75 ]
2012-01-18 22:55:18 --- STRACE: ErrorException [ 8 ]: Undefined variable: catexist ~ APPPATH/classes/model/mquestions.php [ 75 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(75): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-18 23:27:53 --- ERROR: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ INSERT INTO `subcategory` (`id_category`, `stitle`) VALUES ('3', ('семья', 'работа', 'закон')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 23:27:53 --- STRACE: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ INSERT INTO `subcategory` (`id_category`, `stitle`) VALUES ('3', ('семья', 'работа', 'закон')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `su...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(80): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 23:28:31 --- ERROR: Database_Exception [ 1136 ]: Column count doesn't match value count at row 1 [ INSERT INTO `subcategory` (`id_category`, `stitle`) VALUES ('семья', 'работа', 'закон') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 23:28:31 --- STRACE: Database_Exception [ 1136 ]: Column count doesn't match value count at row 1 [ INSERT INTO `subcategory` (`id_category`, `stitle`) VALUES ('семья', 'работа', 'закон') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `su...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(80): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 23:30:38 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_DB::insert() must be an array, string given, called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 79 and defined ~ MODPATH/database/classes/kohana/db.php [ 90 ]
2012-01-18 23:30:38 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_DB::insert() must be an array, string given, called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 79 and defined ~ MODPATH/database/classes/kohana/db.php [ 90 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/db.php(90): Kohana_Core::error_handler('subcategory', 'stitle')
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(79): Kohana_DB::insert(Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#3 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 23:31:26 --- ERROR: Database_Exception [ 1136 ]: Column count doesn't match value count at row 1 [ INSERT INTO `subcategory` (`stitle`) VALUES ('семья', 'работа', 'закон') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 23:31:26 --- STRACE: Database_Exception [ 1136 ]: Column count doesn't match value count at row 1 [ INSERT INTO `subcategory` (`stitle`) VALUES ('семья', 'работа', 'закон') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `su...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(80): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 23:33:52 --- ERROR: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Database_Query_Builder_Insert::values() must be an array, string given, called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 82 and defined ~ MODPATH/database/classes/kohana/database/query/builder/insert.php [ 80 ]
2012-01-18 23:33:52 --- STRACE: ErrorException [ 4096 ]: Argument 1 passed to Kohana_Database_Query_Builder_Insert::values() must be an array, string given, called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 82 and defined ~ MODPATH/database/classes/kohana/database/query/builder/insert.php [ 80 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(80): Kohana_Core::error_handler('??????????')
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(82): Kohana_Database_Query_Builder_Insert->values(Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#3 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 23:34:17 --- ERROR: ErrorException [ 1 ]: Call to a member function as_array() on a non-object ~ APPPATH/classes/model/mquestions.php [ 82 ]
2012-01-18 23:34:17 --- STRACE: ErrorException [ 1 ]: Call to a member function as_array() on a non-object ~ APPPATH/classes/model/mquestions.php [ 82 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler(Array)
#1 {main}
2012-01-18 23:39:05 --- ERROR: ErrorException [ 8 ]: Undefined offset:  2 ~ APPPATH/classes/model/mquestions.php [ 82 ]
2012-01-18 23:39:05 --- STRACE: ErrorException [ 8 ]: Undefined offset:  2 ~ APPPATH/classes/model/mquestions.php [ 82 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(82): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-18 23:39:38 --- ERROR: ErrorException [ 8 ]: Undefined offset:  1 ~ APPPATH/classes/model/mquestions.php [ 82 ]
2012-01-18 23:39:38 --- STRACE: ErrorException [ 8 ]: Undefined offset:  1 ~ APPPATH/classes/model/mquestions.php [ 82 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(82): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-18 23:42:17 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_subcategory ~ APPPATH/classes/model/mquestions.php [ 90 ]
2012-01-18 23:42:17 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_subcategory ~ APPPATH/classes/model/mquestions.php [ 90 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(90): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-18 23:42:34 --- ERROR: ErrorException [ 8 ]: Undefined index:  id ~ APPPATH/classes/model/mquestions.php [ 90 ]
2012-01-18 23:42:34 --- STRACE: ErrorException [ 8 ]: Undefined index:  id ~ APPPATH/classes/model/mquestions.php [ 90 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(90): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-18 23:52:09 --- ERROR: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ INSERT INTO `questions_cat` (`id_subcategory`) VALUES (('1', '2')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 23:52:09 --- STRACE: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ INSERT INTO `questions_cat` (`id_subcategory`) VALUES (('1', '2')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `qu...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(99): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-18 23:52:43 --- ERROR: Database_Exception [ 1136 ]: Column count doesn't match value count at row 1 [ INSERT INTO `questions_cat` (`id_subcategory`) VALUES ('1', '2') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-18 23:52:43 --- STRACE: Database_Exception [ 1136 ]: Column count doesn't match value count at row 1 [ INSERT INTO `questions_cat` (`id_subcategory`) VALUES ('1', '2') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `qu...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(99): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}