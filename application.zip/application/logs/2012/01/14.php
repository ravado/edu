<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-01-14 00:00:45 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected $end ~ APPPATH/views/questions/vQuestionOne.php [ 231 ]
2012-01-14 00:00:45 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected $end ~ APPPATH/views/questions/vQuestionOne.php [ 231 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler('/Users/ravado/S...', Array)
#1 {main}
2012-01-14 00:18:00 --- ERROR: ErrorException [ 1 ]: Call to a member function on() on a non-object ~ MODPATH/database/classes/kohana/database/query/builder/select.php [ 140 ]
2012-01-14 00:18:00 --- STRACE: ErrorException [ 1 ]: Call to a member function on() on a non-object ~ MODPATH/database/classes/kohana/database/query/builder/select.php [ 140 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler('questions_and_a...', '=', Object(Database_Expression))
#1 {main}
2012-01-14 00:27:24 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/controller/questions/questions.php [ 134 ]
2012-01-14 00:27:24 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/controller/questions/questions.php [ 134 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(134): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_question(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 01:08:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 01:08:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 01:08:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 01:08:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 02:01:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addanswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-01-14 02:01:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addanswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 02:02:48 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addanswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-01-14 02:02:48 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addanswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 02:02:56 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addanswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-01-14 02:02:56 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addanswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 02:04:41 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addanswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-01-14 02:04:41 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addanswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 02:05:02 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addanswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-01-14 02:05:02 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addanswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 02:05:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addanswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-01-14 02:05:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addanswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 02:06:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addanswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-01-14 02:06:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addanswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 02:07:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: edu.ka/questions/qhid/addanswer ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 02:07:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: edu.ka/questions/qhid/addanswer ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 02:08:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/question/questions/qhid/addanswer ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 02:08:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/question/questions/qhid/addanswer ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 02:08:51 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/question/questions/qhid/addAnswer ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 02:08:51 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/question/questions/qhid/addAnswer ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 02:08:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/question/questions/qhid/addAnswer ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 02:08:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/question/questions/qhid/addAnswer ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 02:09:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/question/questions/qhid/addAnswer/1 ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 02:09:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/question/questions/qhid/addAnswer/1 ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 02:10:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/questions/addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-14 02:10:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/questions/addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 02:11:27 --- ERROR: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
2012-01-14 02:11:27 --- STRACE: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/user/uhid.php(13): Kohana_Core::error_handler()
#1 [internal function]: Controller_User_Uhid->action_getUserThLogin(Object(Controller_User_Uhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:11:43 --- ERROR: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
2012-01-14 02:11:43 --- STRACE: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/user/uhid.php(13): Kohana_Core::error_handler()
#1 [internal function]: Controller_User_Uhid->action_getUserThLogin(Object(Controller_User_Uhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:11:52 --- ERROR: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
2012-01-14 02:11:52 --- STRACE: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/user/uhid.php(13): Kohana_Core::error_handler()
#1 [internal function]: Controller_User_Uhid->action_getUserThLogin(Object(Controller_User_Uhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:12:20 --- ERROR: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
2012-01-14 02:12:20 --- STRACE: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/user/uhid.php(13): Kohana_Core::error_handler()
#1 [internal function]: Controller_User_Uhid->action_getUserThLogin(Object(Controller_User_Uhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:12:28 --- ERROR: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
2012-01-14 02:12:28 --- STRACE: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/user/uhid.php(13): Kohana_Core::error_handler()
#1 [internal function]: Controller_User_Uhid->action_getUserThLogin(Object(Controller_User_Uhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:12:57 --- ERROR: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
2012-01-14 02:12:57 --- STRACE: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/user/uhid.php(13): Kohana_Core::error_handler()
#1 [internal function]: Controller_User_Uhid->action_getUserThLogin(Object(Controller_User_Uhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:13:06 --- ERROR: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
2012-01-14 02:13:06 --- STRACE: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/user/uhid.php(13): Kohana_Core::error_handler()
#1 [internal function]: Controller_User_Uhid->action_getUserThLogin(Object(Controller_User_Uhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:13:16 --- ERROR: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
2012-01-14 02:13:16 --- STRACE: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/user/uhid.php(13): Kohana_Core::error_handler()
#1 [internal function]: Controller_User_Uhid->action_getUserThLogin(Object(Controller_User_Uhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:13:28 --- ERROR: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
2012-01-14 02:13:28 --- STRACE: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/user/uhid.php(13): Kohana_Core::error_handler()
#1 [internal function]: Controller_User_Uhid->action_getUserThLogin(Object(Controller_User_Uhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:13:38 --- ERROR: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
2012-01-14 02:13:38 --- STRACE: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/user/uhid.php(13): Kohana_Core::error_handler()
#1 [internal function]: Controller_User_Uhid->action_getUserThLogin(Object(Controller_User_Uhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:13:55 --- ERROR: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
2012-01-14 02:13:55 --- STRACE: ErrorException [ 8 ]: Undefined index:  ckeckIsExist ~ APPPATH/classes/controller/user/uhid.php [ 13 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/user/uhid.php(13): Kohana_Core::error_handler()
#1 [internal function]: Controller_User_Uhid->action_getUserThLogin(Object(Controller_User_Uhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:14:42 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/questions/addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-14 02:14:42 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/questions/addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 02:14:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/questions/addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-14 02:14:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/questions/addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 02:18:37 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-14 02:18:37 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 02:19:03 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/qhid/addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-14 02:19:03 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/qhid/addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 02:21:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL qhid/addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-14 02:21:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL qhid/addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 02:22:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/question/questions/qhid/addAnswer ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 02:22:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/question/questions/qhid/addAnswer ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 02:23:22 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-01-14 02:23:22 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 02:23:48 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL question/qhid/addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-14 02:23:48 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL question/qhid/addAnswer was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 02:27:38 --- ERROR: ErrorException [ 8 ]: Undefined index:  answer_text ~ APPPATH/classes/controller/questions/qhid.php [ 16 ]
2012-01-14 02:27:38 --- STRACE: ErrorException [ 8 ]: Undefined index:  answer_text ~ APPPATH/classes/controller/questions/qhid.php [ 16 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(16): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:28:15 --- ERROR: ErrorException [ 8 ]: Uninitialized string offset: 0 ~ APPPATH/classes/controller/questions/qhid.php [ 15 ]
2012-01-14 02:28:15 --- STRACE: ErrorException [ 8 ]: Uninitialized string offset: 0 ~ APPPATH/classes/controller/questions/qhid.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(15): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:29:03 --- ERROR: ErrorException [ 8 ]: Undefined index:  answer_text ~ APPPATH/classes/controller/questions/qhid.php [ 16 ]
2012-01-14 02:29:03 --- STRACE: ErrorException [ 8 ]: Undefined index:  answer_text ~ APPPATH/classes/controller/questions/qhid.php [ 16 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(16): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:30:04 --- ERROR: ErrorException [ 8 ]: Undefined index:  answer_text ~ APPPATH/classes/controller/questions/qhid.php [ 16 ]
2012-01-14 02:30:04 --- STRACE: ErrorException [ 8 ]: Undefined index:  answer_text ~ APPPATH/classes/controller/questions/qhid.php [ 16 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(16): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:30:33 --- ERROR: ErrorException [ 8 ]: Undefined index:  answer_text ~ APPPATH/classes/controller/questions/qhid.php [ 16 ]
2012-01-14 02:30:33 --- STRACE: ErrorException [ 8 ]: Undefined index:  answer_text ~ APPPATH/classes/controller/questions/qhid.php [ 16 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(16): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:30:54 --- ERROR: ErrorException [ 8 ]: Uninitialized string offset: 0 ~ APPPATH/classes/controller/questions/qhid.php [ 15 ]
2012-01-14 02:30:54 --- STRACE: ErrorException [ 8 ]: Uninitialized string offset: 0 ~ APPPATH/classes/controller/questions/qhid.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(15): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:32:34 --- ERROR: ErrorException [ 8 ]: Uninitialized string offset: 0 ~ APPPATH/classes/controller/questions/qhid.php [ 15 ]
2012-01-14 02:32:34 --- STRACE: ErrorException [ 8 ]: Uninitialized string offset: 0 ~ APPPATH/classes/controller/questions/qhid.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(15): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:34:09 --- ERROR: ErrorException [ 8 ]: Undefined index:  answer_text ~ APPPATH/classes/controller/questions/qhid.php [ 16 ]
2012-01-14 02:34:09 --- STRACE: ErrorException [ 8 ]: Undefined index:  answer_text ~ APPPATH/classes/controller/questions/qhid.php [ 16 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(16): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:34:56 --- ERROR: ErrorException [ 8 ]: Undefined index:  answerData ~ APPPATH/classes/controller/questions/qhid.php [ 15 ]
2012-01-14 02:34:56 --- STRACE: ErrorException [ 8 ]: Undefined index:  answerData ~ APPPATH/classes/controller/questions/qhid.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(15): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:36:17 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/classes/controller/questions/qhid.php [ 15 ]
2012-01-14 02:36:17 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/classes/controller/questions/qhid.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(15): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 02:36:57 --- ERROR: ErrorException [ 1 ]: Call to undefined function execute() ~ APPPATH/classes/model/mquestions.php [ 121 ]
2012-01-14 02:36:57 --- STRACE: ErrorException [ 1 ]: Call to undefined function execute() ~ APPPATH/classes/model/mquestions.php [ 121 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler(Array)
#1 {main}
2012-01-14 02:38:09 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-14 02:38:09 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(133): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(17): Model_Mquestions->addAnswer()
#5 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-14 02:39:36 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-14 02:39:36 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(133): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(17): Model_Mquestions->addAnswer()
#5 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-14 02:40:18 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-14 02:40:18 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(132): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(17): Model_Mquestions->addAnswer()
#5 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-14 02:40:51 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-14 02:40:51 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(133): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(17): Model_Mquestions->addAnswer()
#5 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-14 02:41:58 --- ERROR: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
2012-01-14 02:41:58 --- STRACE: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#1 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#2 [internal function]: Controller_Base->after()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-14 02:42:40 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-14 02:42:40 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(133): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(17): Model_Mquestions->addAnswer()
#5 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-14 13:17:45 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/classes/controller/questions/qhid.php [ 15 ]
2012-01-14 13:17:45 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/classes/controller/questions/qhid.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(15): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 13:18:12 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-14 13:18:12 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(133): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(17): Model_Mquestions->addAnswer()
#5 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-14 13:19:29 --- ERROR: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
2012-01-14 13:19:29 --- STRACE: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#1 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#2 [internal function]: Controller_Base->after()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-14 13:21:36 --- ERROR: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
2012-01-14 13:21:36 --- STRACE: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#1 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#2 [internal function]: Controller_Base->after()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-14 13:22:19 --- ERROR: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
2012-01-14 13:22:19 --- STRACE: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#1 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#2 [internal function]: Controller_Base->after()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-14 13:27:28 --- ERROR: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
2012-01-14 13:27:28 --- STRACE: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#1 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#2 [internal function]: Controller_Base->after()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-14 13:29:42 --- ERROR: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
2012-01-14 13:29:42 --- STRACE: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#1 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#2 [internal function]: Controller_Base->after()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-14 13:30:39 --- ERROR: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
2012-01-14 13:30:39 --- STRACE: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#1 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#2 [internal function]: Controller_Base->after()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-14 13:31:18 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/getOneNews was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-01-14 13:31:18 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/getOneNews was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 13:31:52 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/getOneNews was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
2012-01-14 13:31:52 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/qhid/getOneNews was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 113 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 13:32:31 --- ERROR: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
2012-01-14 13:32:31 --- STRACE: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#1 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#2 [internal function]: Controller_Base->after()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-14 13:33:16 --- ERROR: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
2012-01-14 13:33:16 --- STRACE: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#1 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#2 [internal function]: Controller_Base->after()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-14 13:40:41 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_View::factory() must be an array, string given, called in /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php on line 14 and defined ~ SYSPATH/classes/kohana/view.php [ 28 ]
2012-01-14 13:40:41 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_View::factory() must be an array, string given, called in /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php on line 14 and defined ~ SYSPATH/classes/kohana/view.php [ 28 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/view.php(28): Kohana_Core::error_handler('news/vNewsHome', '')
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(14): Kohana_View::factory()
#2 [internal function]: Controller_Questions_Qhid->action_getOneNews(Object(Controller_Questions_Qhid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-14 13:41:12 --- ERROR: ErrorException [ 4096 ]: Argument 2 passed to Kohana_View::factory() must be an array, string given, called in /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php on line 14 and defined ~ SYSPATH/classes/kohana/view.php [ 28 ]
2012-01-14 13:41:12 --- STRACE: ErrorException [ 4096 ]: Argument 2 passed to Kohana_View::factory() must be an array, string given, called in /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php on line 14 and defined ~ SYSPATH/classes/kohana/view.php [ 28 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/view.php(28): Kohana_Core::error_handler('news/vNewsHome', 'ss')
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(14): Kohana_View::factory()
#2 [internal function]: Controller_Questions_Qhid->action_getOneNews(Object(Controller_Questions_Qhid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-14 13:41:51 --- ERROR: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
2012-01-14 13:41:51 --- STRACE: View_Exception [ 0 ]: You must set the file to use within your view before rendering ~ SYSPATH/classes/kohana/view.php [ 339 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#1 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#2 [internal function]: Controller_Base->after()
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-14 13:49:18 --- ERROR: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/questions/qhid.php [ 15 ]
2012-01-14 13:49:18 --- STRACE: ErrorException [ 2048 ]: Creating default object from empty value ~ APPPATH/classes/controller/questions/qhid.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(15): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Qhid->action_getOneNews(Object(Controller_Questions_Qhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 13:54:10 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestionOne.php [ 14 ]
2012-01-14 13:54:10 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestionOne.php [ 14 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(14): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 14:13:24 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Mquestions::addAnswer() ~ APPPATH/classes/controller/questions/qhid.php [ 17 ]
2012-01-14 14:13:24 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Mquestions::addAnswer() ~ APPPATH/classes/controller/questions/qhid.php [ 17 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-01-14 14:13:50 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Mquestions::addAnswer() ~ APPPATH/classes/controller/questions/qhid.php [ 17 ]
2012-01-14 14:13:50 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Mquestions::addAnswer() ~ APPPATH/classes/controller/questions/qhid.php [ 17 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-01-14 14:19:00 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-14 14:19:00 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(133): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(17): Model_Mquestions->addAnswer()
#5 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-14 14:19:42 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-14 14:19:42 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(133): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(17): Model_Mquestions->addAnswer()
#5 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-14 14:20:22 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-14 14:20:22 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(133): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(17): Model_Mquestions->addAnswer()
#5 [internal function]: Controller_Questions_Qhid->action_addAnswer(Object(Controller_Questions_Qhid))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-14 14:35:01 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id' in 'field list' [ SELECT `id` FROM `answers` WHERE `public_date` = '2012-01-14 14:35:00' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-14 14:35:01 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id' in 'field list' [ SELECT `id` FROM `answers` WHERE `public_date` = '2012-01-14 14:35:00' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id` FRO...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(135): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(17): Model_Mquestions->addAnswer(Array)
#3 [internal function]: Controller_Questions_Qhid->action_addAnswer()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-14 16:24:47 --- ERROR: ErrorException [ 8 ]: Undefined index:  answes ~ APPPATH/views/questions/vQuestionOne.php [ 123 ]
2012-01-14 16:24:47 --- STRACE: ErrorException [ 8 ]: Undefined index:  answes ~ APPPATH/views/questions/vQuestionOne.php [ 123 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(123): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 16:24:54 --- ERROR: ErrorException [ 8 ]: Undefined index:  answes ~ APPPATH/views/questions/vQuestionOne.php [ 123 ]
2012-01-14 16:24:54 --- STRACE: ErrorException [ 8 ]: Undefined index:  answes ~ APPPATH/views/questions/vQuestionOne.php [ 123 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(123): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 16:24:58 --- ERROR: ErrorException [ 8 ]: Undefined index:  answes ~ APPPATH/views/questions/vQuestionOne.php [ 123 ]
2012-01-14 16:24:58 --- STRACE: ErrorException [ 8 ]: Undefined index:  answes ~ APPPATH/views/questions/vQuestionOne.php [ 123 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(123): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 16:25:12 --- ERROR: ErrorException [ 8 ]: Undefined index:  answes ~ APPPATH/views/questions/vQuestionOne.php [ 123 ]
2012-01-14 16:25:12 --- STRACE: ErrorException [ 8 ]: Undefined index:  answes ~ APPPATH/views/questions/vQuestionOne.php [ 123 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(123): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 16:26:02 --- ERROR: ErrorException [ 8 ]: Undefined index:  answer ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
2012-01-14 16:26:02 --- STRACE: ErrorException [ 8 ]: Undefined index:  answer ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 16:26:57 --- ERROR: ErrorException [ 8 ]: Undefined index:  id ~ APPPATH/views/questions/vQuestionOne.php [ 123 ]
2012-01-14 16:26:57 --- STRACE: ErrorException [ 8 ]: Undefined index:  id ~ APPPATH/views/questions/vQuestionOne.php [ 123 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(123): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 16:48:42 --- ERROR: ErrorException [ 8 ]: Undefined index:  questions ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
2012-01-14 16:48:42 --- STRACE: ErrorException [ 8 ]: Undefined index:  questions ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 16:55:42 --- ERROR: ErrorException [ 8 ]: Undefined index:  user_id ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
2012-01-14 16:55:42 --- STRACE: ErrorException [ 8 ]: Undefined index:  user_id ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 16:55:51 --- ERROR: ErrorException [ 8 ]: Undefined index:  answer ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
2012-01-14 16:55:51 --- STRACE: ErrorException [ 8 ]: Undefined index:  answer ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 16:55:53 --- ERROR: ErrorException [ 8 ]: Undefined index:  user_id ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
2012-01-14 16:55:53 --- STRACE: ErrorException [ 8 ]: Undefined index:  user_id ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 16:56:18 --- ERROR: ErrorException [ 8 ]: Undefined index:  user_id ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
2012-01-14 16:56:18 --- STRACE: ErrorException [ 8 ]: Undefined index:  user_id ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 16:56:54 --- ERROR: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
2012-01-14 16:56:54 --- STRACE: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 16:57:01 --- ERROR: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
2012-01-14 16:57:01 --- STRACE: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 16:57:16 --- ERROR: ErrorException [ 8 ]: Undefined variable: username ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
2012-01-14 16:57:16 --- STRACE: ErrorException [ 8 ]: Undefined variable: username ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 16:57:33 --- ERROR: ErrorException [ 8 ]: Undefined variable: userName ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
2012-01-14 16:57:33 --- STRACE: ErrorException [ 8 ]: Undefined variable: userName ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 16:59:05 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 134 ]
2012-01-14 16:59:05 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 134 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(134): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_question(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 16:59:45 --- ERROR: ErrorException [ 8 ]: Undefined index:  userName ~ APPPATH/classes/controller/questions/questions.php [ 134 ]
2012-01-14 16:59:45 --- STRACE: ErrorException [ 8 ]: Undefined index:  userName ~ APPPATH/classes/controller/questions/questions.php [ 134 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(134): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_question(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 17:00:06 --- ERROR: ErrorException [ 8 ]: Undefined index:  userName ~ APPPATH/classes/controller/questions/questions.php [ 134 ]
2012-01-14 17:00:06 --- STRACE: ErrorException [ 8 ]: Undefined index:  userName ~ APPPATH/classes/controller/questions/questions.php [ 134 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(134): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_question(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-14 17:00:40 --- ERROR: ErrorException [ 8 ]: Undefined variable: username ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
2012-01-14 17:00:40 --- STRACE: ErrorException [ 8 ]: Undefined variable: username ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 17:00:54 --- ERROR: ErrorException [ 8 ]: Undefined variable: username ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
2012-01-14 17:00:54 --- STRACE: ErrorException [ 8 ]: Undefined variable: username ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 17:34:23 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected ')' ~ APPPATH/views/questions/vQuestionOne.php [ 155 ]
2012-01-14 17:34:23 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected ')' ~ APPPATH/views/questions/vQuestionOne.php [ 155 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler('/Users/ravado/S...', Array)
#1 {main}
2012-01-14 17:34:33 --- ERROR: ErrorException [ 8 ]: Undefined variable: checkAsBest ~ APPPATH/views/questions/vQuestionOne.php [ 186 ]
2012-01-14 17:34:33 --- STRACE: ErrorException [ 8 ]: Undefined variable: checkAsBest ~ APPPATH/views/questions/vQuestionOne.php [ 186 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(186): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-14 17:42:57 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_ELSE ~ APPPATH/views/questions/vQuestionOne.php [ 68 ]
2012-01-14 17:42:57 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_ELSE ~ APPPATH/views/questions/vQuestionOne.php [ 68 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler('/Users/ravado/S...', Array)
#1 {main}
2012-01-14 20:46:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:46:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:46:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:46:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:46:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:46:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:46:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:46:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:46:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:46:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:46:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:46:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:46:44 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:46:44 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:49:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:49:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:49:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:49:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:49:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:49:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:49:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:49:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:49:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:49:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:49:27 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:49:27 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:49:28 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:49:28 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:52:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:52:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:52:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:52:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:52:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:52:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:52:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:52:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:52:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:52:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:52:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:52:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:52:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:52:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:53:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:53:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:53:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:53:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:53:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:53:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:53:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:53:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:53:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:53:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:53:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:53:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:53:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:53:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:53:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:53:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:53:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:53:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:53:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:53:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:53:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:53:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:53:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:53:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:53:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:53:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:53:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:53:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:34 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL peek was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-14 20:54:34 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL peek was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-14 20:54:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:54:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:54:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:57:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:57:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:57:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:57:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:57:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:57:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:57:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:57:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:57:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:57:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:57:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:57:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:57:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:57:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:58:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:58:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:58:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:58:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:58:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:58:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:58:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:58:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:58:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:58:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:58:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:58:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:58:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:58:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:58:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:58:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:58:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:58:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:58:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:58:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:58:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:58:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:58:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:58:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:58:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:58:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:58:30 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:58:30 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:59:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:59:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:59:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:59:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:59:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:59:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:59:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:59:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:59:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:59:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:59:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:59:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 20:59:08 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 20:59:08 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/peek-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:00:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:00:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/up_carrot.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:00:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:00:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:00:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:00:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:00:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:00:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:00:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:00:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:00:10 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:00:10 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:03:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:03:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:03:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:03:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:03:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:03:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:03:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:03:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:03:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:03:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:04:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:04:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:04:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:04:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:04:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:04:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:04:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:04:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:04:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:04:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:06:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:06:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:06:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:06:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:06:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:06:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:06:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:06:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:06:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:06:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:07:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:07:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:07:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:07:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:07:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:07:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:07:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:07:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:07:21 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:07:21 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:07:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:07:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:07:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:07:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:07:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:07:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:07:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:07:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:07:50 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:07:50 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:08:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:08:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:08:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:08:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:08:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:08:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:08:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:08:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:08:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:08:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:09:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:09:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:09:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:09:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:09:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:09:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:09:13 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:09:13 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:09:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:09:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:09:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:09:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:09:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:09:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/evernote-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:09:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:09:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:09:41 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:09:41 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:09:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:09:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:09:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:09:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:09:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:09:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:09:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:09:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:10:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:10:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/skitch-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:10:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:10:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/food-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:10:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:10:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/hello-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-14 21:10:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-14 21:10:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: about/media/img/product_icons/clearly-25.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}