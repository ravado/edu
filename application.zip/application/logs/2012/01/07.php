<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-01-07 18:48:31 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-07 18:48:31 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-07 18:48:48 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-07 18:48:48 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-07 18:48:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL search/search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-07 18:48:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL search/search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-07 18:49:25 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL search/search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-07 18:49:25 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL search/search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-07 18:49:26 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-07 18:49:26 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-07 18:49:30 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-07 18:49:30 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-07 18:49:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-07 18:49:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-07 18:50:50 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: missing ) at offset 70 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2012-01-07 18:50:50 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: missing ) at offset 70 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^search(?:/(?P...', 'search', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('search')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('search', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/search', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2012-01-07 18:50:58 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: missing ) at offset 70 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2012-01-07 18:50:58 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: missing ) at offset 70 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^search(?:/(?P...', 'search', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('search')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('search', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/search/', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2012-01-07 18:51:08 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: missing ) at offset 70 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2012-01-07 18:51:08 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: missing ) at offset 70 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^search(?:/(?P...', 'search/search', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('search/search')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('search/search', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/search/search', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2012-01-07 18:51:53 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: missing ) at offset 70 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2012-01-07 18:51:53 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: missing ) at offset 70 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^search(?:/(?P...', 'search/search', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('search/search')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('search/search', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/search/search', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2012-01-07 18:51:56 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: missing ) at offset 70 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2012-01-07 18:51:56 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: missing ) at offset 70 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^search(?:/(?P...', 'search', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('search')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('search', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/search', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2012-01-07 18:51:58 --- ERROR: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: missing ) at offset 70 ~ SYSPATH/classes/kohana/route.php [ 392 ]
2012-01-07 18:51:58 --- STRACE: ErrorException [ 2 ]: preg_match() [function.preg-match]: Compilation failed: missing ) at offset 70 ~ SYSPATH/classes/kohana/route.php [ 392 ]
--
#0 [internal function]: Kohana_Core::error_handler('#^search(?:/(?P...', 'search', NULL)
#1 /Users/ravado/Sites/edu/system/classes/kohana/route.php(392): preg_match('search')
#2 /Users/ravado/Sites/edu/system/classes/kohana/request.php(567): Kohana_Route->matches('search', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/request.php(785): Kohana_Request::process_uri('/search', NULL)
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(198): Kohana_Request->__construct()
#5 /Users/ravado/Sites/edu/index.php(108): Kohana_Request::factory()
#6 {main}
2012-01-07 18:52:14 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-07 18:52:14 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-07 18:52:20 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL search/search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-07 18:52:20 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL search/search was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-07 18:52:55 --- ERROR: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-01-07 18:52:55 --- STRACE: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/view.php(137): Kohana_View->set_filename('vSearch')
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(30): Kohana_View->__construct('vSearch', NULL)
#2 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(33): Kohana_View::factory('vSearch')
#3 /Users/ravado/Sites/edu/application/classes/controller/base.php(18): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Base->before()
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Search_Search))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#9 {main}
2012-01-07 18:53:00 --- ERROR: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-01-07 18:53:00 --- STRACE: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/view.php(137): Kohana_View->set_filename('vSearch')
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(30): Kohana_View->__construct('vSearch', NULL)
#2 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(33): Kohana_View::factory('vSearch')
#3 /Users/ravado/Sites/edu/application/classes/controller/base.php(18): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Base->before()
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Search_Search))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#9 {main}
2012-01-07 18:53:27 --- ERROR: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-01-07 18:53:27 --- STRACE: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/view.php(137): Kohana_View->set_filename('vSearch')
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(30): Kohana_View->__construct('vSearch', NULL)
#2 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(33): Kohana_View::factory('vSearch')
#3 /Users/ravado/Sites/edu/application/classes/controller/base.php(18): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Base->before()
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Search_Search))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#9 {main}
2012-01-07 18:54:06 --- ERROR: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-01-07 18:54:06 --- STRACE: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/view.php(137): Kohana_View->set_filename('vSearch')
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(30): Kohana_View->__construct('vSearch', NULL)
#2 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(33): Kohana_View::factory('vSearch')
#3 /Users/ravado/Sites/edu/application/classes/controller/base.php(18): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Base->before()
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Search_Search))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#9 {main}
2012-01-07 18:54:15 --- ERROR: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-01-07 18:54:15 --- STRACE: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/view.php(137): Kohana_View->set_filename('vSearch')
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(30): Kohana_View->__construct('vSearch', NULL)
#2 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(33): Kohana_View::factory('vSearch')
#3 /Users/ravado/Sites/edu/application/classes/controller/base.php(18): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Base->before()
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Search_Search))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#9 {main}
2012-01-07 18:54:52 --- ERROR: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-01-07 18:54:52 --- STRACE: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/view.php(137): Kohana_View->set_filename('vSearch')
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(30): Kohana_View->__construct('vSearch', NULL)
#2 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(33): Kohana_View::factory('vSearch')
#3 /Users/ravado/Sites/edu/application/classes/controller/base.php(18): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Base->before()
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Search_Search))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#9 {main}
2012-01-07 18:55:10 --- ERROR: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-01-07 18:55:10 --- STRACE: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/view.php(137): Kohana_View->set_filename('vSearch')
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(30): Kohana_View->__construct('vSearch', NULL)
#2 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(33): Kohana_View::factory('vSearch')
#3 /Users/ravado/Sites/edu/application/classes/controller/base.php(18): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Base->before()
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Search_Search))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#9 {main}
2012-01-07 18:56:29 --- ERROR: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-01-07 18:56:29 --- STRACE: View_Exception [ 0 ]: The requested view vSearch could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/view.php(137): Kohana_View->set_filename('vSearch')
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(30): Kohana_View->__construct('vSearch', NULL)
#2 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(33): Kohana_View::factory('vSearch')
#3 /Users/ravado/Sites/edu/application/classes/controller/base.php(18): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Base->before()
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Search_Search))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#9 {main}
2012-01-07 18:56:36 --- ERROR: View_Exception [ 0 ]: The requested view vSearchs could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-01-07 18:56:36 --- STRACE: View_Exception [ 0 ]: The requested view vSearchs could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/view.php(137): Kohana_View->set_filename('vSearchs')
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(30): Kohana_View->__construct('vSearchs', NULL)
#2 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(33): Kohana_View::factory('vSearchs')
#3 /Users/ravado/Sites/edu/application/classes/controller/base.php(18): Kohana_Controller_Template->before()
#4 [internal function]: Controller_Base->before()
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(103): ReflectionMethod->invoke(Object(Controller_Search_Search))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#8 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#9 {main}
2012-01-07 19:26:05 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL $(' was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-07 19:26:05 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL $(' was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-07 19:26:42 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL $(' was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-07 19:26:42 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL $(' was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-07 19:26:46 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL $(' was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-07 19:26:46 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL $(' was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-07 19:26:49 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL $(' was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-07 19:26:49 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL $(' was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-07 22:44:35 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-07 22:44:35 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-07 22:44:47 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-07 22:44:47 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-07 22:45:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-07 22:45:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-07 22:45:22 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-07 22:45:22 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-07 22:47:37 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-07 22:47:37 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-07 22:47:56 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-07 22:47:56 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-07 22:47:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-07 22:47:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-07 22:48:20 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-07 22:48:20 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-07 22:52:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-07 22:52:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-07 22:52:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-07 22:52:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-07 22:52:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-07 22:52:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-07 22:53:15 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-07 22:53:15 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: img/1loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}