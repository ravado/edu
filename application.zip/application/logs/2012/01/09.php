<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-01-09 00:00:44 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-09 00:00:44 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(31): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(70): Model_Mquestions->askQuestion()
#5 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-09 00:00:49 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-09 00:00:49 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(31): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(70): Model_Mquestions->askQuestion()
#5 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-09 00:00:55 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-09 00:00:55 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(31): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(70): Model_Mquestions->askQuestion()
#5 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-09 00:01:21 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-09 00:01:21 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(31): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(70): Model_Mquestions->askQuestion()
#5 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-09 00:01:28 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-09 00:01:28 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(31): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(70): Model_Mquestions->askQuestion()
#5 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-09 00:02:56 --- ERROR: ErrorException [ 8 ]: Object of class Database_MySQL_Result could not be converted to int ~ APPPATH/classes/model/mquestions.php [ 18 ]
2012-01-09 00:02:56 --- STRACE: ErrorException [ 8 ]: Object of class Database_MySQL_Result could not be converted to int ~ APPPATH/classes/model/mquestions.php [ 18 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(18): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(70): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 00:18:23 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 60 ]
2012-01-09 00:18:23 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 60 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(60): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 00:40:42 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 60 ]
2012-01-09 00:40:42 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 60 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(60): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 00:41:40 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 60 ]
2012-01-09 00:41:40 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 60 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(60): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 00:47:14 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 60 ]
2012-01-09 00:47:14 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 60 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(60): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 00:57:40 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/controller/questions/questions.php [ 65 ]
2012-01-09 00:57:40 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/controller/questions/questions.php [ 65 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(65): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 00:59:57 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/controller/questions/questions.php [ 65 ]
2012-01-09 00:59:57 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/controller/questions/questions.php [ 65 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(65): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 01:00:29 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/controller/questions/questions.php [ 65 ]
2012-01-09 01:00:29 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/controller/questions/questions.php [ 65 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(65): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 01:02:57 --- ERROR: ErrorException [ 8 ]: Undefined index:  наука ~ APPPATH/classes/controller/questions/questions.php [ 66 ]
2012-01-09 01:02:57 --- STRACE: ErrorException [ 8 ]: Undefined index:  наука ~ APPPATH/classes/controller/questions/questions.php [ 66 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(66): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 01:04:33 --- ERROR: ErrorException [ 8 ]: Undefined index:  наука ~ APPPATH/classes/controller/questions/questions.php [ 67 ]
2012-01-09 01:04:33 --- STRACE: ErrorException [ 8 ]: Undefined index:  наука ~ APPPATH/classes/controller/questions/questions.php [ 67 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(67): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 01:05:17 --- ERROR: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 69 ]
2012-01-09 01:05:17 --- STRACE: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 69 ]
--
#0 [internal function]: Kohana_Core::error_handler(', ', 'Array')
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(69): explode()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:06:04 --- ERROR: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 69 ]
2012-01-09 01:06:04 --- STRACE: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 69 ]
--
#0 [internal function]: Kohana_Core::error_handler(', ', 'Array')
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(69): explode()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:06:18 --- ERROR: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 69 ]
2012-01-09 01:06:18 --- STRACE: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 69 ]
--
#0 [internal function]: Kohana_Core::error_handler(', ', 'Array')
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(69): explode()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:06:39 --- ERROR: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 69 ]
2012-01-09 01:06:39 --- STRACE: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 69 ]
--
#0 [internal function]: Kohana_Core::error_handler(', ', 'Array')
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(69): explode()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:07:15 --- ERROR: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 69 ]
2012-01-09 01:07:15 --- STRACE: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 69 ]
--
#0 [internal function]: Kohana_Core::error_handler(', ', 'Array')
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(69): explode()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:07:21 --- ERROR: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 69 ]
2012-01-09 01:07:21 --- STRACE: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 69 ]
--
#0 [internal function]: Kohana_Core::error_handler(', ', 'Array')
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(69): explode()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:07:48 --- ERROR: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 70 ]
2012-01-09 01:07:48 --- STRACE: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 70 ]
--
#0 [internal function]: Kohana_Core::error_handler(', ', 'Array')
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(70): explode()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:09:16 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 71 ]
2012-01-09 01:09:16 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 71 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(71): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 01:09:28 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags[] ~ APPPATH/classes/controller/questions/questions.php [ 65 ]
2012-01-09 01:09:28 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags[] ~ APPPATH/classes/controller/questions/questions.php [ 65 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(65): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 01:09:50 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 71 ]
2012-01-09 01:09:50 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 71 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(71): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 01:10:17 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags[] ~ APPPATH/classes/controller/questions/questions.php [ 65 ]
2012-01-09 01:10:17 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags[] ~ APPPATH/classes/controller/questions/questions.php [ 65 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(65): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 01:10:36 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 71 ]
2012-01-09 01:10:36 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 71 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(71): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 01:11:29 --- ERROR: ErrorException [ 8 ]: Undefined index:  наука ~ APPPATH/classes/controller/questions/questions.php [ 66 ]
2012-01-09 01:11:29 --- STRACE: ErrorException [ 8 ]: Undefined index:  наука ~ APPPATH/classes/controller/questions/questions.php [ 66 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(66): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 01:12:32 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 71 ]
2012-01-09 01:12:32 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 71 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(71): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 01:13:57 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 71 ]
2012-01-09 01:13:57 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 71 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(71): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 01:16:27 --- ERROR: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 72 ]
2012-01-09 01:16:27 --- STRACE: ErrorException [ 8 ]: Array to string conversion ~ APPPATH/classes/controller/questions/questions.php [ 72 ]
--
#0 [internal function]: Kohana_Core::error_handler(', ', 'Array')
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(72): explode()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:18:13 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-09 01:18:13 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(81): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:19:23 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 69 ]
2012-01-09 01:19:23 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 69 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(69): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 01:19:40 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-09 01:19:40 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(81): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:19:59 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-09 01:19:59 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(81): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:20:38 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-09 01:20:38 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(81): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:22:17 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-09 01:22:17 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(84): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:22:51 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-09 01:22:51 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(84): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:23:04 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-09 01:23:04 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(84): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:24:02 --- ERROR: ErrorException [ 8 ]: Undefined index:  наука ~ APPPATH/classes/controller/questions/questions.php [ 68 ]
2012-01-09 01:24:02 --- STRACE: ErrorException [ 8 ]: Undefined index:  наука ~ APPPATH/classes/controller/questions/questions.php [ 68 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(68): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 01:24:20 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-09 01:24:20 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(84): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:25:04 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-09 01:25:04 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(85): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:25:27 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-09 01:25:27 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(86): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:25:31 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-09 01:25:31 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags_string ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(86): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-09 01:51:43 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/controller/questions/questions.php [ 67 ]
2012-01-09 01:51:43 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/classes/controller/questions/questions.php [ 67 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(67): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 17:22:25 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 66 ]
2012-01-09 17:22:25 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 66 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(66): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 17:22:50 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 60 ]
2012-01-09 17:22:50 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 60 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(60): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 17:30:50 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
2012-01-09 17:30:50 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(47): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 17:51:59 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
2012-01-09 17:51:59 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(47): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 17:52:03 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
2012-01-09 17:52:03 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(47): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 17:52:03 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
2012-01-09 17:52:03 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(47): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 17:52:04 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
2012-01-09 17:52:04 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(47): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 17:52:05 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
2012-01-09 17:52:05 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(47): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 18:50:57 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
2012-01-09 18:50:57 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(47): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 18:51:14 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
2012-01-09 18:51:14 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(47): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 18:51:18 --- ERROR: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
2012-01-09 18:51:18 --- STRACE: ErrorException [ 8 ]: Undefined variable: data ~ APPPATH/classes/controller/questions/questions.php [ 47 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(47): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 20:46:29 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 62 ]
2012-01-09 20:46:29 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 62 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(62): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-09 20:50:22 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 62 ]
2012-01-09 20:50:22 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/controller/questions/questions.php [ 62 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(62): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}