<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-01-19 15:50:42 --- ERROR: Database_Exception [ 1048 ]: Column 'id_subcategory' cannot be null [ INSERT INTO `questions_cat` (`id_question`, `id_subcategory`) VALUES (136, NULL) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 15:50:42 --- STRACE: Database_Exception [ 1048 ]: Column 'id_subcategory' cannot be null [ INSERT INTO `questions_cat` (`id_question`, `id_subcategory`) VALUES (136, NULL) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `qu...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(119): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 15:52:07 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`tags`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `public_date` DESC LIMIT 20 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 15:52:07 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`tags`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `public_date` DESC LIMIT 20 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(26): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 15:53:06 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`tags`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `public_date` DESC LIMIT 20 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 15:53:06 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`tags`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `public_date` DESC LIMIT 20 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(26): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 15:53:57 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`tags`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `public_date` DESC LIMIT 20 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 15:53:57 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`tags`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `public_date` DESC LIMIT 20 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(26): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 15:55:20 --- ERROR: Database_Exception [ 1048 ]: Column 'id_subcategory' cannot be null [ INSERT INTO `questions_cat` (`id_question`, `id_subcategory`) VALUES (139, NULL) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 15:55:20 --- STRACE: Database_Exception [ 1048 ]: Column 'id_subcategory' cannot be null [ INSERT INTO `questions_cat` (`id_question`, `id_subcategory`) VALUES (139, NULL) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `qu...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(119): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 15:57:11 --- ERROR: Database_Exception [ 1048 ]: Column 'id_subcategory' cannot be null [ INSERT INTO `questions_cat` (`id_question`, `id_subcategory`) VALUES (140, NULL) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 15:57:11 --- STRACE: Database_Exception [ 1048 ]: Column 'id_subcategory' cannot be null [ INSERT INTO `questions_cat` (`id_question`, `id_subcategory`) VALUES (140, NULL) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `qu...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(119): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 15:57:53 --- ERROR: Database_Exception [ 1048 ]: Column 'id_subcategory' cannot be null [ INSERT INTO `questions_cat` (`id_question`, `id_subcategory`) VALUES (141, NULL) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 15:57:53 --- STRACE: Database_Exception [ 1048 ]: Column 'id_subcategory' cannot be null [ INSERT INTO `questions_cat` (`id_question`, `id_subcategory`) VALUES (141, NULL) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `qu...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(119): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 16:05:16 --- ERROR: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ INSERT INTO `questions_cat` (`id_question`, `id_subcategory`) VALUES (142, (NULL, (68, 1), (69, 1), (70, 1), (71, 1), (72, 1))) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 16:05:16 --- STRACE: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ INSERT INTO `questions_cat` (`id_question`, `id_subcategory`) VALUES (142, (NULL, (68, 1), (69, 1), (70, 1), (71, 1), (72, 1))) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `qu...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(119): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 16:06:07 --- ERROR: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ INSERT INTO `questions_cat` (`id_question`, `id_subcategory`) VALUES (143, (NULL, 73, 1)) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 16:06:07 --- STRACE: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ INSERT INTO `questions_cat` (`id_question`, `id_subcategory`) VALUES (143, (NULL, 73, 1)) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `qu...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(119): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 16:06:28 --- ERROR: ErrorException [ 2 ]: array_merge() [function.array-merge]: Argument #2 is not an array ~ APPPATH/classes/model/mquestions.php [ 91 ]
2012-01-19 16:06:28 --- STRACE: ErrorException [ 2 ]: array_merge() [function.array-merge]: Argument #2 is not an array ~ APPPATH/classes/model/mquestions.php [ 91 ]
--
#0 [internal function]: Kohana_Core::error_handler(Array, NULL)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(91): array_merge(Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#3 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 16:11:16 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`tags`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `public_date` DESC LIMIT 20 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 16:11:16 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`tags`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `public_date` DESC LIMIT 20 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(26): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 16:12:27 --- ERROR: Database_Exception [ 1048 ]: Column 'id_subcategory' cannot be null [ INSERT INTO `questions_cat` (`id_question`, `id_subcategory`) VALUES (145, NULL) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 16:12:27 --- STRACE: Database_Exception [ 1048 ]: Column 'id_subcategory' cannot be null [ INSERT INTO `questions_cat` (`id_question`, `id_subcategory`) VALUES (145, NULL) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `qu...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(120): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 16:13:52 --- ERROR: ErrorException [ 2 ]: array_push() [function.array-push]: First argument should be an array ~ APPPATH/classes/model/mquestions.php [ 87 ]
2012-01-19 16:13:52 --- STRACE: ErrorException [ 2 ]: array_push() [function.array-push]: First argument should be an array ~ APPPATH/classes/model/mquestions.php [ 87 ]
--
#0 [internal function]: Kohana_Core::error_handler(NULL, 83)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(87): array_push(Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#3 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 16:16:40 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`tags`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `public_date` DESC LIMIT 20 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 16:16:40 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`tags`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `public_date` DESC LIMIT 20 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(26): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 16:17:16 --- ERROR: ErrorException [ 2 ]: array_push() [function.array-push]: First argument should be an array ~ APPPATH/classes/model/mquestions.php [ 87 ]
2012-01-19 16:17:16 --- STRACE: ErrorException [ 2 ]: array_push() [function.array-push]: First argument should be an array ~ APPPATH/classes/model/mquestions.php [ 87 ]
--
#0 [internal function]: Kohana_Core::error_handler(NULL, 86)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(87): array_push(Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#3 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 16:22:49 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 73 ]
2012-01-19 16:22:49 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 73 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(73): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-19 16:23:17 --- ERROR: ErrorException [ 2 ]: array_push() [function.array-push]: First argument should be an array ~ APPPATH/classes/model/mquestions.php [ 87 ]
2012-01-19 16:23:17 --- STRACE: ErrorException [ 2 ]: array_push() [function.array-push]: First argument should be an array ~ APPPATH/classes/model/mquestions.php [ 87 ]
--
#0 [internal function]: Kohana_Core::error_handler(NULL, 88)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(87): array_push(Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(83): Model_Mquestions->askQuestion()
#3 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 16:29:18 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`tags`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `public_date` DESC LIMIT 20 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 16:29:18 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`tags`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) ORDER BY `public_date` DESC LIMIT 20 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(26): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 18:09:55 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 5 ]
2012-01-19 18:09:55 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-19 18:10:27 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 12 ]
2012-01-19 18:10:27 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 12 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(12): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-19 18:20:06 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestions.php [ 5 ]
2012-01-19 18:20:06 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestions.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-19 18:44:21 --- ERROR: Database_Exception [ 1052 ]: Column 'id_question' in where clause is ambiguous [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) WHERE `id_question` > '0' ORDER BY `answers_count` DESC LIMIT 7 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 18:44:21 --- STRACE: Database_Exception [ 1052 ]: Column 'id_question' in where clause is ambiguous [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) WHERE `id_question` > '0' ORDER BY `answers_count` DESC LIMIT 7 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(52): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 18:44:37 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id_questions' in 'where clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) WHERE `id_questions` > '0' ORDER BY `answers_count` DESC LIMIT 7 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 18:44:37 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id_questions' in 'where clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) WHERE `id_questions` > '0' ORDER BY `answers_count` DESC LIMIT 7 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(52): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 18:44:40 --- ERROR: Database_Exception [ 1052 ]: Column 'id_question' in where clause is ambiguous [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) WHERE `id_question` > '0' ORDER BY `answers_count` DESC LIMIT 7 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 18:44:40 --- STRACE: Database_Exception [ 1052 ]: Column 'id_question' in where clause is ambiguous [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) WHERE `id_question` > '0' ORDER BY `answers_count` DESC LIMIT 7 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(52): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 18:44:47 --- ERROR: Database_Exception [ 1052 ]: Column 'id_question' in where clause is ambiguous [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) WHERE `id_question` > 0 ORDER BY `answers_count` DESC LIMIT 7 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 18:44:47 --- STRACE: Database_Exception [ 1052 ]: Column 'id_question' in where clause is ambiguous [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) WHERE `id_question` > 0 ORDER BY `answers_count` DESC LIMIT 7 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(52): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 18:58:35 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_cat.id_subcategory' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) LEFT JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) LEFT JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) ORDER BY `questions`.`public_date` DESC LIMIT 30 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 18:58:35 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_cat.id_subcategory' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) LEFT JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) LEFT JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) ORDER BY `questions`.`public_date` DESC LIMIT 30 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(26): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 19:04:48 --- ERROR: ErrorException [ 1 ]: Cannot use object of type Database_Query_Builder_Insert as array ~ APPPATH/classes/model/mquestions.php [ 134 ]
2012-01-19 19:04:48 --- STRACE: ErrorException [ 1 ]: Cannot use object of type Database_Query_Builder_Insert as array ~ APPPATH/classes/model/mquestions.php [ 134 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler(Array)
#1 {main}
2012-01-19 21:09:09 --- ERROR: ErrorException [ 8 ]: Undefined index: tags ~ APPPATH/views/questions/vQuestions.php [ 246 ]
2012-01-19 21:09:09 --- STRACE: ErrorException [ 8 ]: Undefined index: tags ~ APPPATH/views/questions/vQuestions.php [ 246 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(246): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 246, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-19 21:09:46 --- ERROR: ErrorException [ 8 ]: Undefined variable: key ~ APPPATH/views/questions/vQuestions.php [ 217 ]
2012-01-19 21:09:46 --- STRACE: ErrorException [ 8 ]: Undefined variable: key ~ APPPATH/views/questions/vQuestions.php [ 217 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(217): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 217, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-19 21:10:43 --- ERROR: ErrorException [ 8 ]: Undefined index: tags ~ APPPATH/views/questions/vQuestions.php [ 147 ]
2012-01-19 21:10:43 --- STRACE: ErrorException [ 8 ]: Undefined index: tags ~ APPPATH/views/questions/vQuestions.php [ 147 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(147): Kohana_Core::error_handler(8, 'Undefined index...', '/Users/ravado/S...', 147, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-19 21:24:10 --- ERROR: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ MODPATH/database/classes/kohana/database/mysql/result.php [ 67 ]
2012-01-19 21:24:10 --- STRACE: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ MODPATH/database/classes/kohana/database/mysql/result.php [ 67 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-01-19 21:24:41 --- ERROR: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ MODPATH/database/classes/kohana/database/mysql/result.php [ 33 ]
2012-01-19 21:24:41 --- STRACE: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ MODPATH/database/classes/kohana/database/mysql/result.php [ 33 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-01-19 21:50:25 --- ERROR: ErrorException [ 8 ]: Undefined variable: i ~ APPPATH/views/questions/vQuestions.php [ 208 ]
2012-01-19 21:50:25 --- STRACE: ErrorException [ 8 ]: Undefined variable: i ~ APPPATH/views/questions/vQuestions.php [ 208 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(208): Kohana_Core::error_handler(8, 'Undefined varia...', '/Users/ravado/S...', 208, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-19 22:10:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-19 22:10:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-19 22:10:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-19 22:10:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-19 22:13:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-19 22:13:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-19 22:13:42 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-19 22:13:42 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-19 22:26:20 --- ERROR: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ APPPATH/views/questions/vQuestions.php [ 218 ]
2012-01-19 22:26:20 --- STRACE: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ APPPATH/views/questions/vQuestions.php [ 218 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-01-19 22:33:23 --- ERROR: ErrorException [ 8 ]: Object of class Database_MySQL_Result could not be converted to int ~ APPPATH/views/questions/vQuestions.php [ 220 ]
2012-01-19 22:33:23 --- STRACE: ErrorException [ 8 ]: Object of class Database_MySQL_Result could not be converted to int ~ APPPATH/views/questions/vQuestions.php [ 220 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(220): Kohana_Core::error_handler(8, 'Object of class...', '/Users/ravado/S...', 220, Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString()
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture('/Users/ravado/S...', Array)
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after()
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-19 22:37:02 --- ERROR: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ APPPATH/views/questions/vQuestions.php [ 236 ]
2012-01-19 22:37:02 --- STRACE: ErrorException [ 1 ]: Maximum execution time of 30 seconds exceeded ~ APPPATH/views/questions/vQuestions.php [ 236 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-01-19 22:43:38 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers`, `vote`.`value` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = 143) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = 143 AND `questions_and_answers`.`id_answers` IS null) LEFT JOIN `vote` ON (`vote`.`id_user` = 1 AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 22:43:38 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.tags' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers`, `vote`.`value` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = 143) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = 143 AND `questions_and_answers`.`id_answers` IS null) LEFT JOIN `vote` ON (`vote`.`id_user` = 1 AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(167): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(136): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 22:51:18 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::get_all() ~ APPPATH/classes/model/mquestions.php [ 25 ]
2012-01-19 22:51:18 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::get_all() ~ APPPATH/classes/model/mquestions.php [ 25 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-01-19 22:51:26 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::find_all() ~ APPPATH/classes/model/mquestions.php [ 25 ]
2012-01-19 22:51:26 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::find_all() ~ APPPATH/classes/model/mquestions.php [ 25 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-01-19 23:27:00 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::limit_by() ~ APPPATH/classes/model/mquestions.php [ 22 ]
2012-01-19 23:27:00 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::limit_by() ~ APPPATH/classes/model/mquestions.php [ 22 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-01-19 23:28:56 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions' in 'group statement' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) LEFT JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) LEFT JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) GROUP BY `questions` ORDER BY `questions`.`public_date` DESC ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 23:28:56 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions' in 'group statement' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) LEFT JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) LEFT JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) GROUP BY `questions` ORDER BY `questions`.`public_date` DESC ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(26): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-19 23:29:15 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.id_questions' in 'group statement' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) LEFT JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) LEFT JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) GROUP BY `questions`.`id_questions` ORDER BY `questions`.`public_date` DESC ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-19 23:29:15 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.id_questions' in 'group statement' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `questions`.`public_date`, `questions`.`answers_count`, `users`.`username`, `questions_cat`.`id_question`, `questions_cat`.`id_subcategory`, `subcategory`.`id_subcategory`, `subcategory`.`stitle` FROM `questions` JOIN `users` ON (`questions`.`id_user` = `users`.`id`) LEFT JOIN `questions_cat` ON (`questions_cat`.`id_question` = `questions`.`id_question`) LEFT JOIN `subcategory` ON (`subcategory`.`id_subcategory` = `questions_cat`.`id_subcategory`) GROUP BY `questions`.`id_questions` ORDER BY `questions`.`public_date` DESC ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(26): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#3 [internal function]: Controller_Questions_Questions->action_index()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}