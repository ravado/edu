<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-01-13 18:54:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-13 18:54:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-13 18:54:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-13 18:54:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-13 20:30:11 --- ERROR: ErrorException [ 8 ]: Undefined index:  username ~ APPPATH/views/questions/vQuestionOne.php [ 17 ]
2012-01-13 20:30:11 --- STRACE: ErrorException [ 8 ]: Undefined index:  username ~ APPPATH/views/questions/vQuestionOne.php [ 17 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(17): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-13 20:31:14 --- ERROR: ErrorException [ 8 ]: Undefined index:  username ~ APPPATH/views/questions/vQuestionOne.php [ 17 ]
2012-01-13 20:31:14 --- STRACE: ErrorException [ 8 ]: Undefined index:  username ~ APPPATH/views/questions/vQuestionOne.php [ 17 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(17): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-13 20:58:23 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.id_question' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`id`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`rating`, `answers`.`best` FROM `questions` ANSWERS JOIN `users` ON (`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 20:58:23 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.id_question' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`id`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`rating`, `answers`.`best` FROM `questions` ANSWERS JOIN `users` ON (`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(94): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:00:10 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.id_question' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`id`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`rating`, `answers`.`best` FROM `questions` ANSWERS JOIN `users` ON (`questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:00:10 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.id_question' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`id`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`rating`, `answers`.`best` FROM `questions` ANSWERS JOIN `users` ON (`questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(94): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:00:14 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.id_question' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`id`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`rating`, `answers`.`best` FROM `questions` ANSWERS JOIN `users` ON (`questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:00:14 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.id_question' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`id`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`rating`, `answers`.`best` FROM `questions` ANSWERS JOIN `users` ON (`questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(94): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:00:16 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.id_question' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`id`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`rating`, `answers`.`best` FROM `questions` ANSWERS JOIN `users` ON (`questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:00:16 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.id_question' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`id`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`rating`, `answers`.`best` FROM `questions` ANSWERS JOIN `users` ON (`questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(94): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:00:42 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`id`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`rating`, `answers`.`best` FROM `questions` JOIN `users` ON (`questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:00:42 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`id`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`rating`, `answers`.`best` FROM `questions` JOIN `users` ON (`questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(94): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:02:17 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`id`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`rating`, `answers`.`best` FROM `questions` JOIN `users` ON (`questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:02:17 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`id`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`rating`, `answers`.`best` FROM `questions` JOIN `users` ON (`questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(94): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:02:19 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`id`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`rating`, `answers`.`best` FROM `questions` JOIN `users` ON (`questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:02:19 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`id`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`answer_text`, `answers`.`rating`, `answers`.`best` FROM `questions` JOIN `users` ON (`questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(94): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:03:51 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` JOIN `users` ON (`questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:03:51 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` JOIN `users` ON (`questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(90): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:04:39 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:04:39 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(90): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:05:34 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'users.username' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` JOIN `questions_and_answers` ON (`users`.`id` = `questions`.`id_user`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:05:34 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'users.username' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` JOIN `questions_and_answers` ON (`users`.`id` = `questions`.`id_user`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(90): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:05:52 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.id_question' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` USERS JOIN `questions_and_answers` ON (`users`.`id` = `questions`.`id_user`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:05:52 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.id_question' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` USERS JOIN `questions_and_answers` ON (`users`.`id` = `questions`.`id_user`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(90): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:07:16 --- ERROR: Database_Exception [ 1054 ]: Unknown column '1' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user`) JOIN `questions_and_answers` ON (`questions_and_answers`.`id_answers` = `1`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:07:16 --- STRACE: Database_Exception [ 1054 ]: Unknown column '1' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user`) JOIN `questions_and_answers` ON (`questions_and_answers`.`id_answers` = `1`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(90): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:07:45 --- ERROR: Database_Exception [ 1054 ]: Unknown column '1' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user`) JOIN `questions_and_answers` ON (`questions_and_answers`.`id_answers` = `1`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:07:45 --- STRACE: Database_Exception [ 1054 ]: Unknown column '1' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user`) JOIN `questions_and_answers` ON (`questions_and_answers`.`id_answers` = `1`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(91): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:08:08 --- ERROR: Database_Exception [ 1054 ]: Unknown column '0' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user`) JOIN `questions_and_answers` ON (`questions_and_answers`.`id_answers` = `0`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:08:08 --- STRACE: Database_Exception [ 1054 ]: Unknown column '0' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user`) JOIN `questions_and_answers` ON (`questions_and_answers`.`id_answers` = `0`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(91): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:09:03 --- ERROR: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user`) JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:09:03 --- STRACE: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user`) JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(91): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:15:11 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'answers.id_answers' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user`) JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `questions`.`id_question`) JOIN `answers` ON (`answers`.`id_answers` = `questions_and_answers`.`id_questions`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:15:11 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'answers.id_answers' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user`) JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `questions`.`id_question`) JOIN `answers` ON (`answers`.`id_answers` = `questions_and_answers`.`id_questions`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(92): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:16:40 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user`) JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_questions`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:16:40 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_answers`, `answers`.`id_user` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user`) JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_questions`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(92): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:25:33 --- ERROR: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions_and_answers`, `users`.`username`, `users`.`karma`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) JOIN `users` ON (`users`.`id` = `answers`.`id_user`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:25:33 --- STRACE: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions_and_answers`, `users`.`username`, `users`.`karma`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) JOIN `users` ON (`users`.`id` = `answers`.`id_user`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:26:38 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'users.username' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions_and_answers`, `users`.`username`, `users`.`karma`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:26:38 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'users.username' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions_and_answers`, `users`.`username`, `users`.`karma`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:27:03 --- ERROR: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions_and_answers`, `questions_and_answers`.`id_questions`, `users`.`username`, `users`.`karma`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) JOIN `users` ON (`users`.`id` = `answers`.`id_user`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:27:03 --- STRACE: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions_and_answers`, `questions_and_answers`.`id_questions`, `users`.`username`, `users`.`karma`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) JOIN `users` ON (`users`.`id` = `answers`.`id_user`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(99): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:27:16 --- ERROR: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions_and_answers`, `questions_and_answers`.`id_questions`, `users`.`username`, `users`.`karma`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) JOIN `users` ON (`users`.`id` = `answers`.`id_user`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:27:16 --- STRACE: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions_and_answers`, `questions_and_answers`.`id_questions`, `users`.`username`, `users`.`karma`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) JOIN `users` ON (`users`.`id` = `answers`.`id_user`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(99): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:28:06 --- ERROR: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions_and_answers`, `questions_and_answers`.`id_questions`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:28:06 --- STRACE: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions_and_answers`, `questions_and_answers`.`id_questions`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:29:25 --- ERROR: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions_and_answers`, `questions_and_answers`.`id_questions`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:29:25 --- STRACE: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions_and_answers`, `questions_and_answers`.`id_questions`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:30:12 --- ERROR: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:30:12 --- STRACE: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(97): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:30:56 --- ERROR: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:30:56 --- STRACE: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(97): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:32:43 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.id_question' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `questions`.`id_question`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:32:43 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.id_question' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `questions`.`id_question`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(97): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:33:44 --- ERROR: Database_Exception [ 1054 ]: Unknown column '1' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `1`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:33:44 --- STRACE: Database_Exception [ 1054 ]: Unknown column '1' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `1`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(97): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:33:53 --- ERROR: Database_Exception [ 1054 ]: Unknown column '1' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `1`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:33:53 --- STRACE: Database_Exception [ 1054 ]: Unknown column '1' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `1`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(97): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:34:09 --- ERROR: Database_Exception [ 1054 ]: Unknown column '1' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `1`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:34:09 --- STRACE: Database_Exception [ 1054 ]: Unknown column '1' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = `1`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(97): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:35:17 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answer' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_answer` = `1`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:35:17 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answer' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `answers` JOIN `questions_and_answers` ON (`questions_and_answers`.`id_answer` = `1`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(97): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:36:24 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answer' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `questions_and_answers` JOIN `answers` ON (`questions_and_answers`.`id_answer` = `answer`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:36:24 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answer' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `questions_and_answers` JOIN `answers` ON (`questions_and_answers`.`id_answer` = `answer`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(97): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:36:38 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'answer.id_answer' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `questions_and_answers` JOIN `answers` ON (`questions_and_answers`.`id_answers` = `answer`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:36:38 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'answer.id_answer' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer` FROM `questions_and_answers` JOIN `answers` ON (`questions_and_answers`.`id_answers` = `answer`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(97): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:36:48 --- ERROR: ErrorException [ 8 ]: Undefined index:  title ~ APPPATH/classes/controller/questions/questions.php [ 134 ]
2012-01-13 21:36:48 --- STRACE: ErrorException [ 8 ]: Undefined index:  title ~ APPPATH/classes/controller/questions/questions.php [ 134 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(134): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_question(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-13 21:37:06 --- ERROR: ErrorException [ 8 ]: Undefined index:  title ~ APPPATH/views/questions/vQuestionOne.php [ 17 ]
2012-01-13 21:37:06 --- STRACE: ErrorException [ 8 ]: Undefined index:  title ~ APPPATH/views/questions/vQuestionOne.php [ 17 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(17): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-13 21:38:48 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'answers.text' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer`, `answers`.`text` FROM `questions_and_answers` JOIN `answers` ON (`questions_and_answers`.`id_answers` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:38:48 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'answers.text' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer`, `answers`.`text` FROM `questions_and_answers` JOIN `answers` ON (`questions_and_answers`.`id_answers` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:40:34 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`questions_and_answers`.`id_answers` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:40:34 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`questions_and_answers`.`id_answers` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:41:20 --- ERROR: Database_Exception [ 1054 ]: Unknown column '1' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`questions_and_answers`.`id_answers` = `answers`.`id_answer`) JOIN `users` ON (`users`.`id` = `1`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:41:20 --- STRACE: Database_Exception [ 1054 ]: Unknown column '1' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`questions_and_answers`.`id_answers` = `answers`.`id_answer`) JOIN `users` ON (`users`.`id` = `1`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:46:12 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'users.username' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_user`, `users`.`username`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`questions_and_answers`.`id_answers` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:46:12 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'users.username' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_user`, `users`.`username`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`questions_and_answers`.`id_answers` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:47:20 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'answers.id_user' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_user`, `users`.`username`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `users` ON (`users`.`id` = `answers`.`id_user`) JOIN `answers` ON (`questions_and_answers`.`id_answers` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 21:47:20 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'answers.id_user' in 'on clause' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_user`, `users`.`username`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `users` ON (`users`.`id` = `answers`.`id_user`) JOIN `answers` ON (`questions_and_answers`.`id_answers` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 21:51:11 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestionOne.php [ 6 ]
2012-01-13 21:51:11 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestionOne.php [ 6 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(6): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-13 21:51:54 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::joinleft() ~ APPPATH/classes/model/mquestions.php [ 96 ]
2012-01-13 21:51:54 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::joinleft() ~ APPPATH/classes/model/mquestions.php [ 96 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler('24')
#1 {main}
2012-01-13 21:52:00 --- ERROR: ErrorException [ 8 ]: Undefined property: Database_Query_Builder_Select::$join ~ APPPATH/classes/model/mquestions.php [ 96 ]
2012-01-13 21:52:00 --- STRACE: ErrorException [ 8 ]: Undefined property: Database_Query_Builder_Select::$join ~ APPPATH/classes/model/mquestions.php [ 96 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(96): Kohana_Core::error_handler('24')
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion()
#2 [internal function]: Controller_Questions_Questions->action_question(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-13 22:14:34 --- ERROR: ErrorException [ 1 ]: Call to undefined function on() ~ APPPATH/classes/model/mquestions.php [ 96 ]
2012-01-13 22:14:34 --- STRACE: ErrorException [ 1 ]: Call to undefined function on() ~ APPPATH/classes/model/mquestions.php [ 96 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler('24')
#1 {main}
2012-01-13 22:34:45 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_questions_and_answers' in 'field list' [ SELECT `questions_and_answers`.`id_questions_and_answers`, `answers`.`id_user`, `users`.`username`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 22:34:45 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_questions_and_answers' in 'field list' [ SELECT `questions_and_answers`.`id_questions_and_answers`, `answers`.`id_user`, `users`.`username`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 22:35:25 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'users.username' in 'field list' [ SELECT `answers`.`id_user`, `users`.`username`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 22:35:25 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'users.username' in 'field list' [ SELECT `answers`.`id_user`, `users`.`username`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 22:35:38 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'on clause' [ SELECT `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 22:35:38 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'on clause' [ SELECT `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 22:35:47 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'on clause' [ SELECT `answers`.`id_user`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 22:35:47 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'on clause' [ SELECT `answers`.`id_user`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 22:37:05 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'on clause' [ SELECT `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers` AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 22:37:05 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'on clause' [ SELECT `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers` AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 22:37:39 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_questions_and_answers' in 'field list' [ SELECT `questions_and_answers`.`id_questions_and_answers`, `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers` AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 22:37:39 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_questions_and_answers' in 'field list' [ SELECT `questions_and_answers`.`id_questions_and_answers`, `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers` AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 22:38:15 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'on clause' [ SELECT `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers` AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 22:38:15 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'on clause' [ SELECT `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers` AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 22:38:56 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers` AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 22:38:56 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers` AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 22:43:39 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = questions_and_answers.id_answers AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 22:43:39 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = questions_and_answers.id_answers AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 22:44:16 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = questions_and_answers.id_answers AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 22:44:16 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = questions_and_answers.id_answers AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 22:44:23 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = 'questions_and_answers.id_answers' AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 22:44:23 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = 'questions_and_answers.id_answers' AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 22:44:54 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.'id_answers' AND `users`.`id` = `answers`.`id_answer`)' at line 1 [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = 'questions_and_answers'.'id_answers' AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 22:44:54 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '.'id_answers' AND `users`.`id` = `answers`.`id_answer`)' at line 1 [ SELECT `questions_and_answers`.`id_answers`, `answers`.`id_user`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = 'questions_and_answers'.'id_answers' AND `users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 22:47:03 --- ERROR: Database_Exception [ 1066 ]: Not unique table/alias: 'users' [ SELECT `questions_and_answers`.`id_questions_and_answers`, `answers`.`id_user`, `users`.`username`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) JOIN `users` ON (`users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 22:47:03 --- STRACE: Database_Exception [ 1066 ]: Not unique table/alias: 'users' [ SELECT `questions_and_answers`.`id_questions_and_answers`, `answers`.`id_user`, `users`.`username`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` USERS JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) JOIN `users` ON (`users`.`id` = `answers`.`id_answer`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(98): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 22:47:57 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::find_all() ~ APPPATH/classes/model/mquestions.php [ 96 ]
2012-01-13 22:47:57 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::find_all() ~ APPPATH/classes/model/mquestions.php [ 96 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler('24')
#1 {main}
2012-01-13 22:48:18 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::find_all() ~ APPPATH/classes/model/mquestions.php [ 96 ]
2012-01-13 22:48:18 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::find_all() ~ APPPATH/classes/model/mquestions.php [ 96 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler('24')
#1 {main}
2012-01-13 22:48:28 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::find_all() ~ APPPATH/classes/model/mquestions.php [ 96 ]
2012-01-13 22:48:28 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Select::find_all() ~ APPPATH/classes/model/mquestions.php [ 96 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler('24')
#1 {main}
2012-01-13 23:07:14 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'answer.public_date' in 'field list' [ SELECT `questions_and_answers`.`id_questions_and_answers`, `answer`.`public_date`, `answers`.`rating`, `answers`.`best`, `answers`.`id_user`, `users`.`username`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 23:07:14 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'answer.public_date' in 'field list' [ SELECT `questions_and_answers`.`id_questions_and_answers`, `answer`.`public_date`, `answers`.`rating`, `answers`.`best`, `answers`.`id_user`, `users`.`username`, `answers`.`id_answer`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(101): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 23:15:26 --- ERROR: ErrorException [ 8 ]: Undefined offset:  1 ~ APPPATH/views/questions/vQuestionOne.php [ 6 ]
2012-01-13 23:15:26 --- STRACE: ErrorException [ 8 ]: Undefined offset:  1 ~ APPPATH/views/questions/vQuestionOne.php [ 6 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(6): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-13 23:15:43 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestionOne.php [ 24 ]
2012-01-13 23:15:43 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestionOne.php [ 24 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(24): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-13 23:15:58 --- ERROR: ErrorException [ 8 ]: Undefined index:  title ~ APPPATH/views/questions/vQuestionOne.php [ 24 ]
2012-01-13 23:15:58 --- STRACE: ErrorException [ 8 ]: Undefined index:  title ~ APPPATH/views/questions/vQuestionOne.php [ 24 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(24): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-13 23:23:06 --- ERROR: ErrorException [ 8 ]: Undefined index:  popular ~ APPPATH/views/questions/vQuestionOne.php [ 52 ]
2012-01-13 23:23:06 --- STRACE: ErrorException [ 8 ]: Undefined index:  popular ~ APPPATH/views/questions/vQuestionOne.php [ 52 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(52): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-13 23:23:25 --- ERROR: ErrorException [ 8 ]: Undefined variable: key ~ APPPATH/views/questions/vQuestionOne.php [ 52 ]
2012-01-13 23:23:25 --- STRACE: ErrorException [ 8 ]: Undefined variable: key ~ APPPATH/views/questions/vQuestionOne.php [ 52 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(52): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-13 23:31:07 --- ERROR: Database_Exception [ 1054 ]: Unknown column '32' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = `32`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 23:31:07 --- STRACE: Database_Exception [ 1054 ]: Unknown column '32' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = `32`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(92): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('32')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-13 23:31:20 --- ERROR: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-13 23:31:20 --- STRACE: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(92): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(132): Model_Mquestions->getOneQuestion('24')
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}