<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-01-16 00:00:40 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'vote.id_q&a' in 'where clause' [ SELECT `vote`.`id_vote`, `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions` FROM `vote` LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions_and_answers` = 46) WHERE `vote`.`id_user` = '5' AND `vote`.`id_q&a` = 46 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 00:00:40 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'vote.id_q&a' in 'where clause' [ SELECT `vote`.`id_vote`, `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions` FROM `vote` LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions_and_answers` = 46) WHERE `vote`.`id_user` = '5' AND `vote`.`id_q&a` = 46 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `vote`.`...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(228): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteUp()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:01:18 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 230 ]
2012-01-16 00:01:18 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 230 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(230): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp()
#2 [internal function]: Controller_Questions_Qhid->action_voteUp(Object(Controller_Questions_Qhid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-16 00:03:31 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 230 ]
2012-01-16 00:03:31 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 230 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(230): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp()
#2 [internal function]: Controller_Questions_Qhid->action_voteUp(Object(Controller_Questions_Qhid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-16 00:04:44 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 230 ]
2012-01-16 00:04:44 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 230 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(230): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp()
#2 [internal function]: Controller_Questions_Qhid->action_voteUp(Object(Controller_Questions_Qhid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-16 00:04:49 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 230 ]
2012-01-16 00:04:49 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 230 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(230): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp()
#2 [internal function]: Controller_Questions_Qhid->action_voteUp(Object(Controller_Questions_Qhid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-16 00:04:59 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 230 ]
2012-01-16 00:04:59 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/classes/model/mquestions.php [ 230 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(230): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp()
#2 [internal function]: Controller_Questions_Qhid->action_voteUp(Object(Controller_Questions_Qhid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-16 00:08:28 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 227 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
2012-01-16 00:08:28 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 227 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/where.php(30): Kohana_Core::error_handler()
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(227): Kohana_Database_Query_Builder_Where->where(Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp()
#3 [internal function]: Controller_Questions_Qhid->action_voteUp(Object(Controller_Questions_Qhid))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:10:21 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 227 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
2012-01-16 00:10:21 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 227 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/where.php(30): Kohana_Core::error_handler()
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(227): Kohana_Database_Query_Builder_Where->where(Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp()
#3 [internal function]: Controller_Questions_Qhid->action_voteUp(Object(Controller_Questions_Qhid))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:10:35 --- ERROR: Database_Exception [ 1054 ]: Unknown column '5' in 'on clause' [ SELECT `vote`.`id_vote`, `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions` FROM `questions_and_answers` RIGHT JOIN `vote` ON (`vote`.`id_user` = `5` AND `vote`.`id_qa` = 46) WHERE `questions_and_answers`.`id_questions_and_answers` = 46 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 00:10:35 --- STRACE: Database_Exception [ 1054 ]: Unknown column '5' in 'on clause' [ SELECT `vote`.`id_vote`, `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions` FROM `questions_and_answers` RIGHT JOIN `vote` ON (`vote`.`id_user` = `5` AND `vote`.`id_qa` = 46) WHERE `questions_and_answers`.`id_questions_and_answers` = 46 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `vote`.`...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(229): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteUp()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:16:48 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'value' in 'field list' [ INSERT INTO `vote` (`id_user`, `id_qa`, `value`) VALUES ('5', ' 48', '1') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 00:16:48 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'value' in 'field list' [ INSERT INTO `vote` (`id_user`, `id_qa`, `value`) VALUES ('5', ' 48', '1') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `vo...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(241): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteUp()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:17:42 --- ERROR: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = '50' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 00:17:42 --- STRACE: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = '50' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(248): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteUp()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:21:21 --- ERROR: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = 50 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 00:21:21 --- STRACE: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = 50 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(248): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteUp()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:21:41 --- ERROR: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = 51 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 00:21:41 --- STRACE: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = 51 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(248): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteUp()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:22:30 --- ERROR: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = 50 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 00:22:30 --- STRACE: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = 50 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(248): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteUp()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:24:38 --- ERROR: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = 50 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 00:24:38 --- STRACE: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = 50 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(248): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteUp()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:25:42 --- ERROR: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = 50 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 00:25:42 --- STRACE: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = 50 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(248): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteUp()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:25:52 --- ERROR: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = 51 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 00:25:52 --- STRACE: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = 51 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(248): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteUp()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:26:29 --- ERROR: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = 50 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 00:26:29 --- STRACE: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating+1 WHERE `id_answer` = 50 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(248): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteUp()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:39:16 --- ERROR: ErrorException [ 8 ]: Undefined index:  value ~ APPPATH/classes/model/mquestions.php [ 255 ]
2012-01-16 00:39:16 --- STRACE: ErrorException [ 8 ]: Undefined index:  value ~ APPPATH/classes/model/mquestions.php [ 255 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(255): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp()
#2 [internal function]: Controller_Questions_Qhid->action_voteUp(Object(Controller_Questions_Qhid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-16 00:40:05 --- ERROR: ErrorException [ 8 ]: Undefined index:  value ~ APPPATH/classes/model/mquestions.php [ 255 ]
2012-01-16 00:40:05 --- STRACE: ErrorException [ 8 ]: Undefined index:  value ~ APPPATH/classes/model/mquestions.php [ 255 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(255): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp()
#2 [internal function]: Controller_Questions_Qhid->action_voteUp(Object(Controller_Questions_Qhid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-16 00:40:08 --- ERROR: ErrorException [ 8 ]: Undefined index:  value ~ APPPATH/classes/model/mquestions.php [ 255 ]
2012-01-16 00:40:08 --- STRACE: ErrorException [ 8 ]: Undefined index:  value ~ APPPATH/classes/model/mquestions.php [ 255 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(255): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp()
#2 [internal function]: Controller_Questions_Qhid->action_voteUp(Object(Controller_Questions_Qhid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-16 00:41:04 --- ERROR: ErrorException [ 8 ]: Undefined index:  vote.value ~ APPPATH/classes/model/mquestions.php [ 255 ]
2012-01-16 00:41:04 --- STRACE: ErrorException [ 8 ]: Undefined index:  vote.value ~ APPPATH/classes/model/mquestions.php [ 255 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(255): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp()
#2 [internal function]: Controller_Questions_Qhid->action_voteUp(Object(Controller_Questions_Qhid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-16 00:42:43 --- ERROR: ErrorException [ 8 ]: Undefined index:  vote.value ~ APPPATH/classes/model/mquestions.php [ 255 ]
2012-01-16 00:42:43 --- STRACE: ErrorException [ 8 ]: Undefined index:  vote.value ~ APPPATH/classes/model/mquestions.php [ 255 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(255): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp()
#2 [internal function]: Controller_Questions_Qhid->action_voteUp(Object(Controller_Questions_Qhid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-16 00:46:45 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') WHERE `questions_and_answers`.`id_questions_and_answers` =' at line 1 [ SELECT `vote`.`id_vote`, `vote`.`value`, `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions` FROM `questions_and_answers` LEFT JOIN `vote` ON (`vote`.`id_user` = 5 AND `vote`.`id_qa` =  ) WHERE `questions_and_answers`.`id_questions_and_answers` = ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 00:46:45 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') WHERE `questions_and_answers`.`id_questions_and_answers` =' at line 1 [ SELECT `vote`.`id_vote`, `vote`.`value`, `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions` FROM `questions_and_answers` LEFT JOIN `vote` ON (`vote`.`id_user` = 5 AND `vote`.`id_qa` =  ) WHERE `questions_and_answers`.`id_questions_and_answers` = ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `vote`.`...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(229): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteUp()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:51:30 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 70 ]
2012-01-16 00:51:30 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 70 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(70): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-16 00:51:30 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 70 ]
2012-01-16 00:51:30 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 70 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(70): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-16 00:51:48 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = ) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =  AND `questions_and_answers`.`id_answers` IS null) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 00:51:48 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = ) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =  AND `questions_and_answers`.`id_answers` IS null) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(95): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(133): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:51:48 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = ) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =  AND `questions_and_answers`.`id_answers` IS null) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 00:51:48 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = ) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =  AND `questions_and_answers`.`id_answers` IS null) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(95): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(133): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 00:55:07 --- ERROR: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 114 ]
2012-01-16 00:55:07 --- STRACE: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 114 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(114): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-16 00:55:07 --- ERROR: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 114 ]
2012-01-16 00:55:07 --- STRACE: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 114 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(114): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-16 01:17:22 --- ERROR: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `questions` SET `answers_count` = answers_count+1, `0` = 'public_date' WHERE `id_question` = 51 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 01:17:22 --- STRACE: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `questions` SET `answers_count` = answers_count+1, `0` = 'public_date' WHERE `id_question` = 51 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(147): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(17): Model_Mquestions->addAnswer(Array)
#3 [internal function]: Controller_Questions_Qhid->action_addAnswer()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 01:17:36 --- ERROR: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `questions` SET `answers_count` = answers_count+1, `0` = 'public_date' WHERE `id_question` = 51 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 01:17:36 --- STRACE: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `questions` SET `answers_count` = answers_count+1, `0` = 'public_date' WHERE `id_question` = 51 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(147): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(17): Model_Mquestions->addAnswer(Array)
#3 [internal function]: Controller_Questions_Qhid->action_addAnswer()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 15:58:49 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/question/edu.ka ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-16 15:58:49 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: questions/question/edu.ka ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-16 16:27:48 --- ERROR: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating-2 WHERE `id_answer` = 59 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 16:27:48 --- STRACE: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `answers` SET `0` = 'rating', `1` = rating-2 WHERE `id_answer` = 59 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(320): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(71): Model_Mquestions->voteDown(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteDown()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 16:33:35 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 70 ]
2012-01-16 16:33:35 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 70 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(70): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-16 16:38:01 --- ERROR: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `vote` SET `0` = 'value', `1` = '-1' WHERE `id_qa` = ' 64' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 16:38:01 --- STRACE: Database_Exception [ 1054 ]: Unknown column '0' in 'field list' [ UPDATE `vote` SET `0` = 'value', `1` = '-1' WHERE `id_qa` = ' 64' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `vote` S...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(313): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(71): Model_Mquestions->voteDown(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteDown()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 17:14:17 --- ERROR: Database_Exception [ 1052 ]: Column 'id_user' in on clause is ambiguous [ SELECT `answers`.`id_answer`, `answers`.`public_date`, `answers`.`rating`, `answers`.`best`, `questions_and_answers`.`id_questions`, `users`.`username`, `questions_and_answers`.`id_questions_and_answers`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) JOIN `vote` ON (`id_user` = `5` AND `id_qa` = `questions_and_answers`.`id_questions_and_answers`) WHERE `questions_and_answers`.`id_questions` = 54 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 17:14:17 --- STRACE: Database_Exception [ 1052 ]: Column 'id_user' in on clause is ambiguous [ SELECT `answers`.`id_answer`, `answers`.`public_date`, `answers`.`rating`, `answers`.`best`, `questions_and_answers`.`id_questions`, `users`.`username`, `questions_and_answers`.`id_questions_and_answers`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) JOIN `vote` ON (`id_user` = `5` AND `id_qa` = `questions_and_answers`.`id_questions_and_answers`) WHERE `questions_and_answers`.`id_questions` = 54 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(118): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(134): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 17:15:30 --- ERROR: Database_Exception [ 1054 ]: Unknown column '5' in 'on clause' [ SELECT `answers`.`id_answer`, `answers`.`public_date`, `answers`.`rating`, `answers`.`best`, `questions_and_answers`.`id_questions`, `users`.`username`, `questions_and_answers`.`id_questions_and_answers`, `answers`.`answer_text`, `vote`.`value` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) JOIN `vote` ON (`vote`.`id_user` = `5` AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) WHERE `questions_and_answers`.`id_questions` = 54 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 17:15:30 --- STRACE: Database_Exception [ 1054 ]: Unknown column '5' in 'on clause' [ SELECT `answers`.`id_answer`, `answers`.`public_date`, `answers`.`rating`, `answers`.`best`, `questions_and_answers`.`id_questions`, `users`.`username`, `questions_and_answers`.`id_questions_and_answers`, `answers`.`answer_text`, `vote`.`value` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) JOIN `vote` ON (`vote`.`id_user` = `5` AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) WHERE `questions_and_answers`.`id_questions` = 54 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(119): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(134): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 17:17:48 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) WHERE `' at line 1 [ SELECT `answers`.`id_answer`, `answers`.`public_date`, `answers`.`rating`, `answers`.`best`, `questions_and_answers`.`id_questions`, `users`.`username`, `questions_and_answers`.`id_questions_and_answers`, `answers`.`answer_text`, `vote`.`value` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) LEFT JOIN `vote` ON (`vote`.`id_user` =  AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) WHERE `questions_and_answers`.`id_questions` = 54 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 17:17:48 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) WHERE `' at line 1 [ SELECT `answers`.`id_answer`, `answers`.`public_date`, `answers`.`rating`, `answers`.`best`, `questions_and_answers`.`id_questions`, `users`.`username`, `questions_and_answers`.`id_questions_and_answers`, `answers`.`answer_text`, `vote`.`value` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) LEFT JOIN `vote` ON (`vote`.`id_user` =  AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) WHERE `questions_and_answers`.`id_questions` = 54 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(119): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(134): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 18:57:56 --- ERROR: ErrorException [ 1 ]: Call to a member function as_array() on a non-object ~ APPPATH/classes/model/mquestions.php [ 343 ]
2012-01-16 18:57:56 --- STRACE: ErrorException [ 1 ]: Call to a member function as_array() on a non-object ~ APPPATH/classes/model/mquestions.php [ 343 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler(Array)
#1 {main}
2012-01-16 18:59:16 --- ERROR: ErrorException [ 1 ]: Call to a member function as_array() on a non-object ~ APPPATH/classes/model/mquestions.php [ 343 ]
2012-01-16 18:59:16 --- STRACE: ErrorException [ 1 ]: Call to a member function as_array() on a non-object ~ APPPATH/classes/model/mquestions.php [ 343 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler(Array)
#1 {main}
2012-01-16 19:04:57 --- ERROR: ErrorException [ 8 ]: Undefined index:  question_id ~ APPPATH/classes/controller/questions/qhid.php [ 83 ]
2012-01-16 19:04:57 --- STRACE: ErrorException [ 8 ]: Undefined index:  question_id ~ APPPATH/classes/controller/questions/qhid.php [ 83 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(83): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Qhid->action_checkAsBest(Object(Controller_Questions_Qhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-16 19:05:30 --- ERROR: ErrorException [ 8 ]: Undefined index:  question_id ~ APPPATH/classes/controller/questions/qhid.php [ 83 ]
2012-01-16 19:05:30 --- STRACE: ErrorException [ 8 ]: Undefined index:  question_id ~ APPPATH/classes/controller/questions/qhid.php [ 83 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(83): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Qhid->action_checkAsBest(Object(Controller_Questions_Qhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-16 19:07:55 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions.id_question' in 'where clause' [ UPDATE `answers` SET `answers`.`best` = '1' WHERE `answers`.`id_answer` = 67 AND `questions`.`id_question` = 55 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 19:07:55 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions.id_question' in 'where clause' [ UPDATE `answers` SET `answers`.`best` = '1' WHERE `answers`.`id_answer` = 67 AND `questions`.`id_question` = 55 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(3, 'UPDATE `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(343): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(84): Model_Mquestions->checkAsBest(Array)
#3 [internal function]: Controller_Questions_Qhid->action_checkAsBest()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 19:10:11 --- ERROR: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Update::join() ~ APPPATH/classes/model/mquestions.php [ 343 ]
2012-01-16 19:10:11 --- STRACE: ErrorException [ 1 ]: Call to undefined method Database_Query_Builder_Update::join() ~ APPPATH/classes/model/mquestions.php [ 343 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler(Array)
#1 {main}
2012-01-16 19:37:02 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers`, `vote`.`value` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = ) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =  AND `questions_and_answers`.`id_answers` IS null) LEFT JOIN `vote` ON (`vote`.`id_user` = 5 AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 19:37:02 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers`, `vote`.`value` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = ) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =  AND `questions_and_answers`.`id_answers` IS null) LEFT JOIN `vote` ON (`vote`.`id_user` = 5 AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(100): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(134): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 19:37:11 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers`, `vote`.`value` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = ) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =  AND `questions_and_answers`.`id_answers` IS null) LEFT JOIN `vote` ON (`vote`.`id_user` = -1 AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 19:37:11 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers`, `vote`.`value` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = ) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =  AND `questions_and_answers`.`id_answers` IS null) LEFT JOIN `vote` ON (`vote`.`id_user` = -1 AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(100): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(134): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 19:44:38 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers`, `vote`.`value` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = ) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =  AND `questions_and_answers`.`id_answers` IS null) LEFT JOIN `vote` ON (`vote`.`id_user` = -1 AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 19:44:38 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers`, `vote`.`value` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = ) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =  AND `questions_and_answers`.`id_answers` IS null) LEFT JOIN `vote` ON (`vote`.`id_user` = -1 AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(100): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(134): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 20:14:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-16 20:14:57 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-16 20:14:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-16 20:14:57 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-16 20:35:34 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers`, `vote`.`value` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = ) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =  AND `questions_and_answers`.`id_answers` IS null) LEFT JOIN `vote` ON (`vote`.`id_user` = 5 AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-16 20:35:34 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers`, `vote`.`value` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = ) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` =  AND `questions_and_answers`.`id_answers` IS null) LEFT JOIN `vote` ON (`vote`.`id_user` = 5 AND `vote`.`id_qa` = `questions_and_answers`.`id_questions_and_answers`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(100): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(134): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-16 20:42:36 --- ERROR: ErrorException [ 8 ]: Undefined variable: result ~ APPPATH/views/questions/vQuestionOne.php [ 33 ]
2012-01-16 20:42:36 --- STRACE: ErrorException [ 8 ]: Undefined variable: result ~ APPPATH/views/questions/vQuestionOne.php [ 33 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(33): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-16 20:43:05 --- ERROR: ErrorException [ 8 ]: Uninitialized string offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 14 ]
2012-01-16 20:43:05 --- STRACE: ErrorException [ 8 ]: Uninitialized string offset: 0 ~ APPPATH/views/questions/vQuestionOne.php [ 14 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(14): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-16 20:43:32 --- ERROR: View_Exception [ 0 ]: The requested view questions/vQuestion could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
2012-01-16 20:43:32 --- STRACE: View_Exception [ 0 ]: The requested view questions/vQuestion could not be found ~ SYSPATH/classes/kohana/view.php [ 252 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/view.php(137): Kohana_View->set_filename('questions/vQues...')
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(30): Kohana_View->__construct('questions/vQues...', Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(141): Kohana_View::factory('questions/vQues...', Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}