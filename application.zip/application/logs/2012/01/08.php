<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-01-08 02:15:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 02:15:29 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 02:15:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 02:15:29 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 14:19:33 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/back.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 14:19:33 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/back.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 14:21:34 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/back-icon.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 14:21:34 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/back-icon.png ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 20:40:12 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 20:40:12 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 20:41:05 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 20:41:05 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 20:41:09 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 20:41:09 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 20:41:11 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 20:41:11 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 20:42:48 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 20:42:48 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 20:42:59 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 20:42:59 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 20:43:04 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 20:43:04 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 20:43:46 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 20:43:46 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 20:43:54 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 20:43:54 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 20:44:31 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 20:44:31 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 20:44:38 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 20:44:38 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 20:45:03 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 20:45:03 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 20:45:07 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 20:45:07 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 20:45:16 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-08 20:45:16 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: stfile/img/2loading.gif ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-08 21:41:24 --- ERROR: ErrorException [ 8 ]: Undefined index:  frmQuestion ~ APPPATH/classes/controller/questions/questions.php [ 45 ]
2012-01-08 21:41:24 --- STRACE: ErrorException [ 8 ]: Undefined index:  frmQuestion ~ APPPATH/classes/controller/questions/questions.php [ 45 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(45): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-08 21:42:07 --- ERROR: ErrorException [ 8 ]: Undefined index:  btnSearch ~ APPPATH/classes/controller/questions/questions.php [ 45 ]
2012-01-08 21:42:07 --- STRACE: ErrorException [ 8 ]: Undefined index:  btnSearch ~ APPPATH/classes/controller/questions/questions.php [ 45 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(45): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-08 21:42:11 --- ERROR: ErrorException [ 8 ]: Undefined index:  btnSearch ~ APPPATH/classes/controller/questions/questions.php [ 45 ]
2012-01-08 21:42:11 --- STRACE: ErrorException [ 8 ]: Undefined index:  btnSearch ~ APPPATH/classes/controller/questions/questions.php [ 45 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(45): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-08 21:45:47 --- ERROR: ErrorException [ 8 ]: Undefined index:  btnSearch ~ APPPATH/classes/controller/questions/questions.php [ 45 ]
2012-01-08 21:45:47 --- STRACE: ErrorException [ 8 ]: Undefined index:  btnSearch ~ APPPATH/classes/controller/questions/questions.php [ 45 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(45): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-08 21:46:22 --- ERROR: ErrorException [ 8 ]: Undefined index:  btnSearch ~ APPPATH/classes/controller/questions/questions.php [ 45 ]
2012-01-08 21:46:22 --- STRACE: ErrorException [ 8 ]: Undefined index:  btnSearch ~ APPPATH/classes/controller/questions/questions.php [ 45 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(45): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_ask(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-08 23:08:00 --- ERROR: ErrorException [ 8 ]: Undefined index:  questionTags ~ APPPATH/classes/controller/questions/questions.php [ 62 ]
2012-01-08 23:08:00 --- STRACE: ErrorException [ 8 ]: Undefined index:  questionTags ~ APPPATH/classes/controller/questions/questions.php [ 62 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(62): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-08 23:08:39 --- ERROR: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ INSERT INTO `questions` (`title`, `full`, `id_user`, `tags`, `public_date`) VALUES ('test title', '', 1, 'some1,some2,some3', ('test title', '')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-08 23:08:39 --- STRACE: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ INSERT INTO `questions` (`title`, `full`, `id_user`, `tags`, `public_date`) VALUES ('test title', '', 1, 'some1,some2,some3', ('test title', '')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `qu...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(29): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(67): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-08 23:09:44 --- ERROR: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ INSERT INTO `questions` (`title`, `full`, `id_user`, `tags`, `public_date`) VALUES ('sad', 'sdd', 1, 'some1,some2,some3', ('sad', 'sdd')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-08 23:09:44 --- STRACE: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ INSERT INTO `questions` (`title`, `full`, `id_user`, `tags`, `public_date`) VALUES ('sad', 'sdd', 1, 'some1,some2,some3', ('sad', 'sdd')) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `qu...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(29): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(67): Model_Mquestions->askQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_askquestion()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-08 23:17:41 --- ERROR: ErrorException [ 1 ]: Call to undefined function now() ~ APPPATH/classes/model/mquestions.php [ 16 ]
2012-01-08 23:17:41 --- STRACE: ErrorException [ 1 ]: Call to undefined function now() ~ APPPATH/classes/model/mquestions.php [ 16 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler(Array)
#1 {main}
2012-01-08 23:57:33 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-08 23:57:33 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(30): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(70): Model_Mquestions->askQuestion()
#5 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-08 23:58:36 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-08 23:58:36 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(30): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(70): Model_Mquestions->askQuestion()
#5 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}
2012-01-08 23:58:46 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-08 23:58:46 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/insert.php(140): Kohana_Database->quote(Object(Database_MySQL))
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Insert->compile()
#3 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(30): Kohana_Database_Query->execute(Array)
#4 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(70): Model_Mquestions->askQuestion()
#5 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#9 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#10 {main}