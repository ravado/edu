<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-01-15 15:09:20 --- ERROR: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 158 ]
2012-01-15 15:09:20 --- STRACE: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 158 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(158): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-15 15:10:27 --- ERROR: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 158 ]
2012-01-15 15:10:27 --- STRACE: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 158 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(158): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-15 15:10:32 --- ERROR: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 158 ]
2012-01-15 15:10:32 --- STRACE: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 158 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(158): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-15 15:11:12 --- ERROR: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 158 ]
2012-01-15 15:11:12 --- STRACE: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 158 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(158): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-15 15:11:55 --- ERROR: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 158 ]
2012-01-15 15:11:55 --- STRACE: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 158 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(158): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-15 15:13:09 --- ERROR: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 158 ]
2012-01-15 15:13:09 --- STRACE: ErrorException [ 8 ]: Undefined variable: user_id ~ APPPATH/views/questions/vQuestionOne.php [ 158 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(158): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-15 15:15:20 --- ERROR: ErrorException [ 8 ]: Undefined variable: checkAsBest ~ APPPATH/views/questions/vQuestionOne.php [ 193 ]
2012-01-15 15:15:20 --- STRACE: ErrorException [ 8 ]: Undefined variable: checkAsBest ~ APPPATH/views/questions/vQuestionOne.php [ 193 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(193): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-15 15:20:04 --- ERROR: ErrorException [ 8 ]: Undefined variable: userName ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
2012-01-15 15:20:04 --- STRACE: ErrorException [ 8 ]: Undefined variable: userName ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-15 16:31:49 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/classes/controller/questions/qhid.php [ 29 ]
2012-01-15 16:31:49 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/classes/controller/questions/qhid.php [ 29 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(29): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Qhid->action_addFavorite(Object(Controller_Questions_Qhid))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-15 16:33:27 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'id_questions' in 'field list' [ INSERT INTO `qfavorite` (`id_user`, `id_questions`) VALUES ('5', 'undefined') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 16:33:27 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'id_questions' in 'field list' [ INSERT INTO `qfavorite` (`id_user`, `id_questions`) VALUES ('5', 'undefined') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `qf...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(164): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(30): Model_Mquestions->addFavorite(Array)
#3 [internal function]: Controller_Questions_Qhid->action_addFavorite()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 16:35:11 --- ERROR: Database_Exception [ 1452 ]: Cannot add or update a child row: a foreign key constraint fails (`edu`.`qfavorite`, CONSTRAINT `fk_qfavorite_id_question` FOREIGN KEY (`id_question`) REFERENCES `questions` (`id_question`) ON DELETE CASCADE ON UPDATE CASCADE) [ INSERT INTO `qfavorite` (`id_user`, `id_question`) VALUES ('5', 'undefined') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 16:35:11 --- STRACE: Database_Exception [ 1452 ]: Cannot add or update a child row: a foreign key constraint fails (`edu`.`qfavorite`, CONSTRAINT `fk_qfavorite_id_question` FOREIGN KEY (`id_question`) REFERENCES `questions` (`id_question`) ON DELETE CASCADE ON UPDATE CASCADE) [ INSERT INTO `qfavorite` (`id_user`, `id_question`) VALUES ('5', 'undefined') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `qf...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(164): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(30): Model_Mquestions->addFavorite(Array)
#3 [internal function]: Controller_Questions_Qhid->action_addFavorite()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 16:37:11 --- ERROR: Database_Exception [ 1452 ]: Cannot add or update a child row: a foreign key constraint fails (`edu`.`qfavorite`, CONSTRAINT `fk_qfavorite_id_question` FOREIGN KEY (`id_question`) REFERENCES `questions` (`id_question`)) [ INSERT INTO `qfavorite` (`id_user`, `id_question`) VALUES ('5', 'undefined') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 16:37:11 --- STRACE: Database_Exception [ 1452 ]: Cannot add or update a child row: a foreign key constraint fails (`edu`.`qfavorite`, CONSTRAINT `fk_qfavorite_id_question` FOREIGN KEY (`id_question`) REFERENCES `questions` (`id_question`)) [ INSERT INTO `qfavorite` (`id_user`, `id_question`) VALUES ('5', 'undefined') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(2, 'INSERT INTO `qf...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(164): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(30): Model_Mquestions->addFavorite(Array)
#3 [internal function]: Controller_Questions_Qhid->action_addFavorite()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 17:10:00 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-15 17:10:00 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder.php(116): Kohana_Database->quote(Object(Database_MySQL), Array)
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/delete.php(61): Kohana_Database_Query_Builder->_compile_conditions(Object(Database_MySQL))
#3 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Delete->compile()
#4 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(193): Kohana_Database_Query->execute(Array)
#5 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(45): Model_Mquestions->removeFavorite()
#6 [internal function]: Controller_Questions_Qhid->action_removeFavorite(Object(Controller_Questions_Qhid))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#10 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#11 {main}
2012-01-15 17:15:42 --- ERROR: ErrorException [ 2 ]: Missing argument 2 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 160 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
2012-01-15 17:15:42 --- STRACE: ErrorException [ 2 ]: Missing argument 2 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 160 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/where.php(30): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(160): Kohana_Database_Query_Builder_Where->where(Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(30): Model_Mquestions->addFavorite()
#3 [internal function]: Controller_Questions_Qhid->action_addFavorite(Object(Controller_Questions_Qhid))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 17:15:50 --- ERROR: ErrorException [ 2 ]: Missing argument 2 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 160 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
2012-01-15 17:15:50 --- STRACE: ErrorException [ 2 ]: Missing argument 2 for Kohana_Database_Query_Builder_Where::where(), called in /Users/ravado/Sites/edu/application/classes/model/mquestions.php on line 160 and defined ~ MODPATH/database/classes/kohana/database/query/builder/where.php [ 30 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/where.php(30): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(160): Kohana_Database_Query_Builder_Where->where(Array)
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(30): Model_Mquestions->addFavorite()
#3 [internal function]: Controller_Questions_Qhid->action_addFavorite(Object(Controller_Questions_Qhid))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 17:18:03 --- ERROR: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `id_qfavorite` FROM `qfavorite` WHERE `id_user` = ('5', ' 24') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 17:18:03 --- STRACE: Database_Exception [ 1241 ]: Operand should contain 1 column(s) [ SELECT `id_qfavorite` FROM `qfavorite` WHERE `id_user` = ('5', ' 24') ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `id_qfav...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(161): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(30): Model_Mquestions->addFavorite(Array)
#3 [internal function]: Controller_Questions_Qhid->action_addFavorite()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 17:21:45 --- ERROR: ErrorException [ 1 ]: Call to undefined function where() ~ APPPATH/classes/model/mquestions.php [ 160 ]
2012-01-15 17:21:45 --- STRACE: ErrorException [ 1 ]: Call to undefined function where() ~ APPPATH/classes/model/mquestions.php [ 160 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler(Array)
#1 {main}
2012-01-15 17:25:22 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-15 17:25:22 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder.php(116): Kohana_Database->quote(Object(Database_MySQL), Array)
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/delete.php(61): Kohana_Database_Query_Builder->_compile_conditions(Object(Database_MySQL))
#3 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Delete->compile()
#4 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(193): Kohana_Database_Query->execute(Array)
#5 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(45): Model_Mquestions->removeFavorite()
#6 [internal function]: Controller_Questions_Qhid->action_removeFavorite(Object(Controller_Questions_Qhid))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#10 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#11 {main}
2012-01-15 17:58:22 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-15 17:58:22 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder.php(116): Kohana_Database->quote(Object(Database_MySQL), Array)
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/delete.php(61): Kohana_Database_Query_Builder->_compile_conditions(Object(Database_MySQL))
#3 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Delete->compile()
#4 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(193): Kohana_Database_Query->execute(Array)
#5 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(45): Model_Mquestions->removeFavorite()
#6 [internal function]: Controller_Questions_Qhid->action_removeFavorite(Object(Controller_Questions_Qhid))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#10 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#11 {main}
2012-01-15 17:58:41 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-15 17:58:41 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder.php(116): Kohana_Database->quote(Object(Database_MySQL), Array)
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/delete.php(61): Kohana_Database_Query_Builder->_compile_conditions(Object(Database_MySQL))
#3 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Delete->compile()
#4 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(193): Kohana_Database_Query->execute(Array)
#5 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(45): Model_Mquestions->removeFavorite()
#6 [internal function]: Controller_Questions_Qhid->action_removeFavorite(Object(Controller_Questions_Qhid))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#10 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#11 {main}
2012-01-15 18:02:10 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-15 18:02:10 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder.php(116): Kohana_Database->quote(Object(Database_MySQL), Array)
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/delete.php(61): Kohana_Database_Query_Builder->_compile_conditions(Object(Database_MySQL))
#3 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Delete->compile()
#4 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(194): Kohana_Database_Query->execute(Array)
#5 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(45): Model_Mquestions->removeFavorite()
#6 [internal function]: Controller_Questions_Qhid->action_removeFavorite(Object(Controller_Questions_Qhid))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#10 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#11 {main}
2012-01-15 18:02:17 --- ERROR: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
2012-01-15 18:02:17 --- STRACE: ErrorException [ 4096 ]: Object of class Database_MySQL_Result could not be converted to string ~ MODPATH/database/classes/kohana/database.php [ 456 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database.php(456): Kohana_Core::error_handler(Object(Database_MySQL_Result))
#1 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder.php(116): Kohana_Database->quote(Object(Database_MySQL), Array)
#2 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query/builder/delete.php(61): Kohana_Database_Query_Builder->_compile_conditions(Object(Database_MySQL))
#3 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(228): Kohana_Database_Query_Builder_Delete->compile()
#4 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(194): Kohana_Database_Query->execute(Array)
#5 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(45): Model_Mquestions->removeFavorite()
#6 [internal function]: Controller_Questions_Qhid->action_removeFavorite(Object(Controller_Questions_Qhid))
#7 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#8 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#9 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#10 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#11 {main}
2012-01-15 18:36:59 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'Array' in 'where clause' [ SELECT `answers`.`id_answer`, `answers`.`public_date`, `answers`.`rating`, `answers`.`best`, `users`.`username`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) WHERE `questions_and_answers`.`id_questions` = Array ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 18:36:59 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'Array' in 'where clause' [ SELECT `answers`.`id_answer`, `answers`.`public_date`, `answers`.`rating`, `answers`.`best`, `users`.`username`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) WHERE `questions_and_answers`.`id_questions` = Array ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(113): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(133): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 18:37:44 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'Array' in 'where clause' [ SELECT `answers`.`id_answer`, `answers`.`public_date`, `answers`.`rating`, `answers`.`best`, `users`.`username`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) WHERE `questions_and_answers`.`id_questions` = Array ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 18:37:44 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'Array' in 'where clause' [ SELECT `answers`.`id_answer`, `answers`.`public_date`, `answers`.`rating`, `answers`.`best`, `users`.`username`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) WHERE `questions_and_answers`.`id_questions` = Array ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(113): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(133): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 18:38:47 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'Array' in 'where clause' [ SELECT `answers`.`id_answer`, `answers`.`public_date`, `answers`.`rating`, `answers`.`best`, `users`.`username`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) WHERE `questions_and_answers`.`id_questions` = Array ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 18:38:47 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'Array' in 'where clause' [ SELECT `answers`.`id_answer`, `answers`.`public_date`, `answers`.`rating`, `answers`.`best`, `users`.`username`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) WHERE `questions_and_answers`.`id_questions` = Array ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(113): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(133): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 18:39:15 --- ERROR: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 18:39:15 --- STRACE: Database_Exception [ 1054 ]: Unknown column '24' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = `24`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(93): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(133): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 18:39:43 --- ERROR: ErrorException [ 1 ]: Call to undefined method DB::arr() ~ APPPATH/classes/model/mquestions.php [ 92 ]
2012-01-15 18:39:43 --- STRACE: ErrorException [ 1 ]: Call to undefined method DB::arr() ~ APPPATH/classes/model/mquestions.php [ 92 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler(Array)
#1 {main}
2012-01-15 18:39:48 --- ERROR: ErrorException [ 4 ]: syntax error, unexpected T_ARRAY, expecting T_STRING or T_VARIABLE or '$' ~ APPPATH/classes/model/mquestions.php [ 92 ]
2012-01-15 18:39:48 --- STRACE: ErrorException [ 4 ]: syntax error, unexpected T_ARRAY, expecting T_STRING or T_VARIABLE or '$' ~ APPPATH/classes/model/mquestions.php [ 92 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler('Model_Mquestion...')
#1 {main}
2012-01-15 18:40:21 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'Array' in 'where clause' [ SELECT `answers`.`id_answer`, `answers`.`public_date`, `answers`.`rating`, `answers`.`best`, `users`.`username`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) WHERE `questions_and_answers`.`id_questions` = Array ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 18:40:21 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'Array' in 'where clause' [ SELECT `answers`.`id_answer`, `answers`.`public_date`, `answers`.`rating`, `answers`.`best`, `users`.`username`, `answers`.`answer_text` FROM `questions_and_answers` JOIN `answers` ON (`answers`.`id_answer` = `questions_and_answers`.`id_answers`) LEFT JOIN `users` ON (`users`.`id` = `answers`.`id_user`) WHERE `questions_and_answers`.`id_questions` = Array ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `answers...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(114): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(133): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 20:23:45 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_ques' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags` FROM `questions_and_answers` JOIN `questions` ON () JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = 1) WHERE `questions_and_answers`.`id_questions` = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 20:23:45 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_ques' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags` FROM `questions_and_answers` JOIN `questions` ON () JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = 1) WHERE `questions_and_answers`.`id_questions` = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(93): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(133): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 20:23:58 --- ERROR: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_ques' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags` FROM `questions_and_answers` JOIN `questions` ON () JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = 1) WHERE `questions_and_answers`.`id_questions` = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 20:23:58 --- STRACE: Database_Exception [ 1064 ]: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ') JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_ques' at line 1 [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags` FROM `questions_and_answers` JOIN `questions` ON () JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = 1) WHERE `questions_and_answers`.`id_questions` = 1 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(93): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(133): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 20:26:43 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/views/questions/vQuestionOne.php [ 25 ]
2012-01-15 20:26:43 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/views/questions/vQuestionOne.php [ 25 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(25): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-15 20:27:18 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/views/questions/vQuestionOne.php [ 25 ]
2012-01-15 20:27:18 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/views/questions/vQuestionOne.php [ 25 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(25): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-15 20:31:10 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_question' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = 6) JOIN `questions_and_answers` ON (`questions_and_answers`.`id_question` = 6) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 20:31:10 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_question' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = 6) JOIN `questions_and_answers` ON (`questions_and_answers`.`id_question` = 6) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(95): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(133): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 20:36:52 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_questions_and_answers ~ APPPATH/views/questions/vQuestionOne.php [ 136 ]
2012-01-15 20:36:52 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_questions_and_answers ~ APPPATH/views/questions/vQuestionOne.php [ 136 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(136): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-15 21:05:41 --- ERROR: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 70 ]
2012-01-15 21:05:41 --- STRACE: ErrorException [ 2 ]: Invalid argument supplied for foreach() ~ APPPATH/views/questions/vQuestions.php [ 70 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(70): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-15 21:24:20 --- ERROR: Database_Exception [ 1054 ]: Unknown column '' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = 39) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = 39 AND `questions_and_answers`.`id_questions` = ``) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 21:24:20 --- STRACE: Database_Exception [ 1054 ]: Unknown column '' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = 39) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = 39 AND `questions_and_answers`.`id_questions` = ``) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(95): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(133): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 21:24:40 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'null' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = 39) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = 39 AND `questions_and_answers`.`id_questions` = `null`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 21:24:40 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'null' in 'on clause' [ SELECT `questions`.`id_question`, `questions`.`title`, `questions`.`id_user`, `users`.`username`, `users`.`karma`, `questions`.`rating`, `questions`.`public_date`, `questions`.`full`, `questions`.`closed`, `questions`.`tags`, `questions_and_answers`.`id_questions_and_answers` FROM `questions` JOIN `users` ON (`users`.`id` = `questions`.`id_user` AND `questions`.`id_question` = 39) LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions` = 39 AND `questions_and_answers`.`id_questions` = `null`) ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `questio...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(95): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(133): Model_Mquestions->getOneQuestion(Array)
#3 [internal function]: Controller_Questions_Questions->action_question()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Questions))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 21:27:39 --- ERROR: ErrorException [ 8 ]: Undefined index:  QUESTION ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
2012-01-15 21:27:39 --- STRACE: ErrorException [ 8 ]: Undefined index:  QUESTION ~ APPPATH/views/questions/vQuestionOne.php [ 5 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestionOne.php(5): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(43): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-15 22:25:16 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/mquestions.php [ 69 ]
2012-01-15 22:25:16 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/mquestions.php [ 69 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(69): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(82): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-15 22:25:43 --- ERROR: ErrorException [ 1 ]: Call to a member function save() on a non-object ~ APPPATH/classes/model/mquestions.php [ 67 ]
2012-01-15 22:25:43 --- STRACE: ErrorException [ 1 ]: Call to a member function save() on a non-object ~ APPPATH/classes/model/mquestions.php [ 67 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler(Array)
#1 {main}
2012-01-15 22:25:54 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/mquestions.php [ 69 ]
2012-01-15 22:25:54 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/mquestions.php [ 69 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(69): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(82): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-15 22:28:49 --- ERROR: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/mquestions.php [ 69 ]
2012-01-15 22:28:49 --- STRACE: ErrorException [ 8 ]: Trying to get property of non-object ~ APPPATH/classes/model/mquestions.php [ 69 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(69): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(82): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-15 22:29:28 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/classes/model/mquestions.php [ 69 ]
2012-01-15 22:29:28 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_question ~ APPPATH/classes/model/mquestions.php [ 69 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(69): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(82): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-15 22:29:35 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_questions ~ APPPATH/classes/model/mquestions.php [ 69 ]
2012-01-15 22:29:35 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_questions ~ APPPATH/classes/model/mquestions.php [ 69 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(69): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(82): Model_Mquestions->askQuestion()
#2 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-15 23:40:04 --- ERROR: Database_Exception [ 1054 ]: Unknown column ' 48' in 'on clause' [ SELECT `vote`.`id_vote`, `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions` FROM `vote` LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions_and_answers` = ` 48`) WHERE `id_user` = '5' AND `id_q&a` = ' 48' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 23:40:04 --- STRACE: Database_Exception [ 1054 ]: Unknown column ' 48' in 'on clause' [ SELECT `vote`.`id_vote`, `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions` FROM `vote` LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions_and_answers` = ` 48`) WHERE `id_user` = '5' AND `id_q&a` = ' 48' ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `vote`.`...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(228): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteUp()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 23:41:13 --- ERROR: Database_Exception [ 1054 ]: Unknown column ' 48' in 'on clause' [ SELECT `vote`.`id_vote`, `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions` FROM `vote` LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions_and_answers` = ` 48`) WHERE `id_user` = '5' AND `id_q&a` =  48 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 23:41:13 --- STRACE: Database_Exception [ 1054 ]: Unknown column ' 48' in 'on clause' [ SELECT `vote`.`id_vote`, `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions` FROM `vote` LEFT JOIN `questions_and_answers` ON (`questions_and_answers`.`id_questions_and_answers` = ` 48`) WHERE `id_user` = '5' AND `id_q&a` =  48 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `vote`.`...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(228): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteUp()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 23:46:03 --- ERROR: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `vote`.`id_vote`, `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions` FROM `vote` WHERE `id_user` = '5' AND `id_q&a` =  48 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
2012-01-15 23:46:03 --- STRACE: Database_Exception [ 1054 ]: Unknown column 'questions_and_answers.id_answers' in 'field list' [ SELECT `vote`.`id_vote`, `questions_and_answers`.`id_answers`, `questions_and_answers`.`id_questions` FROM `vote` WHERE `id_user` = '5' AND `id_q&a` =  48 ] ~ MODPATH/database/classes/kohana/database/mysql.php [ 194 ]
--
#0 /Users/ravado/Sites/edu/modules/database/classes/kohana/database/query.php(245): Kohana_Database_MySQL->query(1, 'SELECT `vote`.`...', false, Array)
#1 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(227): Kohana_Database_Query->execute()
#2 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp(Array)
#3 [internal function]: Controller_Questions_Qhid->action_voteUp()
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Controller_Questions_Qhid))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#6 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#7 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#8 {main}
2012-01-15 23:53:04 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_answers ~ APPPATH/classes/model/mquestions.php [ 229 ]
2012-01-15 23:53:04 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_answers ~ APPPATH/classes/model/mquestions.php [ 229 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(229): Kohana_Core::error_handler(Array)
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/qhid.php(59): Model_Mquestions->voteUp()
#2 [internal function]: Controller_Questions_Qhid->action_voteUp(Object(Controller_Questions_Qhid))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}