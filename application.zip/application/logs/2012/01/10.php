<?php defined('SYSPATH') or die('No direct script access.'); ?>

2012-01-10 14:43:09 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 68 ]
2012-01-10 14:43:09 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 68 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(68): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-10 14:43:53 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 68 ]
2012-01-10 14:43:53 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 68 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(68): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-10 14:58:37 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 70 ]
2012-01-10 14:58:37 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 70 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(70): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-10 14:59:12 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 70 ]
2012-01-10 14:59:12 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/classes/controller/questions/questions.php [ 70 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(70): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_askquestion(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-10 15:51:50 --- ERROR: ErrorException [ 1 ]: Call to undefined method Model_Mquestions::mainVIO() ~ APPPATH/classes/controller/questions/questions.php [ 24 ]
2012-01-10 15:51:50 --- STRACE: ErrorException [ 1 ]: Call to undefined method Model_Mquestions::mainVIO() ~ APPPATH/classes/controller/questions/questions.php [ 24 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-01-10 15:59:52 --- ERROR: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/views/questions/vQuestions.php [ 71 ]
2012-01-10 15:59:52 --- STRACE: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/views/questions/vQuestions.php [ 71 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(71): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-10 16:00:22 --- ERROR: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/views/questions/vQuestions.php [ 71 ]
2012-01-10 16:00:22 --- STRACE: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/views/questions/vQuestions.php [ 71 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(71): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-10 16:15:54 --- ERROR: ErrorException [ 8 ]: Undefined index:  [public_date ~ APPPATH/views/questions/vQuestions.php [ 77 ]
2012-01-10 16:15:54 --- STRACE: ErrorException [ 8 ]: Undefined index:  [public_date ~ APPPATH/views/questions/vQuestions.php [ 77 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(77): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-10 16:22:07 --- ERROR: ErrorException [ 8 ]: A non well formed numeric value encountered ~ APPPATH/views/questions/vQuestions.php [ 77 ]
2012-01-10 16:22:07 --- STRACE: ErrorException [ 8 ]: A non well formed numeric value encountered ~ APPPATH/views/questions/vQuestions.php [ 77 ]
--
#0 [internal function]: Kohana_Core::error_handler('F', '2012-01-10 14:4...')
#1 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(77): date('/Users/ravado/S...', Array)
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#4 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#5 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#7 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#8 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#9 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#10 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#14 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#15 {main}
2012-01-10 16:26:03 --- ERROR: ErrorException [ 1 ]: Call to undefined function now() ~ APPPATH/views/questions/vQuestions.php [ 70 ]
2012-01-10 16:26:03 --- STRACE: ErrorException [ 1 ]: Call to undefined function now() ~ APPPATH/views/questions/vQuestions.php [ 70 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler('/Users/ravado/S...', Array)
#1 {main}
2012-01-10 16:29:28 --- ERROR: ErrorException [ 8 ]: A non well formed numeric value encountered ~ APPPATH/views/questions/vQuestions.php [ 78 ]
2012-01-10 16:29:28 --- STRACE: ErrorException [ 8 ]: A non well formed numeric value encountered ~ APPPATH/views/questions/vQuestions.php [ 78 ]
--
#0 [internal function]: Kohana_Core::error_handler('2012-01-10 14:4...')
#1 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(78): getdate('/Users/ravado/S...', Array)
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#4 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#5 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#7 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#8 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#9 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#10 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#14 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#15 {main}
2012-01-10 16:30:27 --- ERROR: ErrorException [ 8 ]: A non well formed numeric value encountered ~ APPPATH/views/questions/vQuestions.php [ 78 ]
2012-01-10 16:30:27 --- STRACE: ErrorException [ 8 ]: A non well formed numeric value encountered ~ APPPATH/views/questions/vQuestions.php [ 78 ]
--
#0 [internal function]: Kohana_Core::error_handler('2012-01-10 14:4...')
#1 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(78): mktime('/Users/ravado/S...', Array)
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#4 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#5 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#7 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#8 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#9 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#10 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#14 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#15 {main}
2012-01-10 16:33:59 --- ERROR: ErrorException [ 8 ]: A non well formed numeric value encountered ~ APPPATH/views/questions/vQuestions.php [ 78 ]
2012-01-10 16:33:59 --- STRACE: ErrorException [ 8 ]: A non well formed numeric value encountered ~ APPPATH/views/questions/vQuestions.php [ 78 ]
--
#0 [internal function]: Kohana_Core::error_handler('F', '2012-01-10 14:4...')
#1 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(78): date('/Users/ravado/S...', Array)
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#4 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#5 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#7 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#8 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#9 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#10 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#13 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#14 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#15 {main}
2012-01-10 16:52:09 --- ERROR: ErrorException [ 8 ]: Undefined index:  some1 ~ APPPATH/views/questions/vQuestions.php [ 146 ]
2012-01-10 16:52:09 --- STRACE: ErrorException [ 8 ]: Undefined index:  some1 ~ APPPATH/views/questions/vQuestions.php [ 146 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(146): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-10 16:58:47 --- ERROR: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/views/questions/vQuestions.php [ 143 ]
2012-01-10 16:58:47 --- STRACE: ErrorException [ 8 ]: Undefined index:  tags ~ APPPATH/views/questions/vQuestions.php [ 143 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(143): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-10 16:59:44 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestions.php [ 143 ]
2012-01-10 16:59:44 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestions.php [ 143 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(143): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-10 16:59:54 --- ERROR: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestions.php [ 148 ]
2012-01-10 16:59:54 --- STRACE: ErrorException [ 8 ]: Undefined offset:  0 ~ APPPATH/views/questions/vQuestions.php [ 148 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(148): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-10 17:00:23 --- ERROR: ErrorException [ 8 ]: Undefined index:  lsat ~ APPPATH/views/questions/vQuestions.php [ 153 ]
2012-01-10 17:00:23 --- STRACE: ErrorException [ 8 ]: Undefined index:  lsat ~ APPPATH/views/questions/vQuestions.php [ 153 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(153): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-10 17:06:40 --- ERROR: ErrorException [ 1 ]: Call to undefined function as_array() ~ APPPATH/classes/model/mquestions.php [ 19 ]
2012-01-10 17:06:40 --- STRACE: ErrorException [ 1 ]: Call to undefined function as_array() ~ APPPATH/classes/model/mquestions.php [ 19 ]
--
#0 [internal function]: Kohana_Core::shutdown_handler()
#1 {main}
2012-01-10 17:28:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-10 17:28:52 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-10 17:28:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-10 17:28:52 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-10 17:28:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-10 17:28:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-10 17:28:53 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-10 17:28:53 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-10 17:28:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-10 17:28:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-10 17:28:55 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-10 17:28:55 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-10 17:29:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-10 17:29:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-10 17:29:01 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-10 17:29:01 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-10 17:29:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-10 17:29:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-10 17:29:06 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-10 17:29:06 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-10 21:57:19 --- ERROR: ErrorException [ 8 ]: Undefined index:  id ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-10 21:57:19 --- STRACE: ErrorException [ 8 ]: Undefined index:  id ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler()
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-10 21:58:15 --- ERROR: ErrorException [ 8 ]: Undefined index:  id_user ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-10 21:58:15 --- STRACE: ErrorException [ 8 ]: Undefined index:  id_user ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler()
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-10 21:59:03 --- ERROR: ErrorException [ 8 ]: Undefined index:  title ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-10 21:59:03 --- STRACE: ErrorException [ 8 ]: Undefined index:  title ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler()
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-10 21:59:09 --- ERROR: ErrorException [ 8 ]: Undefined index:  id ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-10 21:59:09 --- STRACE: ErrorException [ 8 ]: Undefined index:  id ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler()
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-10 21:59:12 --- ERROR: ErrorException [ 8 ]: Undefined index:   ~ APPPATH/classes/model/mquestions.php [ 15 ]
2012-01-10 21:59:12 --- STRACE: ErrorException [ 8 ]: Undefined index:   ~ APPPATH/classes/model/mquestions.php [ 15 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(15): Kohana_Core::error_handler()
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-10 21:59:18 --- ERROR: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/classes/model/mquestions.php [ 16 ]
2012-01-10 21:59:18 --- STRACE: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/classes/model/mquestions.php [ 16 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(16): Kohana_Core::error_handler()
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-10 21:59:32 --- ERROR: ErrorException [ 8 ]: Undefined offset:  4 ~ APPPATH/classes/model/mquestions.php [ 16 ]
2012-01-10 21:59:32 --- STRACE: ErrorException [ 8 ]: Undefined offset:  4 ~ APPPATH/classes/model/mquestions.php [ 16 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(16): Kohana_Core::error_handler()
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-10 21:59:41 --- ERROR: ErrorException [ 8 ]: Undefined offset:  4 ~ APPPATH/classes/model/mquestions.php [ 16 ]
2012-01-10 21:59:41 --- STRACE: ErrorException [ 8 ]: Undefined offset:  4 ~ APPPATH/classes/model/mquestions.php [ 16 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(16): Kohana_Core::error_handler()
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-10 21:59:51 --- ERROR: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/classes/model/mquestions.php [ 16 ]
2012-01-10 21:59:51 --- STRACE: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/classes/model/mquestions.php [ 16 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(16): Kohana_Core::error_handler()
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-10 22:00:07 --- ERROR: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/classes/model/mquestions.php [ 16 ]
2012-01-10 22:00:07 --- STRACE: ErrorException [ 2 ]: Illegal offset type ~ APPPATH/classes/model/mquestions.php [ 16 ]
--
#0 /Users/ravado/Sites/edu/application/classes/model/mquestions.php(16): Kohana_Core::error_handler()
#1 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(24): Model_Mquestions->mainQA()
#2 [internal function]: Controller_Questions_Questions->action_index(Object(Controller_Questions_Questions))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#5 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#6 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#7 {main}
2012-01-10 22:22:47 --- ERROR: ErrorException [ 8 ]: Undefined index:  username ~ APPPATH/views/questions/vQuestions.php [ 80 ]
2012-01-10 22:22:47 --- STRACE: ErrorException [ 8 ]: Undefined index:  username ~ APPPATH/views/questions/vQuestions.php [ 80 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(80): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-10 22:23:11 --- ERROR: ErrorException [ 8 ]: Undefined index:  username ~ APPPATH/views/questions/vQuestions.php [ 114 ]
2012-01-10 22:23:11 --- STRACE: ErrorException [ 8 ]: Undefined index:  username ~ APPPATH/views/questions/vQuestions.php [ 114 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(114): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-10 22:32:37 --- ERROR: ErrorException [ 8 ]: Undefined index:  username ~ APPPATH/views/questions/vQuestions.php [ 80 ]
2012-01-10 22:32:37 --- STRACE: ErrorException [ 8 ]: Undefined index:  username ~ APPPATH/views/questions/vQuestions.php [ 80 ]
--
#0 /Users/ravado/Sites/edu/application/views/questions/vQuestions.php(80): Kohana_Core::error_handler('/Users/ravado/S...', Array)
#1 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#2 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#3 /Users/ravado/Sites/edu/system/classes/kohana/view.php(228): Kohana_View->render()
#4 /Users/ravado/Sites/edu/application/views/vBase.php(38): Kohana_View->__toString('/Users/ravado/S...', Array)
#5 /Users/ravado/Sites/edu/system/classes/kohana/view.php(61): include('/Users/ravado/S...')
#6 /Users/ravado/Sites/edu/system/classes/kohana/view.php(343): Kohana_View::capture()
#7 /Users/ravado/Sites/edu/system/classes/kohana/controller/template.php(44): Kohana_View->render()
#8 /Users/ravado/Sites/edu/application/classes/controller/base.php(50): Kohana_Controller_Template->after()
#9 [internal function]: Controller_Base->after(Object(Controller_Questions_Questions))
#10 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(121): ReflectionMethod->invoke(Object(Request))
#11 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#12 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#13 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#14 {main}
2012-01-10 23:47:04 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/question was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-10 23:47:04 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/question was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-10 23:47:11 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/ask was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-10 23:47:11 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/ask was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-10 23:51:13 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/12 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-10 23:51:13 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/12 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-10 23:51:38 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/12 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-10 23:51:38 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/12 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-10 23:51:41 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_Questions_Questions::action_question() ~ APPPATH/classes/controller/questions/questions.php [ 120 ]
2012-01-10 23:51:41 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Controller_Questions_Questions::action_question() ~ APPPATH/classes/controller/questions/questions.php [ 120 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(120): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_question(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-10 23:51:46 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_Questions_Questions::action_question() ~ APPPATH/classes/controller/questions/questions.php [ 120 ]
2012-01-10 23:51:46 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Controller_Questions_Questions::action_question() ~ APPPATH/classes/controller/questions/questions.php [ 120 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(120): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_question(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-10 23:51:49 --- ERROR: ErrorException [ 2 ]: Missing argument 1 for Controller_Questions_Questions::action_question() ~ APPPATH/classes/controller/questions/questions.php [ 120 ]
2012-01-10 23:51:49 --- STRACE: ErrorException [ 2 ]: Missing argument 1 for Controller_Questions_Questions::action_question() ~ APPPATH/classes/controller/questions/questions.php [ 120 ]
--
#0 /Users/ravado/Sites/edu/application/classes/controller/questions/questions.php(120): Kohana_Core::error_handler()
#1 [internal function]: Controller_Questions_Questions->action_question(Object(Controller_Questions_Questions))
#2 /Users/ravado/Sites/edu/system/classes/kohana/request/client/internal.php(118): ReflectionMethod->invoke(Object(Request))
#3 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#4 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute()
#5 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#6 {main}
2012-01-10 23:51:53 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/dqwd was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-10 23:51:53 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/dqwd was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-10 23:52:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-10 23:52:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-10 23:52:17 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-10 23:52:17 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/331e547ef1c43131903c8831c1866453.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-10 23:52:19 --- ERROR: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
2012-01-10 23:52:19 --- STRACE: HTTP_Exception_404 [ 404 ]: Unable to find a route to match the URI: uploads/imagesnews/e4f4bba8a247f757deb01032409ad886.jpg ~ SYSPATH/classes/kohana/request.php [ 1126 ]
--
#0 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#1 {main}
2012-01-10 23:57:29 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/12 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-10 23:57:29 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/12 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}
2012-01-10 23:57:42 --- ERROR: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/12 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
2012-01-10 23:57:42 --- STRACE: HTTP_Exception_404 [ 404 ]: The requested URL questions/question/12 was not found on this server. ~ SYSPATH/classes/kohana/request/client/internal.php [ 87 ]
--
#0 /Users/ravado/Sites/edu/system/classes/kohana/request/client.php(64): Kohana_Request_Client_Internal->execute_request(Object(Request))
#1 /Users/ravado/Sites/edu/system/classes/kohana/request.php(1138): Kohana_Request_Client->execute(Object(Request))
#2 /Users/ravado/Sites/edu/index.php(109): Kohana_Request->execute()
#3 {main}