<div id="dvContent">
    <div class="spnTitle Page">Тесты</div>
</div>