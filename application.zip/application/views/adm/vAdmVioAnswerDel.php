    <input class="inpColor ReferName" type="text" id="inpQuestionId" placeholder="ID Вопроса">
    <input type="hidden" id="hQuestionId" value="">
    <a class="btn" id="btnQuestionAll">Вывести</a>
    <a class="btn btn-danger" id="btnDelAnswers">Удалить отмеченные</a>
    <div class="alert alert-info" >Вопрос</div>
    <div class="well" id="dvQuestionTitle"></div>
    <div class="alert alert-info">Ответы</div>
    <div id="dvAllAnswers"></div>

