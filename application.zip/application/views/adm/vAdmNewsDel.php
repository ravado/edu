    <input class="inpColor ReferName" type="text" id="inpNewsDel" placeholder="ID Новости">
    <a class="btnSilver" name="btnNewsTitle">Показать новость</a><br />
    <input class="inpColor ReferName" disabled="disabled" type="text" id="inpNewsTitle" placeholder="Заголовок новости">
    <a class="btnSilver" name="btnNewsDel">Удалить новость</a><br />

