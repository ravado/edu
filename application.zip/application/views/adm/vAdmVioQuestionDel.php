    <input class="inpColor ReferName" type="number" id="inpQuestionId" placeholder="ID Вопроса">
    <a class="btn" name="btnQuestionTitle" id="btnShowQuestion">Показать Вопрос</a>
    <a class="btn btn-danger" name="btnQuestionDel" id="btnDelQuestion">Удалить вопрос</a>
    <div class="alert alert-info">Заголовок вопроса</div>
    <div class="well" id="dvQuestionTitle"></div>
    <input type="hidden" id="hQuestionId" value="">
    <div class="alert alert-info">Текст вопроса</div>
    <div class="well" id="dvQuestionFull"></div>



