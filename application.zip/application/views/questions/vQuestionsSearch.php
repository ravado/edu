<div id="dvContent">
    <div class="spnTitle Page">Вопросы и ответы: поиск</div>
    <div id="dvSearch">
        <input class="inpColor" id="txtSearch" type="text" placeholder="Искать тут">
        <a class="btnColor register" id="submitSearch">Найти</a>
    </div>
    <div id="searchResult"></div>
</div>