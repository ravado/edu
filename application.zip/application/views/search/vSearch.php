<div id="dvContent">
    <div class="spnTitle Page">Поиск</div>
    <div id="dvForResults">
        <div id="dvSearch">
            <input class="inpColor" id="txtSearch" type="text" placeholder="Искать тут">
            <a class="btnColor register" id="submitSearch">Найти</a>
        </div>
        <div id="searchResult"></div>
    </div>
</div>