<div id="dvContent">
   <div id="dvRegInfo">
       <img src="../../../stfile/img/user/ok.png" />
       Поздравляем!<br/>
       Ваша учетная запись <b>успешно активирована</b><br/>
       Перейдите на <a href="/">главную страницу</a>, что бы авторизироваться.
   </div>
</div>