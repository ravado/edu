<div id="dvContent">
   <div id="dvRegInfo">
       <img src="../../../stfile/img/user/mail.png" />
       Вы запросили восстановления пароля<br/>
       На ваш электронный ящик, мы выслали инструкции для сброса пароля.
   </div>
</div>