<div id="dvContent">
   <div id="dvRegInfo">
       <img src="../../../stfile/img/user/mail.png" />
       Генерация нового пароля прошла успешно!<br/>
       Новый пароль был выслан на ваш электронный ящик.
   </div>
</div>