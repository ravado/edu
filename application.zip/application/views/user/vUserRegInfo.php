<div id="dvContent">
   <div id="dvRegInfo">
       <img src="../../../stfile/img/user/mail.png" />
       Поздравляем!<br/>
       Вы успешно зарагестрировались на сайте <b>EduName</b>.<br/>
       На ваш электронный адрес было отправлено письмо для активации учетной записи.
   </div>
</div>