<?php
define('SYSTEM_ROOT', '/home/redactor/www/');

define('FILES_ROOT', SYSTEM_ROOT.'tmp/files/');
define('IMAGES_ROOT', SYSTEM_ROOT.'tmp/images/');
?>