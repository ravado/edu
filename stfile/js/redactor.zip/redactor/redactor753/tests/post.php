<?php
/*
echo stripslashes($_POST['redactor']);
echo '<hr style="clear: both;">';
echo stripslashes($_POST['redactor2']);
*/

print_r($_POST);
?>